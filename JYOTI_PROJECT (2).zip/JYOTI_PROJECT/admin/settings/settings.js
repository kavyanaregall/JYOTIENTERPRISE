/* =========================================
   JYOTI ENTERPRISE
   SETTINGS MODULE
   FRONTEND ONLY
========================================= */


/* =========================================
   ASSUMED STORE DATA
========================================= */

const storeData = {

    name: "Jyoti Enterprise",

    phone: "+91 98765 43210",

    email: "info@jyotienterprise.com",

    address:
        "Jyoti Enterprise, Main Market Road, Bengaluru, Karnataka - 560001"

};


/* =========================================
   SETTINGS TABS
========================================= */

const settingsTabs =
    document.querySelectorAll(
        ".settings-tab"
    );


const settingsSections =
    document.querySelectorAll(
        ".settings-section"
    );


settingsTabs.forEach(
    function(tab) {

        tab.addEventListener(
            "click",
            function() {


                const section =
                    tab.dataset.section;


                settingsTabs.forEach(
                    function(item) {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                settingsSections.forEach(
                    function(item) {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                tab.classList.add(
                    "active"
                );


                document
                    .getElementById(
                        section + "Section"
                    )
                    .classList.add(
                        "active"
                    );

            }
        );

    }
);


/* =========================================
   STORE FORM
========================================= */

const storeForm =
    document.getElementById(
        "storeForm"
    );


const storeName =
    document.getElementById(
        "storeName"
    );


const contactNumber =
    document.getElementById(
        "contactNumber"
    );


const storeEmail =
    document.getElementById(
        "storeEmail"
    );


const storeAddress =
    document.getElementById(
        "storeAddress"
    );


storeForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        storeData.name =
            storeName.value.trim();


        storeData.phone =
            contactNumber.value.trim();


        storeData.email =
            storeEmail.value.trim();


        storeData.address =
            storeAddress.value.trim();


        showToast(
            "Store information saved successfully."
        );


        console.log(
            "Updated store data:",
            storeData
        );

    }
);


/* =========================================
   STORE CANCEL
========================================= */

const storeCancel =
    document.getElementById(
        "storeCancel"
    );


storeCancel.addEventListener(
    "click",
    function() {

        storeName.value =
            storeData.name;


        contactNumber.value =
            storeData.phone;


        storeEmail.value =
            storeData.email;


        storeAddress.value =
            storeData.address;

    }
);


/* =========================================
   LOGO UPLOAD
========================================= */

const logoUpload =
    document.getElementById(
        "logoUpload"
    );


const currentLogo =
    document.querySelector(
        ".current-logo"
    );


logoUpload.addEventListener(
    "change",
    function() {


        const file =
            logoUpload.files[0];


        if (!file) {
            return;
        }


        if (
            !file.type.startsWith(
                "image/"
            )
        ) {

            alert(
                "Please select an image file."
            );

            logoUpload.value = "";

            return;

        }


        const reader =
            new FileReader();


        reader.onload =
            function(event) {

                currentLogo.innerHTML = `

                    <img
                        src="${event.target.result}"
                        alt="Store Logo"
                    >

                `;

                currentLogo.classList.add(
                    "uploaded"
                );

            };


        reader.readAsDataURL(file);

    }
);


/* =========================================
   REMOVE LOGO
========================================= */

const removeLogo =
    document.getElementById(
        "removeLogo"
    );


removeLogo.addEventListener(
    "click",
    function() {


        logoUpload.value = "";


        currentLogo.innerHTML = `

            <i class="fa-solid fa-book-open"></i>

        `;


        currentLogo.classList.remove(
            "uploaded"
        );

    }
);


/* =========================================
   PASSWORD TOGGLE
========================================= */

const passwordToggles =
    document.querySelectorAll(
        ".password-toggle"
    );


passwordToggles.forEach(
    function(button) {

        button.addEventListener(
            "click",
            function() {


                const targetId =
                    button.dataset.target;


                const input =
                    document.getElementById(
                        targetId
                    );


                if (
                    input.type ===
                    "password"
                ) {

                    input.type =
                        "text";


                    button.innerHTML = `

                        <i
                            class="
                                fa-regular
                                fa-eye-slash
                            "
                        ></i>

                    `;

                } else {

                    input.type =
                        "password";


                    button.innerHTML = `

                        <i
                            class="
                                fa-regular
                                fa-eye
                            "
                        ></i>

                    `;

                }

            }
        );

    }
);


/* =========================================
   PASSWORD VALIDATION
========================================= */

const newPassword =
    document.getElementById(
        "newPassword"
    );


const lengthRequirement =
    document.getElementById(
        "lengthRequirement"
    );


const numberRequirement =
    document.getElementById(
        "numberRequirement"
    );


const specialRequirement =
    document.getElementById(
        "specialRequirement"
    );


newPassword.addEventListener(
    "input",
    function() {


        const password =
            newPassword.value;


        const hasLength =
            password.length >= 8;


        const hasNumber =
            /[0-9]/.test(
                password
            );


        const hasSpecial =
            /[^A-Za-z0-9]/.test(
                password
            );


        updateRequirement(
            lengthRequirement,
            hasLength
        );


        updateRequirement(
            numberRequirement,
            hasNumber
        );


        updateRequirement(
            specialRequirement,
            hasSpecial
        );

    }
);


/* =========================================
   REQUIREMENT UI
========================================= */

function updateRequirement(
    element,
    valid
) {


    if (valid) {

        element.classList.add(
            "valid"
        );


        element.querySelector(
            "i"
        ).className =
            "fa-solid fa-circle-check";

    } else {

        element.classList.remove(
            "valid"
        );


        element.querySelector(
            "i"
        ).className =
            "fa-solid fa-circle";

    }

}


/* =========================================
   PASSWORD FORM
========================================= */

const passwordForm =
    document.getElementById(
        "passwordForm"
    );


passwordForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        const currentPassword =
            document.getElementById(
                "currentPassword"
            ).value;


        const newPasswordValue =
            newPassword.value;


        const confirmPassword =
            document.getElementById(
                "confirmPassword"
            ).value;


        if (!currentPassword) {

            alert(
                "Please enter your current password."
            );

            return;

        }


        if (
            newPasswordValue.length <
            8
        ) {

            alert(
                "New password must contain at least 8 characters."
            );

            return;

        }


        if (
            !/[0-9]/.test(
                newPasswordValue
            )
        ) {

            alert(
                "New password must contain at least one number."
            );

            return;

        }


        if (
            !/[^A-Za-z0-9]/.test(
                newPasswordValue
            )
        ) {

            alert(
                "New password must contain at least one special character."
            );

            return;

        }


        if (
            newPasswordValue !==
            confirmPassword
        ) {

            alert(
                "New password and confirmation password do not match."
            );

            return;

        }


        /*
            FRONTEND ONLY

            Later the password will be
            sent to your backend/API.
        */


        showToast(
            "Password changed successfully."
        );


        passwordForm.reset();


        updateRequirement(
            lengthRequirement,
            false
        );


        updateRequirement(
            numberRequirement,
            false
        );


        updateRequirement(
            specialRequirement,
            false
        );

    }
);


/* =========================================
   PASSWORD CANCEL
========================================= */

const passwordCancel =
    document.getElementById(
        "passwordCancel"
    );


passwordCancel.addEventListener(
    "click",
    function() {

        passwordForm.reset();


        updateRequirement(
            lengthRequirement,
            false
        );


        updateRequirement(
            numberRequirement,
            false
        );


        updateRequirement(
            specialRequirement,
            false
        );

    }
);


/* =========================================
   TOAST
========================================= */

const successToast =
    document.getElementById(
        "successToast"
    );


const toastText =
    document.getElementById(
        "toastText"
    );


let toastTimer;


function showToast(message) {


    toastText.textContent =
        message;


    successToast.classList.add(
        "show"
    );


    clearTimeout(
        toastTimer
    );


    toastTimer =
        setTimeout(
            function() {

                successToast.classList.remove(
                    "show"
                );

            },
            3000
        );

}