document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const passwordToggle = document.getElementById("passwordToggle");
    const passwordIcon = document.getElementById("passwordIcon");
    const signInButton = document.getElementById("signInButton");

    // Popup elements
    const customPopup = document.getElementById("customPopup");
    const popupTitle = document.getElementById("popupTitle");
    const popupMessage = document.getElementById("popupMessage");
    const popupOkBtn = document.getElementById("popupOkBtn");

    // Trigger popup signal without any browser host dialog
    function triggerPopupSignal(title, message, redirectUrl) {
        if (popupTitle) popupTitle.textContent = title;
        if (popupMessage) popupMessage.textContent = message;

        if (customPopup) {
            customPopup.classList.add("active");

            popupOkBtn.onclick = function () {
                customPopup.classList.remove("active");
                if (redirectUrl) window.location.href = redirectUrl;
            };

            // Auto-redirect if user does not click OK
            setTimeout(function () {
                if (redirectUrl) window.location.href = redirectUrl;
            }, 1400);
        } else if (redirectUrl) {
            window.location.href = redirectUrl;
        }
    }

    // Toggle password visibility
    if (passwordToggle && passwordInput && passwordIcon) {
        passwordToggle.addEventListener("click", function () {
            const isPassword = passwordInput.type === "password";
            passwordInput.type = isPassword ? "text" : "password";
            passwordIcon.classList.toggle("fa-eye", !isPassword);
            passwordIcon.classList.toggle("fa-eye-slash", isPassword);
        });
    }

    if (loginForm) {
        loginForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            const email = emailInput.value.trim().toLowerCase();
            const password = passwordInput.value;

            if (signInButton) {
                signInButton.disabled = true;
                signInButton.innerText = "Signing In...";
            }

            try {
                const response = await fetch("http://127.0.0.1:5000/api/auth/login", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: email, password: password, role: "admin" })
                });

                const data = await response.json().catch(() => ({}));
                if (!response.ok || !data.success || !data.user || data.user.role !== "admin") {
                    triggerPopupSignal(
                        "Login Failed",
                        "Invalid email or password. Use the admin account details on file."
                    );
                    return;
                }

                // Only establish a session after the server verifies the stored admin credentials.
                localStorage.setItem("token", data.token || "admin_active_token_" + Date.now());
                localStorage.setItem("user", JSON.stringify(data.user));
                localStorage.setItem("userRole", "admin");

                triggerPopupSignal(
                    "Login Done",
                    "Authentication successful! Entering Admin Dashboard.",
                    "../dashboard/dashboard.html"
                );
            } catch (err) {
                console.error("Admin login request failed:", err);
                triggerPopupSignal(
                    "Login Unavailable",
                    "Could not verify your account. Please check the server connection and try again."
                );
            } finally {
                if (signInButton) {
                    signInButton.disabled = false;
                    signInButton.innerText = "Sign In";
                }
            }
        });
    }
});
