// ============================================================
// JYOTI ENTERPRISE - CATEGORIES MANAGEMENT
// ============================================================

const API_URL = "http://localhost:5000/api/categories";
const SERVER_URL = "http://localhost:5000";
const FALLBACK_ICON = '<div class="category-icon"><i class="fa-solid fa-layer-group"></i></div>';

function showPopup(message, type = "info") {
    let popup = document.getElementById("actionPopupMessage");
    if (!popup) {
        if (!document.getElementById("actionPopupGlowStyles")) {
            const style = document.createElement("style");
            style.id = "actionPopupGlowStyles";
            style.textContent = `
                @keyframes actionPopupGlow {
                    0%, 100% { box-shadow: 0 12px 32px rgba(15,23,42,.22), 0 0 0 rgba(34,197,94,0); }
                    50% { box-shadow: 0 12px 32px rgba(15,23,42,.22), 0 0 18px rgba(34,197,94,.35); }
                }
                #actionPopupMessage { animation: actionPopupGlow 1.8s ease-in-out infinite; }
                @media (prefers-reduced-motion: reduce) { #actionPopupMessage { animation: none; } }
            `;
            document.head.appendChild(style);
        }
        popup = document.createElement("div");
        popup.id = "actionPopupMessage";
        popup.setAttribute("role", "status");
        popup.setAttribute("aria-live", "polite");
        Object.assign(popup.style, {
            position: "fixed", top: "24px", right: "24px", zIndex: "10000",
            maxWidth: "min(420px, calc(100vw - 32px))", padding: "14px 20px",
            borderRadius: "12px", color: "#fff", font: "600 14px/1.5 Inter, sans-serif",
            whiteSpace: "pre-line", boxShadow: "0 12px 32px rgba(15,23,42,.22)",
            opacity: "0", transform: "translateY(-8px)", transition: "all .2s ease"
        });
        document.body.appendChild(popup);
    }
    popup.style.background = type === "error" ? "#dc2626" : "#16a34a";
    popup.textContent = message;
    popup.style.opacity = "1";
    popup.style.transform = "translateY(0)";
    clearTimeout(popup.hideTimer);
    popup.hideTimer = setTimeout(() => {
        popup.style.opacity = "0";
        popup.style.transform = "translateY(-8px)";
    }, 3500);
}

let categories = [];
let filteredCategories = [];
let currentPage = 1;
let itemsPerPage = 8;

// DOM Elements
const categoryTableBody = document.getElementById("categoryTableBody");
const categorySearch = document.getElementById("categorySearch");
const navbarSearch = document.getElementById("navbarSearch");
const resetSearch = document.getElementById("resetSearch");
const itemsPerPageSelect = document.getElementById("itemsPerPage");
const resultCount = document.getElementById("resultCount");
const paginationInfo = document.getElementById("paginationInfo");
const pageNumbers = document.getElementById("pageNumbers");
const previousPage = document.getElementById("previousPage");
const nextPage = document.getElementById("nextPage");
const selectAll = document.getElementById("selectAll");

const categoryModal = document.getElementById("categoryModal");
const addCategoryButton = document.getElementById("addCategoryButton");
const closeModal = document.getElementById("closeModal");
const cancelCategory = document.getElementById("cancelCategory");
const categoryForm = document.getElementById("categoryForm");
const categoryImage = document.getElementById("categoryImage");
const imagePreview = document.getElementById("imagePreview");

const totalCategories = document.getElementById("totalCategories");
const activeCategories = document.getElementById("activeCategories");
const totalItemsLinked = document.getElementById("totalItemsLinked");
const inactiveCategories = document.getElementById("inactiveCategories");

// ------------------------------------------------------------
// INITIAL LOAD & EVENTS
// ------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
    loadCategories();
    setupEventListeners();
});

function setupEventListeners() {
    if (addCategoryButton) addCategoryButton.addEventListener("click", openCategoryModal);
    if (closeModal) closeModal.addEventListener("click", closeCategoryModal);
    if (cancelCategory) cancelCategory.addEventListener("click", closeCategoryModal);
    if (categoryForm) categoryForm.addEventListener("submit", handleCategorySubmit);
    if (categorySearch) categorySearch.addEventListener("input", applySearch);

    if (navbarSearch) {
        navbarSearch.addEventListener("input", () => {
            if (categorySearch) categorySearch.value = navbarSearch.value;
            applySearch();
        });
    }

    if (resetSearch) {
        resetSearch.addEventListener("click", () => {
            if (categorySearch) categorySearch.value = "";
            if (navbarSearch) navbarSearch.value = "";
            filteredCategories = [...categories];
            currentPage = 1;
            renderCategories();
        });
    }

    if (itemsPerPageSelect) {
        itemsPerPageSelect.addEventListener("change", () => {
            itemsPerPage = Number(itemsPerPageSelect.value);
            currentPage = 1;
            renderCategories();
        });
    }

    if (previousPage) {
        previousPage.addEventListener("click", () => {
            if (currentPage > 1) {
                currentPage--;
                renderCategories();
            }
        });
    }

    if (nextPage) {
        nextPage.addEventListener("click", () => {
            const totalPages = Math.ceil(filteredCategories.length / itemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderCategories();
            }
        });
    }

    if (selectAll) {
        selectAll.addEventListener("change", () => {
            document.querySelectorAll(".category-checkbox").forEach(cb => {
                cb.checked = selectAll.checked;
            });
        });
    }

    if (categoryTableBody) {
        categoryTableBody.addEventListener("click", handleCategoryActions);
    }

    if (categoryImage) {
        categoryImage.addEventListener("change", handleImagePreview);
    }
}

// ------------------------------------------------------------
// LOAD CATEGORIES FROM BACKEND
// ------------------------------------------------------------

async function loadCategories() {
    try {
        const response = await fetch(API_URL);
        const data = await response.json();

        if (data.success) {
            categories = data.categories || [];
            filteredCategories = [...categories];
            currentPage = 1;
            renderCategories();
            updateSummary();
        } else {
            throw new Error(data.message);
        }
    } catch (err) {
        console.error("Error loading categories:", err);
        if (categoryTableBody) {
            categoryTableBody.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align:center;padding:30px;color:#DC2626;">
                        Unable to connect to server. Ensure Flask app.py is running.
                    </td>
                </tr>
            `;
        }
    }
}

// ------------------------------------------------------------
// RENDER TABLE
// ------------------------------------------------------------

function renderCategories() {
    if (!categoryTableBody) return;
    categoryTableBody.innerHTML = "";

    const startIndex = (currentPage - 1) * itemsPerPage;
    const currentCategories = filteredCategories.slice(startIndex, startIndex + itemsPerPage);

    if (currentCategories.length === 0) {
        categoryTableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align:center;padding:30px;">
                    No categories found.
                </td>
            </tr>
        `;
        updatePagination();
        return;
    }

    currentCategories.forEach(category => {
        const row = document.createElement("tr");
        const statusClass = String(category.status).toLowerCase() === "active" ? "active" : "inactive";
        const catCode = `CAT${String(category.id).padStart(3, '0')}`;

        // Format image thumbnail or icon
        let imageHtml = FALLBACK_ICON;
        if (category.image) {
            const imgSrc = category.image.startsWith("http") ? category.image : `${SERVER_URL}${category.image}`;
            imageHtml = `<img src="${imgSrc}" alt="${category.name}" class="category-img" onerror="this.outerHTML='${FALLBACK_ICON.replace(/"/g, '&quot;')}'">`;
        }

        row.innerHTML = `
            <td>
                <input type="checkbox" class="category-checkbox" value="${category.id}">
            </td>
            <td>${catCode}</td>
            <td>
                <div class="category-cell">
                    ${imageHtml}
                    <div class="category-name">
                        <strong>${escapeHTML(category.name || "")}</strong>
                        <span>${catCode}</span>
                    </div>
                </div>
            </td>
            <td>
                <div class="description">${escapeHTML(category.description || "No description added.")}</div>
            </td>
            <td>
                <span class="product-count">${category.products || 0}</span>
            </td>
            <td>
                <span class="status-badge ${statusClass}">${category.status}</span>
            </td>
            <td>${category.created_at || "N/A"}</td>
            <td>
                <div class="action-buttons">
                    <button type="button" class="action-button edit" data-id="${category.id}" title="Edit Category">
                        <i class="fa-solid fa-pen" style="pointer-events: none;"></i>
                    </button>
                    <button type="button" class="action-button delete" data-id="${category.id}" title="Delete Category">
                        <i class="fa-solid fa-trash" style="pointer-events: none;"></i>
                    </button>
                </div>
            </td>
        `;
        categoryTableBody.appendChild(row);
    });

    updatePagination();
}

// ------------------------------------------------------------
// ACTIONS: EDIT & DELETE
// ------------------------------------------------------------

async function handleCategoryActions(event) {
    const button = event.target.closest(".action-button");
    if (!button) return;
    const catId = button.dataset.id;

    // EDIT
    if (button.classList.contains("edit")) {
        const cat = categories.find(c => String(c.id) === String(catId));
        if (!cat) return;

        openCategoryModal();
        document.getElementById("categoryName").value = cat.name || "";
        document.getElementById("categoryStatus").value = cat.status || "Active";
        document.getElementById("categoryDescription").value = cat.description || "";

        categoryForm.dataset.mode = "edit";
        categoryForm.dataset.editId = catId;

        const title = document.querySelector("#categoryModal .modal-header h2");
        if (title) title.textContent = "Edit Category";
    }

    // DELETE
    if (button.classList.contains("delete")) {
        const cat = categories.find(c => String(c.id) === String(catId));
        if (cat && cat.products > 0) {
            showPopup(`"${cat.name}" contains ${cat.products} products. Reassign or delete products first.`);
            return;
        }

        if (!confirm(`Are you sure you want to delete category #${catId}?`)) return;

        try {
            const res = await fetch(`${API_URL}/${catId}`, { method: "DELETE" });
            const data = await res.json();
            if (data.success) {
                showPopup("Category deleted successfully.");
                await loadCategories();
            } else {
                showPopup(data.message || "Failed to delete category.");
            }
        } catch (err) {
            showPopup("Error connecting to server to delete category.");
        }
    }
}

// ------------------------------------------------------------
// FORM SUBMIT (ADD / UPDATE)
// ------------------------------------------------------------

async function handleCategorySubmit(event) {
    event.preventDefault();

    const isEdit = categoryForm.dataset.mode === "edit";
    const editId = categoryForm.dataset.editId;

    const name = document.getElementById("categoryName").value.trim();
    const status = document.getElementById("categoryStatus").value;
    const description = document.getElementById("categoryDescription").value.trim();

    if (!name) {
        showPopup("Please enter a category name.");
        return;
    }

    const formData = new FormData();
    formData.append("categoryName", name);
    formData.append("categoryStatus", status);
    formData.append("categoryDescription", description);

    if (categoryImage && categoryImage.files.length > 0) {
        formData.append("categoryImage", categoryImage.files[0]);
    }

    const url = isEdit ? `${API_URL}/${editId}` : API_URL;

    try {
        const res = await fetch(url, {
            method: "POST",
            body: formData
        });
        const data = await res.json();

        if (data.success) {
            showPopup(isEdit ? "Category updated successfully." : "Category added successfully.");
            closeCategoryModal();
            await loadCategories();
        } else {
            showPopup(data.message || "Failed to save category.");
        }
    } catch (err) {
        showPopup("Error connecting to server.");
    }
}

// ------------------------------------------------------------
// MODAL CONTROLS & PREVIEW
// ------------------------------------------------------------

function openCategoryModal() {
    categoryModal.classList.add("show");
    document.body.style.overflow = "hidden";
    categoryForm.reset();
    delete categoryForm.dataset.mode;
    delete categoryForm.dataset.editId;

    const title = document.querySelector("#categoryModal .modal-header h2");
    if (title) title.textContent = "Add Category";
    if (imagePreview) imagePreview.style.display = "none";
}

function closeCategoryModal() {
    categoryModal.classList.remove("show");
    document.body.style.overflow = "";
    categoryForm.reset();
    delete categoryForm.dataset.mode;
    delete categoryForm.dataset.editId;
    if (imagePreview) imagePreview.style.display = "none";
}

function handleImagePreview(e) {
    const file = e.target.files[0];
    if (file && imagePreview) {
        const url = URL.createObjectURL(file);
        imagePreview.style.display = "block";
        imagePreview.innerHTML = `<img src="${url}" style="width:50px;height:50px;border-radius:6px;object-fit:cover;">`;
    }
}

// ------------------------------------------------------------
// SEARCH & SUMMARY
// ------------------------------------------------------------

function applySearch() {
    const term = (categorySearch?.value || "").toLowerCase().trim();
    filteredCategories = categories.filter(c => {
        const catCode = `CAT${String(c.id).padStart(3, '0')}`.toLowerCase();
        return (c.name || "").toLowerCase().includes(term) ||
               (c.description || "").toLowerCase().includes(term) ||
               catCode.includes(term);
    });
    currentPage = 1;
    renderCategories();
}

function updateSummary() {
    if (totalCategories) totalCategories.textContent = categories.length;
    if (activeCategories) activeCategories.textContent = categories.filter(c => String(c.status).toLowerCase() === "active").length;
    if (inactiveCategories) inactiveCategories.textContent = categories.filter(c => String(c.status).toLowerCase() === "inactive").length;
    if (totalItemsLinked) {
        const totalProducts = categories.reduce((sum, c) => sum + (Number(c.products) || 0), 0);
        totalItemsLinked.textContent = totalProducts;
    }
}

function updatePagination() {
    const total = filteredCategories.length;
    const totalPages = Math.max(1, Math.ceil(total / itemsPerPage));
    const start = total === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1;
    const end = Math.min(currentPage * itemsPerPage, total);

    if (resultCount) resultCount.textContent = `Showing ${start}–${end} of ${total} categories`;
    if (paginationInfo) paginationInfo.textContent = `Page ${currentPage} of ${totalPages}`;
    if (previousPage) previousPage.disabled = currentPage === 1;
    if (nextPage) nextPage.disabled = currentPage === totalPages;

    if (pageNumbers) {
        pageNumbers.innerHTML = "";
        for (let i = 1; i <= totalPages; i++) {
            const btn = document.createElement("button");
            btn.className = `page-number ${i === currentPage ? "active" : ""}`;
            btn.textContent = i;
            btn.addEventListener("click", () => {
                currentPage = i;
                renderCategories();
            });
            pageNumbers.appendChild(btn);
        }
    }
}

function escapeHTML(str) {
    return String(str).replace(/[&<>'"]/g, tag => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[tag] || tag));
}

