// ============================================================
// JYOTI ENTERPRISE - NOTIFICATIONS CONTROLLER
// ============================================================

const NOTIF_API_URL = "http://127.0.0.1:5000/api/admin/notifications";

let notifications = [];

let activeFilter = "all";

// DOM Elements
const notificationList = document.getElementById("notificationList");
const emptyState = document.getElementById("emptyState");
const notificationSearch = document.getElementById("notificationSearch");
const allCount = document.getElementById("allCount");
const unreadCount = document.getElementById("unreadCount");
const readCount = document.getElementById("readCount");
const markAllButton = document.getElementById("markAllButton");
const clearAllButton = document.getElementById("clearAllButton");
const clearModal = document.getElementById("clearModal");
const cancelClear = document.getElementById("cancelClear");
const confirmClear = document.getElementById("confirmClear");
const filterTabs = document.querySelectorAll(".filter-tab");

document.addEventListener("DOMContentLoaded", () => {
    loadNotifications();
    setupEventListeners();
    setupSocket();
});

function setupEventListeners() {
    if (notificationSearch) {
        notificationSearch.addEventListener("input", renderNotifications);
    }

    filterTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            filterTabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            activeFilter = tab.dataset.filter || "all";
            renderNotifications();
        });
    });

    if (markAllButton) {
        markAllButton.addEventListener("click", async () => {
            await markOrdersAsRead();
            notifications.forEach(n => n.read = true);
            renderNotifications();
        });
    }

    if (clearAllButton && clearModal) {
        clearAllButton.addEventListener("click", () => clearModal.classList.add("show"));
    }

    if (cancelClear && clearModal) {
        cancelClear.addEventListener("click", () => clearModal.classList.remove("show"));
    }

    if (confirmClear && clearModal) {
        confirmClear.addEventListener("click", () => {
            markOrdersAsRead().finally(() => {
                notifications = [];
                clearModal.classList.remove("show");
                renderNotifications();
            });
        });
    }
}

async function markOrdersAsRead() {
    try {
        const response = await fetch(`${NOTIF_API_URL}/mark-read`, { method: "POST" });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
    } catch (error) {
        console.error("Could not mark admin order notifications as read:", error);
    }
}

async function loadNotifications() {
    try {
        const response = await fetch(NOTIF_API_URL);
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();
        if (!data.success) throw new Error(data.message || "Could not load notifications");

        const liveOrders = notifications.filter(item => item.live);
        const savedOrders = (Array.isArray(data.unread_orders) ? data.unread_orders : [])
            .map(order => ({
                id: Number(order.id),
                type: "order",
                title: `New Order #${order.id} Received`,
                customerName: order.customer_name || "Customer",
                phone: order.customer_phone || "",
                address: "",
                products: [],
                amount: Number(order.total_amount) || 0,
                createdAt: order.created_at,
                read: false
            }));

        notifications = [
            ...liveOrders,
            ...savedOrders.filter(order => !liveOrders.some(live => String(live.id) === String(order.id)))
        ];
    } catch (err) {
        console.error("Could not load admin order notifications:", err);
    }
    renderNotifications();
}

function renderNotifications() {
    if (!notificationList) return;
    notificationList.innerHTML = "";

    const searchTerm = (notificationSearch?.value || "").toLowerCase().trim();

    const filtered = notifications.filter(n => {
        const matchesFilter =
            activeFilter === "all" ||
            (activeFilter === "unread" && !n.read) ||
            (activeFilter === "read" && n.read);

        const prodNames = (n.products || []).map(p => p.name).join(" ").toLowerCase();
        const matchesSearch =
            n.title.toLowerCase().includes(searchTerm) ||
            (n.customerName && n.customerName.toLowerCase().includes(searchTerm)) ||
            (n.phone && n.phone.includes(searchTerm)) ||
            prodNames.includes(searchTerm);

        return matchesFilter && matchesSearch;
    });

    updateCounts();

    if (filtered.length === 0) {
        if (emptyState) emptyState.style.display = "block";
        return;
    } else {
        if (emptyState) emptyState.style.display = "none";
    }

    filtered.forEach(item => {
        const dateObj = new Date(item.createdAt);
        const formattedDate = !isNaN(dateObj)
            ? dateObj.toLocaleString("en-IN", {
                day: "2-digit",
                month: "short",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit"
            })
            : item.createdAt;

        // Render product items list
        let productsBlock = "";
        if (item.products && item.products.length > 0) {
            const listItems = item.products.map(p => `
                <li>
                    <span class="product-name">${escapeHTML(p.name)}</span>
                    <span class="product-qty">Qty: ${p.quantity || 1}</span>
                </li>
            `).join("");

            productsBlock = `
                <div class="notif-products-box">
                    <div class="notif-products-header">
                        <i class="fa-solid fa-box-open"></i> Ordered Items (${item.products.length})
                    </div>
                    <ul class="notif-products-list">
                        ${listItems}
                    </ul>
                </div>
            `;
        }

        const card = document.createElement("div");
        card.className = `notification-card ${!item.read ? 'unread' : ''}`;
        card.innerHTML = `
            <div class="notif-icon order">
                <i class="fa-solid fa-cart-shopping"></i>
            </div>

            <div class="notif-body">
                <div class="notif-header-line">
                    <span class="notif-title">${escapeHTML(item.title)}</span>
                    <span class="notif-time">${formattedDate}</span>
                </div>

                <div class="notif-customer-bar">
                    <span>Customer: <strong>${escapeHTML(item.customerName || 'Customer')}</strong></span>
                    <span class="notif-meta-pill"><i class="fa-solid fa-store"></i> Store pickup</span>
                    ${item.phone ? `<span class="notif-meta-pill"><i class="fa-solid fa-phone"></i> ${escapeHTML(item.phone)}</span>` : ''}
                    ${item.address ? `<span class="notif-meta-pill"><i class="fa-solid fa-location-dot"></i> ${escapeHTML(item.address)}</span>` : ''}
                    <span class="notif-amount-badge">₹${Number(item.amount || 0).toFixed(2)}</span>
                </div>

                ${productsBlock}
            </div>

            <button class="notif-action-btn ${item.read ? '' : 'active'}" onclick="toggleRead(${item.id})" title="${item.read ? 'Mark as Unread' : 'Mark as Read'}">
                <i class="${item.read ? 'fa-regular fa-circle' : 'fa-solid fa-circle-check'}"></i>
            </button>
        `;
        notificationList.appendChild(card);
    });
}

function updateCounts() {
    const total = notifications.length;
    const unread = notifications.filter(n => !n.read).length;
    const read = notifications.filter(n => n.read).length;

    if (allCount) allCount.textContent = total;
    if (unreadCount) unreadCount.textContent = unread;
    if (readCount) readCount.textContent = read;
}

window.toggleRead = function(id) {
    const item = notifications.find(n => n.id === id);
    if (item) {
        item.read = !item.read;
        renderNotifications();
    }
};

function setupSocket() {
    if (typeof io !== "undefined") {
        try {
            const socket = io("http://127.0.0.1:5000");
            socket.on("new_order", (data) => {
                const orderId = Number(data.order_id || data.id || Date.now());
                if (notifications.some(item => String(item.id) === String(orderId))) return;

                notifications.unshift({
                    id: orderId,
                    type: "order",
                    title: `New Order #${orderId} Received`,
                    customerName: data.customer_name || data.customerName || "Customer",
                    phone: data.customer_phone || data.phone || "",
                    address: data.address || "",
                    products: data.products || [],
                    amount: Number(data.total_amount ?? data.amount) || 0,
                    createdAt: data.created_at || new Date().toISOString(),
                    read: false,
                    live: true
                });
                renderNotifications();
            });
        } catch (e) {
            console.log("Socket connection skipped.");
        }
    }
}

function escapeHTML(str) {
    return String(str).replace(/[&<>'"]/g, t => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[t] || t));
}