// ============================================================
// JYOTI ENTERPRISE - DASHBOARD DYNAMIC CONTROLLER & REAL-TIME SYNC
// ============================================================

const API_BASE = "http://127.0.0.1:5000";
const FALLBACK_IMAGE = "../../assets/images/default-product.jpg";

// Embedded base64 audio chime (no missing file errors, plays immediately)
const NOTIFICATION_SOUND = new Audio(
    "data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU9vT18AcHd5fn2AgoGEhoeIiYqLjI2Oj5CSk5SVlpeYmZqbnJ2en6ChoqOkpaanqKmqq6ytrq+wsbKztLW2t7i5uru8vb6/wMHCw8TFxsfIycrLzM3Oz9DR0tPU1dbX2Nna29zd3t/g4eLj5OXm5+jp6uvs7e7v8PHy8/T19vf4+fr7/P3+"
);

document.addEventListener("DOMContentLoaded", () => {
    updateGreetingAndDate();
    loadDashboardData();
    loadAdminNotifications();
    setupDropdowns();
    setupRealtimeAdminSocket();
});

// ------------------------------------------------------------
// 1. DYNAMIC GREETING & REAL-TIME DATE
// ------------------------------------------------------------
function updateGreetingAndDate() {
    const now = new Date();

    const dateElement = document.getElementById("currentDate");
    if (dateElement) {
        const dateOptions = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
        dateElement.textContent = now.toLocaleDateString("en-US", dateOptions);
    }

    const greetingEl = document.querySelector(".welcome-section h2");
    if (greetingEl) {
        const hour = now.getHours();
        let greeting = "Good Morning";
        if (hour >= 12 && hour < 17) {
            greeting = "Good Afternoon";
        } else if (hour >= 17) {
            greeting = "Good Evening";
        }
        greetingEl.innerHTML = `${greeting}, Admin 👋`;
    }
}

// ------------------------------------------------------------
// 2. FETCH LIVE DATA FROM FLASK BACKEND
// ------------------------------------------------------------
async function loadDashboardData() {
    try {
        const response = await fetch(`${API_BASE}/api/dashboard/stats`);
        if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);

        const data = await response.json();
        if (!data.success) throw new Error(data.message || "Failed to load dashboard data");

        const { stats, recent_products } = data;

        renderTopStatistics(stats);
        renderInventoryOverview(stats);
        renderRecentProductsTable(recent_products);
        renderLowStockList(recent_products, stats);
    } catch (error) {
        console.error("Dashboard data load error:", error);
    }
}

// ------------------------------------------------------------
// 3. RENDER TOP 4 METRIC STAT CARDS
// ------------------------------------------------------------
function renderTopStatistics(stats) {
    const statCards = document.querySelectorAll(".statistics-grid .stat-card");
    if (statCards.length < 4) return;

    const totalProductsEl = statCards[0].querySelector(".stat-content h3");
    if (totalProductsEl) totalProductsEl.textContent = stats.total_products ?? 0;

    const categoriesEl = statCards[1].querySelector(".stat-content h3");
    if (categoriesEl) categoriesEl.textContent = stats.total_categories ?? 0;

    const customersEl = statCards[2].querySelector(".stat-content h3");
    if (customersEl) customersEl.textContent = stats.total_customers ?? 0;

    const lowStockEl = statCards[3].querySelector(".stat-content h3");
    if (lowStockEl) lowStockEl.textContent = stats.low_stock ?? 0;
}

// ------------------------------------------------------------
// 4. RENDER INVENTORY OVERVIEW (RIGHT CARD PROGRESS)
// ------------------------------------------------------------
function renderInventoryOverview(stats) {
    const totalProducts = stats.total_products || 0;
    const inStock = stats.in_stock || 0;
    const lowStock = stats.low_stock || 0;
    const outOfStock = stats.out_of_stock || 0;

    const inventoryStats = document.querySelectorAll(".inventory-card .inventory-stat");

    if (inventoryStats[0]) {
        const countEl = inventoryStats[0].querySelector(".inventory-top strong");
        const barEl = inventoryStats[0].querySelector(".progress");
        if (countEl) countEl.textContent = inStock;
        if (barEl) {
            const pct = totalProducts > 0 ? Math.round((inStock / totalProducts) * 100) : 0;
            barEl.style.width = `${pct}%`;
        }
    }

    if (inventoryStats[1]) {
        const countEl = inventoryStats[1].querySelector(".inventory-top strong");
        const barEl = inventoryStats[1].querySelector(".progress");
        if (countEl) countEl.textContent = lowStock;
        if (barEl) {
            const pct = totalProducts > 0 ? Math.round((lowStock / totalProducts) * 100) : 0;
            barEl.style.width = `${pct}%`;
        }
    }

    if (inventoryStats[2]) {
        const countEl = inventoryStats[2].querySelector(".inventory-top strong");
        const barEl = inventoryStats[2].querySelector(".progress");
        if (countEl) countEl.textContent = outOfStock;
        if (barEl) {
            const pct = totalProducts > 0 ? Math.round((outOfStock / totalProducts) * 100) : 0;
            barEl.style.width = `${pct}%`;
        }
    }

    const totalInventoryEl = document.querySelector(".inventory-total strong");
    if (totalInventoryEl) {
        totalInventoryEl.textContent = totalProducts;
    }
}

// ------------------------------------------------------------
// 5. RENDER RECENT PRODUCTS TABLE
// ------------------------------------------------------------
function renderRecentProductsTable(products) {
    const tbody = document.querySelector(".dashboard-table tbody");
    if (!tbody) return;

    if (!products || products.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" style="text-align:center; padding: 25px; color: #94A3B8;">
                    No products added yet.
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = products.map(product => {
        const imageURL = getProductImageURL(product.image);
        const isLow = Number(product.stock) <= 10 && Number(product.stock) > 0;
        const statusText = product.status || (Number(product.stock) > 0 ? "In Stock" : "Out of Stock");
        const statusClass = isLow ? "status low" : "status available";

        return `
            <tr data-product-id="${product.id}">
                <td>
                    <div class="product-cell">
                        <img 
                            src="${imageURL || FALLBACK_IMAGE}" 
                            alt="${escapeHTML(product.name || 'Product')}"
                            style="width: 34px; height: 34px; border-radius: 7px; object-fit: cover; border: 1px solid var(--border);"
                            onerror="this.onerror=null; this.src='${FALLBACK_IMAGE}';"
                        />
                        <div>
                            <strong>${escapeHTML(product.name || "")}</strong>
                            <span>${escapeHTML(product.sku || "")}</span>
                        </div>
                    </div>
                </td>
                <td>${escapeHTML(product.category_name || "Uncategorized")}</td>
                <td>₹${parseFloat(product.price || 0).toFixed(2)}</td>
                <td class="stock-cell">${product.stock ?? 0}</td>
                <td>
                    <span class="${statusClass}">
                        ${escapeHTML(statusText)}
                    </span>
                </td>
            </tr>
        `;
    }).join("");
}

// ------------------------------------------------------------
// 6. RENDER LOW STOCK PRODUCTS IN BOTTOM LIST
// ------------------------------------------------------------
function renderLowStockList(products, stats) {
    const listContainer = document.querySelector(".low-stock-list");
    if (!listContainer) return;

    const lowStockItems = (products || []).filter(p => Number(p.stock) <= 10);

    if (lowStockItems.length === 0) {
        listContainer.innerHTML = `
            <div style="padding: 20px; text-align: center; color: #94A3B8; font-size: 11px;">
                All products currently have healthy stock levels.
            </div>
        `;
        return;
    }

    listContainer.innerHTML = lowStockItems.slice(0, 4).map(item => `
        <div class="low-stock-item" data-product-id="${item.id}">
            <div class="mini-product-icon">
                <i class="fa-solid fa-box" style="font-size: 14px; color: var(--yellow);"></i>
            </div>
            <div class="low-stock-info">
                <strong>${escapeHTML(item.name || "")}</strong>
                <span>Current stock: ${item.stock ?? 0}</span>
            </div>
            <span class="stock-number">
                ${item.stock ?? 0}
            </span>
        </div>
    `).join("");
}

// ------------------------------------------------------------
// 7. NOTIFICATION BAR & DROPDOWN HANDLER
// ------------------------------------------------------------
async function loadAdminNotifications() {
    try {
        const response = await fetch(`${API_BASE}/api/admin/notifications`);
        if (!response.ok) return;

        const data = await response.json();
        if (!data.success) return;

        renderNotificationDropdown(data);
    } catch (err) {
        console.error("Could not load notifications:", err);
    }
}

function renderNotificationDropdown(data) {
    const badge = document.querySelector("#notificationButton .badge, #notificationBadge");
    const container = document.getElementById("notificationDropdown");
    const totalAlerts = data.total_alerts || 0;

    if (badge) {
        badge.textContent = totalAlerts;
        badge.style.display = totalAlerts > 0 ? "inline-flex" : "none";
    }

    if (!container) return;

    let itemsHtml = "";

    if (data.unread_orders && data.unread_orders.length > 0) {
        itemsHtml += data.unread_orders.map(o => `
            <div class="notification-item unread-order" style="padding: 10px 14px; border-bottom: 1px solid #f1f5f9; display: flex; gap: 10px; align-items: center;">
                <div style="background: #ECFDF3; color: #16A34A; border-radius: 6px; padding: 6px 8px; font-size: 13px;">🛒</div>
                <div style="flex:1;">
                    <div style="font-size: 12px; font-weight: 600; color: #0F172A;">Order #${o.id} received</div>
                    <div style="font-size: 11px; color: #64748B;">From ${escapeHTML(o.customer_name)} &bull; ₹${parseFloat(o.total_amount).toFixed(2)}</div>
                </div>
            </div>
        `).join("");
    }

    if (data.low_stock_alerts && data.low_stock_alerts.length > 0) {
        itemsHtml += data.low_stock_alerts.map(l => `
            <div class="notification-item low-stock" style="padding: 10px 14px; border-bottom: 1px solid #f1f5f9; display: flex; gap: 10px; align-items: center;">
                <div style="background: #FEF2F2; color: #DC2626; border-radius: 6px; padding: 6px 8px; font-size: 13px;">⚠️</div>
                <div style="flex:1;">
                    <div style="font-size: 12px; font-weight: 600; color: #0F172A;">Low stock: ${escapeHTML(l.name)}</div>
                    <div style="font-size: 11px; color: #64748B;">Only ${l.stock} left (Min: ${l.minimum_stock})</div>
                </div>
            </div>
        `).join("");
    }

    if (!itemsHtml) {
        itemsHtml = `<div style="padding: 20px; text-align: center; color: #94A3B8; font-size: 12px;">No new notifications</div>`;
    }

    container.innerHTML = `
        <div style="padding: 12px 14px; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center;">
            <strong style="font-size: 13px; color: #1E3A8A;">Notifications (${totalAlerts})</strong>
            ${totalAlerts > 0 ? `<button id="markReadBtn" style="border: none; background: transparent; color: #F59E0B; font-size: 11px; font-weight: 600; cursor: pointer;">Mark all read</button>` : ""}
        </div>
        <div class="notification-list" style="max-height: 280px; overflow-y: auto;">
            ${itemsHtml}
        </div>
    `;

    const markBtn = document.getElementById("markReadBtn");
    if (markBtn) {
        markBtn.addEventListener("click", async (e) => {
            e.stopPropagation();
            try {
                await fetch(`${API_BASE}/api/admin/notifications/mark-read`, { method: "POST" });
                loadAdminNotifications();
            } catch (err) {
                console.error("Failed to dismiss notifications:", err);
            }
        });
    }
}

// ------------------------------------------------------------
// 8. REAL-TIME SOCKET.IO LISTENER
// ------------------------------------------------------------
function setupRealtimeAdminSocket() {
    if (typeof io === "undefined") {
        console.warn("Socket.IO client library not loaded. Live notifications disabled.");
        return;
    }

    const socket = io(API_BASE);

    socket.on("connect", () => {
        // Subscribe to admin private broadcast room
        socket.emit("join_admin");
    });

    // Event 1: New order placed by customer
    socket.on("new_order", (order) => {
        try {
            NOTIFICATION_SOUND.play().catch(() => {});
        } catch (e) {}

        showToast(
            "New Order Received! 🛒",
            `Order #${order.order_id} by <strong>${escapeHTML(order.customer_name)}</strong> for <strong>₹${parseFloat(order.total_amount).toFixed(2)}</strong>`
        );

        // Refresh stats cards, inventory graphs, and notification dropdown automatically
        loadDashboardData();
        loadAdminNotifications();
    });

    // Event 2: Product updated or stock reduced
    socket.on("product_updated", () => {
        loadDashboardData();
    });
}

// ------------------------------------------------------------
// 9. FLOATING TOAST NOTIFICATION CREATOR
// ------------------------------------------------------------
function showToast(title, message) {
    let container = document.getElementById("adminToastContainer");
    if (!container) {
        container = document.createElement("div");
        container.id = "adminToastContainer";
        container.style.cssText = `
            position: fixed;
            top: 24px;
            right: 24px;
            display: flex;
            flex-direction: column;
            gap: 10px;
            z-index: 99999;
        `;
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.style.cssText = `
        min-width: 300px;
        max-width: 380px;
        background: #ffffff;
        border-left: 5px solid #16A34A;
        border-radius: 8px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        padding: 14px 16px;
        display: flex;
        align-items: flex-start;
        gap: 12px;
        animation: fadeIn 0.3s ease;
        transition: opacity 0.3s ease, transform 0.3s ease;
    `;

    toast.innerHTML = `
        <div style="font-size: 20px; line-height: 1;">🔔</div>
        <div style="flex:1;">
            <h4 style="margin: 0 0 4px 0; font-size: 13px; font-weight: 700; color: #0F172A;">${title}</h4>
            <p style="margin: 0; font-size: 12px; color: #475569;">${message}</p>
        </div>
        <button style="border: none; background: transparent; font-size: 16px; color: #94A3B8; cursor: pointer; line-height: 1;">&times;</button>
    `;

    toast.querySelector("button").addEventListener("click", () => {
        toast.remove();
    });

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateX(50px)";
        setTimeout(() => toast.remove(), 300);
    }, 6000);
}

// ------------------------------------------------------------
// 10. HELPER UTILITIES & DROPDOWNS
// ------------------------------------------------------------
function getProductImageURL(image) {
    if (!image) return "";
    const imagePath = String(image).trim();
    if (imagePath.startsWith("http://") || imagePath.startsWith("https://")) return imagePath;
    if (imagePath.startsWith("/uploads/")) return `${API_BASE}${imagePath}`;
    if (imagePath.startsWith("uploads/")) return `${API_BASE}/${imagePath}`;
    return `${API_BASE}/uploads/${imagePath}`;
}

function escapeHTML(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function setupDropdowns() {
    const notificationBtn = document.getElementById("notificationButton");
    const notificationDropdown = document.getElementById("notificationDropdown");
    const adminProfile = document.getElementById("adminProfile");
    const profileDropdown = document.getElementById("profileDropdown");
    const sidebarToggle = document.getElementById("sidebarToggle");
    const sidebar = document.getElementById("sidebar");

    if (notificationBtn && notificationDropdown) {
        notificationBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            notificationDropdown.classList.toggle("show");
            if (profileDropdown) profileDropdown.classList.remove("show");
        });
    }

    if (adminProfile && profileDropdown) {
        adminProfile.addEventListener("click", (e) => {
            e.stopPropagation();
            profileDropdown.classList.toggle("show");
            if (notificationDropdown) notificationDropdown.classList.remove("show");
        });
    }

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener("click", (e) => {
            e.stopPropagation();
            sidebar.classList.toggle("open");
        });
    }

    document.addEventListener("click", () => {
        if (notificationDropdown) notificationDropdown.classList.remove("show");
        if (profileDropdown) profileDropdown.classList.remove("show");
    });
}