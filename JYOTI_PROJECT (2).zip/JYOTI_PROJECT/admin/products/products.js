// ============================================================
// JYOTI ENTERPRISE - PRODUCTS MANAGEMENT
// ============================================================

const API_URL = "http://localhost:5000/api/products";
const SERVER_URL = "http://localhost:5000";
const FALLBACK_IMAGE = "../../assets/images/default-product.jpg";

function showPopup(message, type = "info") {
    let popup = document.getElementById("actionPopupMessage");
    if (!popup) {
        if (!document.getElementById("actionPopupGlowStyles")) {
            const style = document.createElement("style");
            style.id = "actionPopupGlowStyles";
            style.textContent = `
                @keyframes actionPopupGlow {
                    0%, 100% { box-shadow: 0 12px 32px rgba(15,23,42,.22), 0 0 0 rgba(34,197,94,0); }
                    50% { box-shadow: 0 12px 32px rgba(15,23,42,.22), 0 0 18px rgba(34,197,94,.35); }
                }
                #actionPopupMessage { animation: actionPopupGlow 1.8s ease-in-out infinite; }
                @media (prefers-reduced-motion: reduce) { #actionPopupMessage { animation: none; } }
            `;
            document.head.appendChild(style);
        }
        popup = document.createElement("div");
        popup.id = "actionPopupMessage";
        popup.setAttribute("role", "status");
        popup.setAttribute("aria-live", "polite");
        Object.assign(popup.style, {
            position: "fixed", top: "24px", right: "24px", zIndex: "10000",
            maxWidth: "min(420px, calc(100vw - 32px))", padding: "14px 20px",
            borderRadius: "12px", color: "#fff", font: "600 14px/1.5 Inter, sans-serif",
            whiteSpace: "pre-line", boxShadow: "0 12px 32px rgba(15,23,42,.22)",
            opacity: "0", transform: "translateY(-8px)", transition: "all .2s ease"
        });
        document.body.appendChild(popup);
    }
    popup.style.background = type === "error" ? "#dc2626" : "#16a34a";
    popup.textContent = message;
    popup.style.opacity = "1";
    popup.style.transform = "translateY(0)";
    clearTimeout(popup.hideTimer);
    popup.hideTimer = setTimeout(() => {
        popup.style.opacity = "0";
        popup.style.transform = "translateY(-8px)";
    }, 3500);
}

// ------------------------------------------------------------
// DOM ELEMENTS
// ------------------------------------------------------------

const productForm = document.getElementById("productForm");
const productModal = document.getElementById("productModal");
const addProductButton = document.getElementById("addProductButton");
const closeModal = document.getElementById("closeModal");
const cancelProduct = document.getElementById("cancelProduct");

const productImage = document.getElementById("productImage");
const imagePreview = document.getElementById("imagePreview");

const productTableBody = document.getElementById("productTableBody");

const productSearch = document.getElementById("productSearch");
const categoryFilter = document.getElementById("categoryFilter");
const statusFilter = document.getElementById("statusFilter");
const resetFilters = document.getElementById("resetFilters");

const totalProducts = document.getElementById("totalProducts");
const activeProducts = document.getElementById("activeProducts");
const lowStockProducts = document.getElementById("lowStockProducts");
const outOfStockProducts = document.getElementById("outOfStockProducts");

const resultCount = document.getElementById("resultCount");
const itemsPerPage = document.getElementById("itemsPerPage");

const paginationInfo = document.getElementById("paginationInfo");
const pageNumbers = document.getElementById("pageNumbers");
const previousPage = document.getElementById("previousPage");
const nextPage = document.getElementById("nextPage");

// ------------------------------------------------------------
// STATE
// ------------------------------------------------------------

let products = [];
let filteredProducts = [];
let currentPage = 1;
let currentItemsPerPage = 8;

// ------------------------------------------------------------
// INITIALIZATION
// ------------------------------------------------------------

document.addEventListener("DOMContentLoaded", () => {
    loadProducts();
    setupEventListeners();
});

function setupEventListeners() {
    if (addProductButton) addProductButton.addEventListener("click", openProductModal);
    if (closeModal) closeModal.addEventListener("click", closeProductModal);
    if (cancelProduct) cancelProduct.addEventListener("click", closeProductModal);
    if (productForm) productForm.addEventListener("submit", handleProductSubmit);
    if (productImage) productImage.addEventListener("change", handleImageSelection);
    if (productSearch) productSearch.addEventListener("input", applyFilters);
    if (categoryFilter) categoryFilter.addEventListener("change", applyFilters);
    if (statusFilter) statusFilter.addEventListener("change", applyFilters);
    if (resetFilters) resetFilters.addEventListener("click", resetProductFilters);

    if (productTableBody) {
        productTableBody.addEventListener("click", handleTableActions);
    }

    if (itemsPerPage) {
        itemsPerPage.addEventListener("change", () => {
            currentItemsPerPage = Number(itemsPerPage.value);
            currentPage = 1;
            renderProducts();
        });
    }

    if (previousPage) {
        previousPage.addEventListener("click", () => {
            if (currentPage > 1) {
                currentPage--;
                renderProducts();
            }
        });
    }

    if (nextPage) {
        nextPage.addEventListener("click", () => {
            const totalPages = Math.ceil(filteredProducts.length / currentItemsPerPage);
            if (currentPage < totalPages) {
                currentPage++;
                renderProducts();
            }
        });
    }
}

// ------------------------------------------------------------
// ACTION HANDLERS (VIEW / EDIT / DELETE)
// ------------------------------------------------------------

async function handleTableActions(event) {
    const button = event.target.closest(".action-button");
    if (!button) return;

    const productId = button.dataset.id;
    if (!productId) return;

    // VIEW
    if (button.classList.contains("view")) {
        let p = products.find(item => String(item.id) === String(productId));
        if (p) {
            showPopup(
                `Product Details:\n\n` +
                `ID: ${p.id}\n` +
                `Name: ${p.name}\n` +
                `SKU: ${p.sku}\n` +
                `Brand: ${p.brand || "N/A"}\n` +
                `Price: ₹${formatNumber(p.price)}\n` +
                `Stock: ${p.stock}\n` +
                `Status: ${p.status}\n` +
                `Description: ${p.description || "None"}`
            );
        }
    }

    // EDIT
    if (button.classList.contains("edit")) {
        let p = products.find(item => String(item.id) === String(productId));

        if (!p) {
            try {
                const res = await fetch(`${API_URL}/${productId}`);
                const data = await res.json();
                if (data.success) p = data.product;
            } catch (err) {
                console.error("Fetch error:", err);
            }
        }

        if (!p) {
            showPopup("Could not load product details.");
            return;
        }

        openProductModal();

        // Populate fields
        if (document.getElementById("productName")) document.getElementById("productName").value = p.name || "";
        if (document.getElementById("productCode")) document.getElementById("productCode").value = p.sku || "";
        if (document.getElementById("productCategory")) document.getElementById("productCategory").value = p.category || "";
        if (document.getElementById("productBrand")) document.getElementById("productBrand").value = p.brand || "";
        if (document.getElementById("productPrice")) document.getElementById("productPrice").value = p.price || "";
        if (document.getElementById("productQuantity")) document.getElementById("productQuantity").value = p.stock || "";
        if (document.getElementById("productMinimumStock")) document.getElementById("productMinimumStock").value = p.minimum_stock || "";
        if (document.getElementById("productDescription")) document.getElementById("productDescription").value = p.description || "";

        // Track edit state
        productForm.dataset.mode = "edit";
        productForm.dataset.editId = productId;

        const headerTitle = document.querySelector("#productModal .modal-header h2");
        if (headerTitle) headerTitle.textContent = "Edit Product";
    }

    // DELETE
    if (button.classList.contains("delete")) {
        const confirmed = confirm(`Are you sure you want to delete product #${productId}?`);
        if (!confirmed) return;

        try {
            const res = await fetch(`${API_URL}/${productId}`, { method: "DELETE" });
            const data = await res.json();
            if (data.success) {
                showPopup("Product deleted successfully!");
                await loadProducts();
            } else {
                showPopup(data.message || "Failed to delete product.");
            }
        } catch (err) {
            console.error("Delete error:", err);
            showPopup("Network error while deleting product.");
        }
    }
}

// ------------------------------------------------------------
// LOAD PRODUCTS
// ------------------------------------------------------------

async function loadProducts() {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error(`HTTP error: ${response.status}`);

        const data = await response.json();
        if (!data.success) throw new Error(data.message || "Failed to load");

        products = Array.isArray(data.products) ? data.products : [];
        filteredProducts = [...products];
        currentPage = 1;

        renderProducts();
        updateSummary();
    } catch (error) {
        console.error("Error loading products:", error);
        if (productTableBody) {
            productTableBody.innerHTML = `
                <tr>
                    <td colspan="8" style="text-align:center;padding:35px;color:#DC2626;">
                        Unable to connect to backend server. Make sure Python app.py is running.
                    </td>
                </tr>
            `;
        }
    }
}

// ------------------------------------------------------------
// MODAL CONTROLS
// ------------------------------------------------------------

function openProductModal() {
    if (!productModal) return;
    productModal.classList.add("show");
    if (productForm) {
        productForm.reset();
        delete productForm.dataset.mode;
        delete productForm.dataset.editId;
    }
    const headerTitle = document.querySelector("#productModal .modal-header h2");
    if (headerTitle) headerTitle.textContent = "Add Product";

    if (imagePreview) {
        imagePreview.style.display = "none";
        imagePreview.innerHTML = "";
    }
    if (productImage) productImage.value = "";
}

function closeProductModal() {
    if (!productModal) return;
    productModal.classList.remove("show");
    if (productForm) {
        productForm.reset();
        delete productForm.dataset.mode;
        delete productForm.dataset.editId;
    }
    if (imagePreview) {
        imagePreview.style.display = "none";
        imagePreview.innerHTML = "";
    }
    if (productImage) productImage.value = "";
}

function handleImageSelection(event) {
    const file = event.target.files[0];
    if (!file) {
        if (imagePreview) imagePreview.style.display = "none";
        return;
    }

    const allowedTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
        showPopup("Only JPG, JPEG, PNG, and WEBP images are allowed.");
        productImage.value = "";
        if (imagePreview) imagePreview.style.display = "none";
        return;
    }

    const previewURL = URL.createObjectURL(file);
    if (imagePreview) {
        imagePreview.style.display = "block";
        imagePreview.innerHTML = `<img src="${previewURL}" alt="Preview">`;
    }
}

// ------------------------------------------------------------
// FORM SUBMISSION (ADD / EDIT)
// ------------------------------------------------------------

async function handleProductSubmit(event) {
    event.preventDefault();

    try {
        const isEdit = productForm.dataset.mode === "edit";
        const editId = productForm.dataset.editId;

        const name = document.getElementById("productName")?.value.trim();
        const sku = document.getElementById("productCode")?.value.trim();
        const category = document.getElementById("productCategory")?.value;
        const brand = document.getElementById("productBrand")?.value.trim();
        const price = document.getElementById("productPrice")?.value;
        const stock = document.getElementById("productQuantity")?.value;
        const minimumStock = document.getElementById("productMinimumStock")?.value;
        const description = document.getElementById("productDescription")?.value.trim();

        if (!name || !sku || price === "" || stock === "") {
            showPopup("Please fill out all required fields.");
            return;
        }

        const formData = new FormData();
        formData.append("productName", name);
        formData.append("productCode", sku);
        formData.append("productCategory", category || "");
        formData.append("productBrand", brand || "");
        formData.append("productPrice", price);
        formData.append("productQuantity", stock);
        formData.append("productMinimumStock", minimumStock || "0");
        formData.append("productStatus", Number(stock) > 0 ? "In Stock" : "Out of Stock");
        formData.append("productDescription", description);

        const imageInput = document.getElementById("productImage");
        if (imageInput && imageInput.files.length > 0) {
            formData.append("productImage", imageInput.files[0]);
        }

        const url = isEdit ? `${API_URL}/${editId}` : API_URL;
        const response = await fetch(url, {
            method: "POST",
            body: formData
        });

        const data = await response.json();
        if (!response.ok || !data.success) {
            throw new Error(data.message || "Failed to save product.");
        }

        showPopup(isEdit ? "Product updated successfully!" : "Product added successfully!");
        closeProductModal();
        await loadProducts();
    } catch (error) {
        console.error("Save product error:", error);
        showPopup(error.message || "Unable to save product.");
    }
}

// ------------------------------------------------------------
// FILTERING & PAGINATION
// ------------------------------------------------------------

function applyFilters() {
    const searchText = productSearch?.value.trim().toLowerCase() || "";
    const selectedCategory = categoryFilter?.value || "";
    const selectedStatus = statusFilter?.value || "";

    filteredProducts = products.filter(product => {
        const name = String(product.name || "").toLowerCase();
        const sku = String(product.sku || "").toLowerCase();
        const brand = String(product.brand || "").toLowerCase();
        const category = String(product.category || "");
        const status = String(product.status || "");

        const matchesSearch = !searchText || name.includes(searchText) || sku.includes(searchText) || brand.includes(searchText);
        const matchesCategory = !selectedCategory || category === selectedCategory;
        const matchesStatus = !selectedStatus || status === selectedStatus;

        return matchesSearch && matchesCategory && matchesStatus;
    });

    currentPage = 1;
    renderProducts();
}

function resetProductFilters() {
    if (productSearch) productSearch.value = "";
    if (categoryFilter) categoryFilter.value = "";
    if (statusFilter) statusFilter.value = "";

    filteredProducts = [...products];
    currentPage = 1;
    renderProducts();
}

function renderProducts() {
    if (!productTableBody) return;

    const totalPages = Math.max(1, Math.ceil(filteredProducts.length / currentItemsPerPage));
    if (currentPage > totalPages) currentPage = totalPages;

    const startIndex = (currentPage - 1) * currentItemsPerPage;
    const pageProducts = filteredProducts.slice(startIndex, startIndex + currentItemsPerPage);

    if (pageProducts.length === 0) {
        productTableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align:center;padding:30px;">
                    No products found.
                </td>
            </tr>
        `;
    } else {
        productTableBody.innerHTML = pageProducts.map(product => {
            const imageURL = getProductImageURL(product.image);

            return `
                <tr>
                    <td>
                        <input type="checkbox" class="product-checkbox" value="${product.id}">
                    </td>
                    <td>${product.id ?? ""}</td>
                    <td>
                        <div class="product-cell">
                            <img 
                                src="${imageURL || FALLBACK_IMAGE}" 
                                alt="${escapeHTML(product.name || "Product")}" 
                                class="product-table-img" 
                                onerror="this.onerror=null; this.src='${FALLBACK_IMAGE}';"
                            />
                            <div class="product-name">
                                <strong>${escapeHTML(product.name || "")}</strong>
                                <span>${escapeHTML(product.sku || "")}</span>
                            </div>
                        </div>
                    </td>
                    <td>${escapeHTML(product.brand || "")}</td>
                    <td class="price">₹${formatNumber(product.price)}</td>
                    <td class="stock-number">${product.stock ?? 0}</td>
                    <td>
                        <span class="status-badge ${String(product.status || '').toLowerCase().replace(/\s+/g, '-')}">
                            ${escapeHTML(product.status || "In Stock")}
                        </span>
                    </td>
                    <td>
                        <div class="action-buttons">
                            <button type="button" class="action-button view" data-id="${product.id}" title="View">
                                <i class="fa-solid fa-eye" style="pointer-events: none;"></i>
                            </button>
                            <button type="button" class="action-button edit" data-id="${product.id}" title="Edit">
                                <i class="fa-solid fa-pen-to-square" style="pointer-events: none;"></i>
                            </button>
                            <button type="button" class="action-button delete" data-id="${product.id}" title="Delete">
                                <i class="fa-solid fa-trash" style="pointer-events: none;"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join("");
    }

    updatePagination(totalPages);
}

function getProductImageURL(image) {
    if (!image) return "";
    const imagePath = String(image).trim();
    if (imagePath.startsWith("http://") || imagePath.startsWith("https://")) return imagePath;
    if (imagePath.startsWith("/uploads/")) return `${SERVER_URL}${imagePath}`;
    if (imagePath.startsWith("uploads/")) return `${SERVER_URL}/${imagePath}`;
    return `${SERVER_URL}/uploads/${imagePath}`;
}

function updateSummary() {
    if (totalProducts) totalProducts.textContent = products.length;

    const activeCount = products.filter(p => String(p.status || "").toLowerCase() === "in stock").length;
    const lowStockCount = products.filter(p => String(p.status || "").toLowerCase() === "low stock").length;
    const outOfStockCount = products.filter(p => String(p.status || "").toLowerCase() === "out of stock").length;

    if (activeProducts) activeProducts.textContent = activeCount;
    if (lowStockProducts) lowStockProducts.textContent = lowStockCount;
    if (outOfStockProducts) outOfStockProducts.textContent = outOfStockCount;
}

function updatePagination(totalPages) {
    if (paginationInfo) paginationInfo.textContent = `Page ${currentPage} of ${totalPages}`;

    if (resultCount) {
        const total = filteredProducts.length;
        if (total === 0) {
            resultCount.textContent = "Showing 0 products";
        } else {
            const start = (currentPage - 1) * currentItemsPerPage + 1;
            const end = Math.min(currentPage * currentItemsPerPage, total);
            resultCount.textContent = `Showing ${start}–${end} of ${total} products`;
        }
    }

    if (previousPage) previousPage.disabled = currentPage <= 1;
    if (nextPage) nextPage.disabled = currentPage >= totalPages;

    if (pageNumbers) {
        pageNumbers.innerHTML = "";
        for (let page = 1; page <= totalPages; page++) {
            const button = document.createElement("button");
            button.type = "button";
            button.className = `page-number ${page === currentPage ? "active" : ""}`;
            button.textContent = page;
            button.addEventListener("click", () => {
                currentPage = page;
                renderProducts();
            });
            pageNumbers.appendChild(button);
        }
    }
}

function escapeHTML(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function formatNumber(value) {
    const number = Number(value);
    return Number.isNaN(number) ? "0.00" : number.toFixed(2);
}

