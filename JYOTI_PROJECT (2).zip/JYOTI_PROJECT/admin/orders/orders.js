// ============================================================
// JYOTI ENTERPRISE - ORDERS MANAGEMENT
// ============================================================

const ORDERS_API_URL = "http://127.0.0.1:5000/api/orders";
let ordersData = [];

let selectedOrder = null;

// DOM Elements
const ordersTableBody = document.getElementById("ordersTableBody");
const orderSearchInput = document.getElementById("orderSearchInput");
const statusFilter = document.getElementById("statusFilter");
const resetSearch = document.getElementById("resetSearch");
const orderResultCount = document.getElementById("orderResultCount");

// Metrics
const totalOrdersCount = document.getElementById("totalOrdersCount");
const pendingOrdersCount = document.getElementById("pendingOrdersCount");
const completedOrdersCount = document.getElementById("completedOrdersCount");
const totalRevenueAmount = document.getElementById("totalRevenueAmount");

// Modal Elements
const orderDetailsModal = document.getElementById("orderDetailsModal");
const closeOrderModal = document.getElementById("closeOrderModal");
const closeModalBtn = document.getElementById("closeModalBtn");
const saveOrderStatusBtn = document.getElementById("saveOrderStatusBtn");
const updateStatusSelect = document.getElementById("updateStatusSelect");

document.addEventListener("DOMContentLoaded", () => {
    fetchOrders();
    setupEventListeners();
});

function setupEventListeners() {
    if (orderSearchInput) orderSearchInput.addEventListener("input", filterAndRenderOrders);
    if (statusFilter) statusFilter.addEventListener("change", filterAndRenderOrders);

    if (resetSearch) {
        resetSearch.addEventListener("click", () => {
            if (orderSearchInput) orderSearchInput.value = "";
            if (statusFilter) statusFilter.value = "ALL";
            filterAndRenderOrders();
        });
    }

    if (closeOrderModal) closeOrderModal.addEventListener("click", () => orderDetailsModal.classList.remove("show"));
    if (closeModalBtn) closeModalBtn.addEventListener("click", () => orderDetailsModal.classList.remove("show"));

    if (saveOrderStatusBtn) {
        saveOrderStatusBtn.addEventListener("click", updateCurrentOrderStatus);
    }
}

async function fetchOrders() {
    try {
        const res = await fetch(ORDERS_API_URL);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data && data.success && Array.isArray(data.orders)) {
            ordersData = data.orders.map(normalizeOrder);
        } else {
            throw new Error(data.message || "Could not load orders");
        }
    } catch (e) {
        console.error("Could not load orders from the backend.", e);
        ordersData = [];
    }
    filterAndRenderOrders();
}

function normalizeOrder(order) {
    const statusMap = {
        confirmed: "Awaiting Pickup",
        pending: "Awaiting Pickup",
        processing: "Ready for Pickup",
        delivered: "Collected"
    };
    const savedStatus = String(order.status || "Awaiting Pickup");
    const normalizedStatus = statusMap[savedStatus.toLowerCase()] || savedStatus;

    return {
        ...order,
        id: String(order.id),
        customer: {
            name: order.customer?.name || order.customer_name || "Customer",
            email: order.customer?.email || order.customer_email || "",
            phone: order.customer?.phone || order.customer_phone || ""
        },
        items: Array.isArray(order.items) ? order.items : [],
        total: Number(order.total ?? order.total_amount) || 0,
        date: order.date || order.created_at || "",
        status: normalizedStatus,
        fulfillment_type: order.fulfillment_type || "store_pickup",
        pickup_location: "Jyoti Enterprise Counter, Main Branch"
    };
}

function filterAndRenderOrders() {
    const term = (orderSearchInput?.value || "").toLowerCase().trim();
    const statusVal = statusFilter?.value || "ALL";

    const filtered = ordersData.filter(ord => {
        const matchesSearch =
            ord.id.toLowerCase().includes(term) ||
            ord.customer.name.toLowerCase().includes(term) ||
            ord.customer.email.toLowerCase().includes(term) ||
            ord.customer.phone.includes(term);

        const matchesStatus = statusVal === "ALL" || ord.status.toLowerCase() === statusVal.toLowerCase();

        return matchesSearch && matchesStatus;
    });

    renderTable(filtered);
    updateMetrics(ordersData);
}

function renderTable(list) {
    if (!ordersTableBody) return;
    ordersTableBody.innerHTML = "";

    if (list.length === 0) {
        ordersTableBody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align: center; padding: 30px; color: #94A3B8;">
                    No pickup orders match your criteria.
                </td>
            </tr>`;
        if (orderResultCount) orderResultCount.textContent = "Showing 0 orders";
        return;
    }

    list.forEach(order => {
        const itemCount = order.items.reduce((sum, itm) => sum + (Number(itm.quantity) || 1), 0);
        const statusClass = order.status.toLowerCase().replace(/[^a-z]+/g, "-");
        const tr = document.createElement("tr");

        tr.innerHTML = `
            <td><strong>#${order.id}</strong></td>
            <td>
                <div class="customer-info-cell">
                    <strong>${escapeHTML(order.customer.name)}</strong>
                    <span>${escapeHTML(order.customer.phone || order.customer.email || "Pickup customer")}</span>
                </div>
            </td>
            <td><span class="fulfillment-pill"><i class="fa-solid fa-store"></i> Store pickup</span></td>
            <td>${itemCount} ${itemCount === 1 ? 'item' : 'items'}</td>
            <td><strong>₹${Number(order.total).toLocaleString('en-IN')}</strong></td>
            <td>${escapeHTML(formatOrderDate(order.date))}</td>
            <td><span class="status-pill ${statusClass}">${escapeHTML(order.status)}</span></td>
            <td>
                <button class="view-btn" data-order-id="${escapeHTML(order.id)}">
                    <i class="fa-solid fa-eye"></i> View Details
                </button>
            </td>
        `;
        ordersTableBody.appendChild(tr);
    });

    if (orderResultCount) orderResultCount.textContent = `Showing ${list.length} orders`;
}

function formatOrderDate(value) {
    if (!value) return "—";
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("en-IN");
}

function updateMetrics(list) {
    if (totalOrdersCount) totalOrdersCount.textContent = list.length;
    if (pendingOrdersCount) {
        pendingOrdersCount.textContent = list.filter(o => o.status === "Awaiting Pickup" || o.status === "Ready for Pickup").length;
    }
    if (completedOrdersCount) {
        completedOrdersCount.textContent = list.filter(o => o.status === "Collected").length;
    }
    if (totalRevenueAmount) {
        const revenue = list
            .filter(o => o.status.toLowerCase() !== "cancelled")
            .reduce((sum, o) => sum + Number(o.total || 0), 0);
        totalRevenueAmount.textContent = `₹${revenue.toLocaleString('en-IN')}`;
    }
}

window.openOrderModal = function(orderId) {
    selectedOrder = ordersData.find(o => String(o.id) === String(orderId));
    if (!selectedOrder) return;

    document.getElementById("modalOrderId").textContent = `Order #${selectedOrder.id}`;
    document.getElementById("modalCustomerName").textContent = selectedOrder.customer.name;
    document.getElementById("modalCustomerEmail").textContent = selectedOrder.customer.email;
    document.getElementById("modalCustomerPhone").textContent = selectedOrder.customer.phone;
    document.getElementById("modalShippingAddress").textContent = selectedOrder.pickup_location;
    document.getElementById("modalOrderDate").textContent = selectedOrder.date;
    document.getElementById("updateStatusSelect").value = selectedOrder.status;

    const itemsTbody = document.getElementById("modalItemsTableBody");
    itemsTbody.innerHTML = "";

    selectedOrder.items.forEach(itm => {
        const row = document.createElement("tr");
        const subtotal = (itm.price * itm.quantity);
        row.innerHTML = `
            <td>${escapeHTML(itm.name)}</td>
            <td>₹${itm.price}</td>
            <td>${itm.quantity}</td>
            <td style="text-align: right; font-weight: 600;">₹${subtotal}</td>
        `;
        itemsTbody.appendChild(row);
    });

    document.getElementById("modalGrandTotal").textContent = `₹${Number(selectedOrder.total).toLocaleString('en-IN')}`;
    orderDetailsModal.classList.add("show");
};

async function updateCurrentOrderStatus() {
    if (!selectedOrder) return;
    const newStatus = updateStatusSelect.value;
    if (saveOrderStatusBtn) {
        saveOrderStatusBtn.disabled = true;
        saveOrderStatusBtn.textContent = "Saving...";
    }

    try {
        const response = await fetch(`${ORDERS_API_URL}/${selectedOrder.id}/status`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: newStatus })
        });
        const result = await response.json();
        if (!response.ok || !result.success) {
            throw new Error(result.message || "Could not update pickup status");
        }

        selectedOrder.status = newStatus;
    } catch (e) {
        alert(e.message || "Could not update the order status. Check the backend connection.");
        return;
    } finally {
        if (saveOrderStatusBtn) {
            saveOrderStatusBtn.disabled = false;
            saveOrderStatusBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i> Update Status';
        }
    }

    orderDetailsModal.classList.remove("show");
    filterAndRenderOrders();
}

if (ordersTableBody) {
    ordersTableBody.addEventListener("click", event => {
        const button = event.target.closest("[data-order-id]");
        if (button) window.openOrderModal(button.dataset.orderId);
    });
}

function escapeHTML(str) {
    return String(str).replace(/[&<>'"]/g, t => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[t] || t));
}