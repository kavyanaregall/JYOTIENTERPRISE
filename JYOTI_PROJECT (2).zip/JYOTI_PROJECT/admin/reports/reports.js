document.addEventListener("DOMContentLoaded", () => {
    // Explicit backend endpoint
    const API_ENDPOINT = "http://127.0.0.1:5000/api/admin/reports/analytics";

    let orderStatusChart = null;
    let categorySalesChart = null;
    let stockCategoryChart = null;
    let productDataset = [];
    let orderLogDataset = [];
    let categorySalesDataset = [];
    let stockCategoryDataset = [];

    const formatINR = (val) => new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 2
    }).format(val || 0);

    const setElText = (id, text) => {
        const el = document.getElementById(id);
        if (el) el.textContent = text;
    };

    async function fetchAnalytics() {
        try {
            console.log("Connecting to:", API_ENDPOINT);
            const res = await fetch(API_ENDPOINT);
            if (!res.ok) {
                const errText = await res.text();
                throw new Error(`Server returned HTTP ${res.status}: ${errText}`);
            }

            const data = await res.json();
            if (!data.success) throw new Error(data.message || "Failed response from server");

            const k = data.kpis || {};

            // 1. Render Order & Confirmation Metrics
            setElText("kpiTotalOrders", (k.total_orders_placed || 0).toLocaleString());
            setElText("kpiConfirmed", (k.count_confirmed_ready || 0).toLocaleString());
            setElText("kpiPending", (k.count_awaiting_pickup || 0).toLocaleString());
            setElText("kpiCollected", (k.count_collected || 0).toLocaleString());
            setElText("kpiCancelled", (k.count_cancelled || 0).toLocaleString());

            // 2. Render Financial & Inventory Metrics
            setElText("kpiRevenue", formatINR(k.total_revenue));
            setElText("kpiCollectedRevenue", formatINR(k.collected_revenue));
            setElText("kpiUnitsSold", (k.total_units_sold || 0).toLocaleString());
            setElText("kpiStockUnits", `${(k.total_stock_units || 0).toLocaleString()} units`);
            setElText("kpiStockValuation", formatINR(k.total_stock_value));

            // 3. Render Charts safely inside try/catch blocks
            try { renderOrderStatusChart(k); } catch(e) { console.warn("Chart 1 render error:", e); }
            try { renderCategorySalesChart(data.category_sales || []); } catch(e) { console.warn("Chart 2 render error:", e); }
            try { renderStockBarChart(data.stock_by_category || []); } catch(e) { console.warn("Chart 3 render error:", e); }

            // 4. Render Orders Log
            orderLogDataset = data.orders_log || [];
            renderOrdersLogTable(orderLogDataset);
            setElText("orderLogCount", `Showing ${orderLogDataset.length} orders`);

            // 5. Render Product Table
            productDataset = data.product_breakdown || [];
            renderProductTable(productDataset);

            // 6. Keep datasets for CSV export
            categorySalesDataset = data.category_sales || [];
            stockCategoryDataset = data.stock_by_category || [];

        } catch (err) {
            console.error("Dashboard Loading Error:", err);
            const errHtml = `<tr><td colspan="7" style="text-align: center; color: #dc2626; padding: 2rem;"><strong>Error:</strong> ${err.message}</td></tr>`;
            const ordBody = document.getElementById("ordersReportTableBody");
            const prodBody = document.getElementById("productReportBody");
            if (ordBody) ordBody.innerHTML = errHtml;
            if (prodBody) prodBody.innerHTML = errHtml;
        }
    }

    function renderOrderStatusChart(kpis) {
        const canvas = document.getElementById("orderStatusChart");
        if (!canvas || typeof Chart === "undefined") return;
        if (orderStatusChart) orderStatusChart.destroy();

        const dataVals = [
            kpis.count_confirmed_ready || 0,
            kpis.count_awaiting_pickup || 0,
            kpis.count_collected || 0,
            kpis.count_cancelled || 0
        ];
        const total = dataVals.reduce((a, b) => a + b, 0);

        orderStatusChart = new Chart(canvas.getContext("2d"), {
            type: "doughnut",
            data: {
                labels: total > 0 ? ["Ready (Confirmed)", "Awaiting Pickup", "Collected", "Cancelled"] : ["No Orders Yet"],
                datasets: [{
                    data: total > 0 ? dataVals : [1],
                    backgroundColor: total > 0 ? ["#7c3aed", "#f59e0b", "#10b981", "#ef4444"] : ["#cbd5e1"]
                }]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: "bottom" } } }
        });
    }

    function renderCategorySalesChart(categories) {
        const canvas = document.getElementById("categorySalesChart");
        if (!canvas || typeof Chart === "undefined") return;
        if (categorySalesChart) categorySalesChart.destroy();

        const labels = categories.length ? categories.map(c => c.category) : ["No Sales Data"];
        const dataVals = categories.length ? categories.map(c => c.total_sales_amount) : [1];
        const colors = ["#2563eb", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6", "#64748b"];

        categorySalesChart = new Chart(canvas.getContext("2d"), {
            type: "pie",
            data: {
                labels: labels,
                datasets: [{
                    data: dataVals,
                    backgroundColor: categories.length ? colors.slice(0, labels.length) : ["#cbd5e1"]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: "bottom" },
                    tooltip: { callbacks: { label: (ctx) => ` ${ctx.label}: ${formatINR(ctx.raw)}` } }
                }
            }
        });
    }

    function renderStockBarChart(categories) {
        const canvas = document.getElementById("stockCategoryChart");
        if (!canvas || typeof Chart === "undefined") return;
        if (stockCategoryChart) stockCategoryChart.destroy();

        const labels = categories.map(c => c.category);
        const dataVals = categories.map(c => c.stock_qty);

        stockCategoryChart = new Chart(canvas.getContext("2d"), {
            type: "bar",
            data: {
                labels: labels,
                datasets: [{ label: "Stock Units", data: dataVals, backgroundColor: "#3b82f6", borderRadius: 4 }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    function renderOrdersLogTable(orders) {
        const tbody = document.getElementById("ordersReportTableBody");
        if (!tbody) return;
        if (!orders.length) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 2rem;">No orders found.</td></tr>`;
            return;
        }

        tbody.innerHTML = orders.map(ord => {
            let statusClass = "awaiting";
            const st = (ord.status || "").toLowerCase();
            if (st.includes("collected")) statusClass = "collected";
            else if (st.includes("cancel")) statusClass = "cancelled";
            else if (st.includes("ready")) statusClass = "ready";

            return `
                <tr>
                    <td><strong>#${ord.id}</strong></td>
                    <td><strong>${ord.customer_name || 'Customer'}</strong><br/><small style="color:#64748b;">${ord.customer_phone || '-'}</small></td>
                    <td><span class="badge-pickup"><i class="fa-solid fa-store" style="font-size:10px;"></i> ${ord.fulfillment_type || 'Store pickup'}</span></td>
                    <td>${ord.items_count || 1} items</td>
                    <td><strong>${formatINR(ord.total_amount)}</strong></td>
                    <td><small style="color:#475569;">${ord.formatted_date || '-'}</small></td>
                    <td><span class="status-pill ${statusClass}">${ord.status}</span></td>
                </tr>
            `;
        }).join("");
    }

    function renderProductTable(products) {
        const tbody = document.getElementById("productReportBody");
        if (!tbody) return;
        if (!products.length) {
            tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; padding: 2rem;">No products found.</td></tr>`;
            return;
        }

        tbody.innerHTML = products.map(p => {
            const isStocked = p.stock > 0;
            const stockStatus = isStocked
                ? (p.stock <= 10 ? `<span class="status-pill awaiting">Low Stock (${p.stock})</span>` : `<span class="status-pill collected">In Stock</span>`)
                : `<span class="status-pill cancelled">Out of Stock</span>`;

            return `
                <tr>
                    <td><strong>${p.name}</strong></td>
                    <td>${p.category_name}</td>
                    <td><span class="badge-qty">${p.stock} units</span></td>
                    <td>${formatINR(p.price)}</td>
                    <td><strong>${p.total_units_sold}</strong></td>
                    <td><strong>${formatINR(p.total_sales_value)}</strong></td>
                    <td>${stockStatus}</td>
                </tr>
            `;
        }).join("");
    }

    // ---------- CSV Export ----------
    const csvCell = (val) => {
        const s = String(val == null ? "" : val);
        return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };

    const toCsv = (headers, rows) =>
        [headers.map(csvCell).join(","), ...rows.map(r => r.map(csvCell).join(","))].join("\n");

    function downloadCsv() {
        const sections = [];

        if (orderLogDataset.length) {
            sections.push("ORDERS LOG\n" + toCsv(
                ["Order ID", "Customer", "Phone", "Fulfillment", "Items", "Total Amount", "Date", "Status"],
                orderLogDataset.map(o => [
                    o.id, o.customer_name, o.customer_phone,
                    o.fulfillment_type, o.items_count,
                    o.total_amount, o.formatted_date, o.status
                ])
            ));
        }

        if (productDataset.length) {
            sections.push("PRODUCT PERFORMANCE & INVENTORY\n" + toCsv(
                ["Product", "Category", "Stock Units", "Unit Price", "Units Sold", "Total Sales", "Stock Status"],
                productDataset.map(p => [
                    p.name, p.category_name, p.stock, p.price,
                    p.total_units_sold, p.total_sales_value,
                    p.stock > 0 ? (p.stock <= 10 ? "Low Stock" : "In Stock") : "Out of Stock"
                ])
            ));
        }

        if (categorySalesDataset.length) {
            sections.push("CATEGORY SALES\n" + toCsv(
                ["Category", "Units Sold", "Total Sales Amount"],
                categorySalesDataset.map(c => [c.category, c.units_sold, c.total_sales_amount])
            ));
        }

        if (stockCategoryDataset.length) {
            sections.push("STOCK BY CATEGORY\n" + toCsv(
                ["Category", "Products", "Stock Units"],
                stockCategoryDataset.map(c => [c.category, c.product_count, c.stock_qty])
            ));
        }

        if (!sections.length) {
            alert("No report data available to export yet.");
            return;
        }

        const blob = new Blob(["\uFEFF" + sections.join("\n\n")], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `jyoti-reports-${new Date().toISOString().slice(0, 10)}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // ---------- Product table filter ----------
    function applyProductFilter(term) {
        const q = String(term || "").trim().toLowerCase();
        const rows = !q
            ? productDataset
            : productDataset.filter(p =>
                String(p.name || "").toLowerCase().includes(q) ||
                String(p.category_name || "").toLowerCase().includes(q)
            );
        renderProductTable(rows);
    }

    const csvBtn = document.getElementById("downloadCsvBtn");
    if (csvBtn) csvBtn.addEventListener("click", downloadCsv);

    const filterInput = document.getElementById("filterInput");
    if (filterInput) filterInput.addEventListener("input", (e) => applyProductFilter(e.target.value));

    fetchAnalytics();
});