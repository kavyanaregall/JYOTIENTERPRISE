/* =========================================================
   JYOTI ENTERPRISE
   CUSTOMER CART CONTROLLER (EXACT HTML ID MATCH)
========================================================= */

// 1. Target exact elements from cart.html
const cartItemsContainer = document.getElementById("cartItems");
const emptyCartContainer = document.getElementById("emptyCart");
const cartItemCountEl = document.getElementById("cartItemCount");
const subtotalEl = document.getElementById("subtotal");
const deliveryEl = document.getElementById("delivery");
const totalEl = document.getElementById("total");
const checkoutBtn = document.getElementById("checkoutButton");

// 2. Load Cart from Storage
let cart = JSON.parse(localStorage.getItem("jyotiCart")) || [];

/* =========================================================
   RENDER CART FUNCTION
========================================================= */
function renderCart() {
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Update item count badge
  if (cartItemCountEl) {
    cartItemCountEl.textContent = `${totalCount} item${totalCount === 1 ? "" : "s"}`;
  }

  // Handle empty state
  if (cart.length === 0) {
    if (emptyCartContainer) emptyCartContainer.style.display = "block";
    if (cartItemsContainer) {
      cartItemsContainer.style.display = "none";
      cartItemsContainer.innerHTML = "";
    }
    updateSummary(0);
    if (checkoutBtn) {
      checkoutBtn.disabled = true;
      checkoutBtn.style.opacity = "0.5";
      checkoutBtn.style.cursor = "not-allowed";
    }
    return;
  }

  // Show items list and hide empty state
  if (emptyCartContainer) emptyCartContainer.style.display = "none";
  if (cartItemsContainer) {
    cartItemsContainer.style.display = "block";
    cartItemsContainer.innerHTML = cart
      .map(
        (item) => `
      <div class="cart-item" style="
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 16px 0;
        border-bottom: 1px solid #E2E8F0;
        gap: 16px;
      ">
        <div style="display: flex; align-items: center; gap: 14px;">
          <div style="
            width: 48px;
            height: 48px;
            background: #F1F5F9;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
          ">
            ${item.fallback || "📦"}
          </div>
          <div>
            <h4 style="margin: 0 0 4px 0; font-size: 15px; color: #1E293B;">${item.name}</h4>
            <span style="font-size: 13px; color: #64748B;">₹${parseFloat(item.price).toFixed(2)} each</span>
          </div>
        </div>

        <div style="display: flex; align-items: center; gap: 16px;">
          <!-- Quantity Controls -->
          <div style="
            display: inline-flex;
            align-items: center;
            border: 1px solid #CBD5E1;
            border-radius: 6px;
            overflow: hidden;
            background: #fff;
          ">
            <button type="button" onclick="modifyQty(${item.id}, -1)" style="
              border: none;
              background: #F8FAFC;
              padding: 6px 12px;
              cursor: pointer;
              font-size: 14px;
              font-weight: bold;
            ">-</button>
            <span style="padding: 0 10px; font-size: 13px; font-weight: 600;">${item.quantity}</span>
            <button type="button" onclick="modifyQty(${item.id}, 1)" style="
              border: none;
              background: #F8FAFC;
              padding: 6px 12px;
              cursor: pointer;
              font-size: 14px;
              font-weight: bold;
            ">+</button>
          </div>

          <!-- Line Item Total -->
          <strong style="min-width: 75px; text-align: right; color: #0F172A; font-size: 14px;">
            ₹${(item.price * item.quantity).toFixed(2)}
          </strong>

          <!-- Remove Item -->
          <button type="button" onclick="deleteCartItem(${item.id})" title="Remove item" style="
            border: none;
            background: transparent;
            color: #EF4444;
            font-size: 18px;
            cursor: pointer;
            padding: 4px 8px;
          ">&times;</button>
        </div>
      </div>
    `
      )
      .join("");
  }

  // Calculate Subtotal & Update Summary
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  updateSummary(subtotal);

  if (checkoutBtn) {
    checkoutBtn.disabled = false;
    checkoutBtn.style.opacity = "1";
    checkoutBtn.style.cursor = "pointer";
  }
}

/* =========================================================
   QUANTITY & REMOVE ACTIONS
========================================================= */
function modifyQty(productId, change) {
  const item = cart.find((i) => i.id === productId);
  if (!item) return;

  item.quantity += change;

  if (item.quantity <= 0) {
    deleteCartItem(productId);
    return;
  }

  saveCart();
  renderCart();
}

function deleteCartItem(productId) {
  cart = cart.filter((i) => i.id !== productId);
  saveCart();
  renderCart();
}

function saveCart() {
  localStorage.setItem("jyotiCart", JSON.stringify(cart));
}

/* =========================================================
   ORDER SUMMARY CALCULATIONS
========================================================= */
function updateSummary(subtotal) {
  const pickupFee = 0;
  const grandTotal = subtotal + pickupFee;

  if (subtotalEl) subtotalEl.textContent = `₹${subtotal.toFixed(0)}`;
  if (deliveryEl) deliveryEl.textContent = "Store pickup · Free";
  if (totalEl) totalEl.textContent = `₹${grandTotal.toFixed(0)}`;
}

function goToCheckout() {
  if (cart.length === 0) {
    return;
  }

  window.location.href = "../checkout/checkout.html";
}

/* =========================================================
   INITIALIZE ON PAGE LOAD
========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  renderCart();

  if (checkoutBtn) {
    checkoutBtn.addEventListener("click", goToCheckout);
  }
});