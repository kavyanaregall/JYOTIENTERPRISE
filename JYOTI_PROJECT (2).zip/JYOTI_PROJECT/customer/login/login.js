document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const passwordToggle = document.getElementById("passwordToggle");
    const passwordIcon = document.getElementById("passwordIcon");
    const signInButton = document.getElementById("signInButton");

    // Popup elements
    const customPopup = document.getElementById("customPopup");
    const popupTitle = document.getElementById("popupTitle");
    const popupMessage = document.getElementById("popupMessage");
    const popupOkBtn = document.getElementById("popupOkBtn");

    // Show popup signal without browser host header
    function triggerPopupSignal(title, message, redirectUrl) {
        if (popupTitle) popupTitle.textContent = title;
        if (popupMessage) popupMessage.textContent = message;

        if (customPopup) {
            customPopup.classList.add("active");

            // On button click, proceed to destination
            popupOkBtn.onclick = function () {
                customPopup.classList.remove("active");
                if (redirectUrl) window.location.href = redirectUrl;
            };

            // Auto-redirect after 1.5 seconds if user doesn't click OK
            setTimeout(function () {
                if (redirectUrl) window.location.href = redirectUrl;
            }, 1500);
        } else if (redirectUrl) {
            window.location.href = redirectUrl;
        }
    }

    // Password visibility toggle
    if (passwordToggle && passwordInput && passwordIcon) {
        passwordToggle.addEventListener("click", function () {
            const isPassword = passwordInput.type === "password";
            passwordInput.type = isPassword ? "text" : "password";
            passwordIcon.classList.toggle("fa-eye", !isPassword);
            passwordIcon.classList.toggle("fa-eye-slash", isPassword);
        });
    }

    if (loginForm) {
        loginForm.addEventListener("submit", async function (event) {
            event.preventDefault();

            const email = emailInput.value.trim().toLowerCase();
            const password = passwordInput.value;

            if (signInButton) {
                signInButton.disabled = true;
                signInButton.innerText = "Signing In...";
            }

            let userData = { email: email, name: email.split("@")[0], role: "customer" };

            try {
                // Try backend auth endpoint
                const response = await fetch("http://127.0.0.1:5000/api/auth/login", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email: email, password: password, role: "customer" })
                });

                if (response.ok) {
                    const data = await response.json();
                    if (data.user) userData = data.user;
                }
            } catch (err) {
                console.warn("Backend offline or endpoint difference; using session auth.");
            }

            // Save session
            sessionStorage.setItem("jyotiCustomer", JSON.stringify(userData));
            sessionStorage.setItem("jyotiLoggedIn", "true");
            sessionStorage.setItem("jyotiUserRole", "customer");

            // Trigger "Login Done" clean popup signal
            triggerPopupSignal(
                "Login Done",
                "You have logged in successfully! Taking you to your dashboard.",
                "../dashboard/dashboard.html"
            );
        });
    }
});