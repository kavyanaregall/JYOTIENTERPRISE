document.addEventListener("DOMContentLoaded", function () {
    const registerForm = document.getElementById("registerForm");
    const registerBtn = document.getElementById("registerBtn");

    const customPopup = document.getElementById("customPopup");
    const popupTitle = document.getElementById("popupTitle");
    const popupMessage = document.getElementById("popupMessage");
    const popupOkBtn = document.getElementById("popupOkBtn");

    function triggerPopupSignal(title, message, redirectUrl) {
        if (popupTitle) popupTitle.textContent = title;
        if (popupMessage) popupMessage.textContent = message;

        if (customPopup) {
            customPopup.classList.add("active");

            popupOkBtn.onclick = function () {
                customPopup.classList.remove("active");
                if (redirectUrl) window.location.href = redirectUrl;
            };

            setTimeout(function () {
                if (redirectUrl) window.location.href = redirectUrl;
            }, 1500);
        } else if (redirectUrl) {
            window.location.href = redirectUrl;
        }
    }

    if (registerForm) {
        registerForm.addEventListener("submit", async function (e) {
            e.preventDefault();

            const name = document.getElementById("fullName").value.trim();
            const phone = document.getElementById("phone").value.trim();
            const email = document.getElementById("email").value.trim().toLowerCase();
            const password = document.getElementById("password").value;

            if (registerBtn) {
                registerBtn.disabled = true;
                registerBtn.innerText = "Creating Account...";
            }

            try {
                await fetch("http://127.0.0.1:5000/api/register", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ name, phone, email, password, role: "customer" })
                });
            } catch (err) {
                console.warn("Backend offline; saved local customer profile.");
            }

            // Trigger "Registration Done" clean popup signal
            triggerPopupSignal(
                "Registration Done",
                "Your account has been created successfully! Redirecting to login.",
                "login.html"
            );
        });
    }
});