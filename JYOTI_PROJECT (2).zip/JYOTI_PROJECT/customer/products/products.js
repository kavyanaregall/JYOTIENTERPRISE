/* =========================================================
   JYOTI ENTERPRISE
   CUSTOMER PRODUCTS MODULE
   PRODUCTS + SEARCH + FILTER + SORT + CART + REALTIME WEBSOCKET
========================================================= */

/* =========================================================
   FALLBACK DEFAULT DATA (Used if API connection fails)
========================================================= */
const fallbackProducts = [
    {
        id: 1,
        name: "NCERT Mathematics Book",
        category: "Books",
        brand: "NCERT",
        price: 185,
        stock: 20,
        description: "Mathematics textbook suitable for school students.",
        image: "images/books/images.jfif",
        fallback: "📚",
        status: "Available"
    },
    {
        id: 2,
        name: "English Grammar Book",
        category: "Books",
        brand: "Oxford",
        price: 240,
        stock: 15,
        description: "English grammar reference book for students.",
        image: "images/books/english-grammar.jpg",
        fallback: "📖",
        status: "Available"
    },
    {
        id: 3,
        name: "Classmate Notebook",
        category: "Notebooks",
        brand: "Classmate",
        price: 75,
        stock: 50,
        description: "Quality ruled notebook for everyday writing.",
        image: "images/notebook/classmate-notebook.jpg",
        fallback: "📒",
        status: "Available"
    },
    {
        id: 4,
        name: "Long Notebook 200 Pages",
        category: "Notebooks",
        brand: "Classmate",
        price: 95,
        stock: 30,
        description: "200 page long notebook for school and college.",
        image: "images/notebook/long-notebook.jpg",
        fallback: "📓",
        status: "Available"
    },
    {
        id: 5,
        name: "Reynolds Ball Pen Blue",
        category: "Pens",
        brand: "Reynolds",
        price: 10,
        stock: 100,
        description: "Smooth writing blue ball pen.",
        image: "images/pens/reynolds-pen.jpg",
        fallback: "🖊️",
        status: "Available"
    },
    {
        id: 6,
        name: "Cello Butterflow Pen",
        category: "Pens",
        brand: "Cello",
        price: 10,
        stock: 100,
        description: "Smooth gel-like writing experience.",
        image: "images/pens/cello-pen.jpg",
        fallback: "🖊️",
        status: "Available"
    },
    {
        id: 7,
        name: "Camlin Colour Set",
        category: "Art & Craft",
        brand: "Camlin",
        price: 120,
        stock: 25,
        description: "Colour set suitable for school artwork.",
        image: "images/art-craft/camlin-colours.jpg",
        fallback: "🎨",
        status: "Available"
    },
    {
        id: 8,
        name: "Camel Drawing Book",
        category: "Art & Craft",
        brand: "Camel",
        price: 85,
        stock: 40,
        description: "Drawing book for creative artwork.",
        image: "images/art-craft/camel-drawing.jpg",
        fallback: "🖌️",
        status: "Available"
    },
    {
        id: 9,
        name: "School Geometry Box",
        category: "School Supplies",
        brand: "Camlin",
        price: 150,
        stock: 15,
        description: "Complete geometry box for school students.",
        image: "images/school-supplies/geometry-box.jpg",
        fallback: "📐",
        status: "Available"
    },
    {
        id: 10,
        name: "HB Pencil Pack",
        category: "School Supplies",
        brand: "Apsara",
        price: 45,
        stock: 60,
        description: "Pack of quality HB pencils.",
        image: "images/school-supplies/pencil-pack.jpg",
        fallback: "✏️",
        status: "Available"
    },
    {
        id: 11,
        name: "Office Stapler",
        category: "Office Supplies",
        brand: "Kangaro",
        price: 90,
        stock: 20,
        description: "Compact stapler suitable for office use.",
        image: "images/office-supplies/stapler.jpg",
        fallback: "📎",
        status: "Available"
    },
    {
        id: 12,
        name: "A4 Copier Paper",
        category: "Office Supplies",
        brand: "JK",
        price: 320,
        stock: 10,
        description: "A4 size copier paper for office printing.",
        image: "images/office-supplies/a4-paper.jpg",
        fallback: "📄",
        status: "Available"
    },
    {
        id: 13,
        name: "Water Colour Set",
        category: "Art & Craft",
        brand: "Camel",
        price: 95,
        stock: 20,
        description: "Water colour set for school projects.",
        image: "images/art-craft/water-colours.jpg",
        fallback: "🎨",
        status: "Available"
    },
    {
        id: 14,
        name: "Sticky Notes",
        category: "Office Supplies",
        brand: "3M",
        price: 65,
        stock: 35,
        description: "Colourful sticky notes for reminders.",
        image: "images/office-supplies/sticky-notes.jpg",
        fallback: "🗒️",
        status: "Available"
    },
    {
        id: 15,
        name: "Dictionary",
        category: "Books",
        brand: "Oxford",
        price: 450,
        stock: 12,
        description: "English dictionary for students and learners.",
        image: "images/books/dictionary.jpg",
        fallback: "📕",
        status: "Available"
    },
    {
        id: 16,
        name: "Pencil Box",
        category: "School Supplies",
        brand: "Classmate",
        price: 110,
        stock: 0,
        description: "Durable pencil box for school students.",
        image: "images/school-supplies/pencil-box.jpg",
        fallback: "🧰",
        status: "Out of Stock"
    }
];

let products = [...fallbackProducts];

/* =========================================================
   VARIABLES & URL PARAMS
========================================================= */
const BACKEND_URL = "http://127.0.0.1:5000";
const productsPerPage = 8;
let currentPage = 1;
let currentProducts = [];
let currentlyOpenModalId = null;

const urlParams = new URLSearchParams(window.location.search);
const selectedCategory = urlParams.get("category");
const selectedProductId = urlParams.get("productId");

/* =========================================================
   DOM ELEMENTS
========================================================= */
const productGrid = document.getElementById("productGrid");
const productCount = document.getElementById("productCount");
const emptyState = document.getElementById("emptyState");
const pagination = document.getElementById("pagination");
const productSearch = document.getElementById("productSearch");
const topSearch = document.getElementById("topSearch");
const categoryFilter = document.getElementById("categoryFilter");
const brandFilter = document.getElementById("brandFilter");
const sortFilter = document.getElementById("sortFilter");
const clearFilters = document.getElementById("clearFilters");

/* MODAL ELEMENTS */
const productModal = document.getElementById("productModal");
const modalClose = document.getElementById("modalClose");
const modalProductImage = document.getElementById("modalProductImage");
const modalCategory = document.getElementById("modalCategory");
const modalProductName = document.getElementById("modalProductName");
const modalBrand = document.getElementById("modalBrand");
const modalDescription = document.getElementById("modalDescription");
const modalPrice = document.getElementById("modalPrice");
const modalStatus = document.getElementById("modalStatus");

/* =========================================================
   CART MANAGEMENT
========================================================= */
let cart = JSON.parse(localStorage.getItem("jyotiCart")) || [];

function saveCart() {
    localStorage.setItem("jyotiCart", JSON.stringify(cart));
    updateCartCount();
}

function getCartCount() {
    return cart.reduce((total, item) => total + item.quantity, 0);
}

function updateCartCount() {
    const cartCount = document.getElementById("cartCount");
    if (cartCount) {
        cartCount.textContent = getCartCount();
    }
}

function createCartButton() {
    if (document.getElementById("jyotiCartButton")) return;
    const navbarRight = document.querySelector(".navbar-right");
    if (!navbarRight) return;

    const cartButton = document.createElement("a");
    cartButton.id = "jyotiCartButton";
    cartButton.href = "../cart/cart.html";
    cartButton.title = "Shopping Cart";
    cartButton.setAttribute("aria-label", "Shopping Cart");
    cartButton.style.cssText = `
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 44px;
        height: 44px;
        margin-right: 10px;
        border-radius: 12px;
        text-decoration: none;
        font-size: 20px;
        background: #ffffff;
        color: #1E3A8A;
        border: 1px solid #dbe4f0;
        cursor: pointer;
    `;
    cartButton.innerHTML = `
        🛒
        <span id="cartCount" style="
            position:absolute;
            top:-5px;
            right:-5px;
            min-width:20px;
            height:20px;
            padding:0 5px;
            border-radius:50px;
            background:#F59E0B;
            color:white;
            font-size:11px;
            font-weight:700;
            display:flex;
            align-items:center;
            justify-content:center;
        ">0</span>
    `;
    navbarRight.prepend(cartButton);
    updateCartCount();
}

function addToCart(productId) {
    const product = products.find(item => item.id === productId);
    if (!product) return;

    if (product.status !== "Available" || (product.stock !== undefined && product.stock <= 0)) {
        showCartPopup("Sorry, this product is currently out of stock.", true);
        return;
    }

    const existingItem = cart.find(item => item.id === productId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            category: product.category,
            brand: product.brand,
            price: product.price,
            image: product.image,
            fallback: product.fallback || "📦",
            quantity: 1
        });
    }

    saveCart();
    showCartPopup(`${product.name} has been added to your cart! 🛒`);
}

function showCartPopup(message, isError = false) {
    let popup = document.getElementById("cartActionPopup");
    if (!popup) {
        if (!document.getElementById("cartPopupGlowStyles")) {
            const style = document.createElement("style");
            style.id = "cartPopupGlowStyles";
            style.textContent = `
                @keyframes cartPopupGlow {
                    0%, 100% { box-shadow: 0 10px 28px rgba(15,23,42,.18), 0 0 0 rgba(34,197,94,0); }
                    50% { box-shadow: 0 12px 32px rgba(15,23,42,.2), 0 0 18px rgba(34,197,94,.38); }
                }
                #cartActionPopup.glow { animation: cartPopupGlow 1.8s ease-in-out infinite; }
                @media (prefers-reduced-motion: reduce) { #cartActionPopup.glow { animation: none; } }
            `;
            document.head.appendChild(style);
        }
        popup = document.createElement("div");
        popup.id = "cartActionPopup";
        popup.setAttribute("role", "status");
        popup.setAttribute("aria-live", "polite");
        Object.assign(popup.style, {
            position: "fixed", top: "24px", right: "24px", zIndex: "10000",
            maxWidth: "min(380px, calc(100vw - 32px))", padding: "14px 20px",
            borderRadius: "12px", color: "#fff", font: "600 14px/1.5 Inter, sans-serif",
            boxShadow: "0 12px 32px rgba(15,23,42,.22)", opacity: "0",
            transform: "translateY(-8px)", transition: "all .2s ease"
        });
        document.body.appendChild(popup);
    }
    popup.textContent = message;
    popup.style.background = isError ? "#dc2626" : "#16a34a";
    popup.classList.toggle("glow", !isError);
    popup.style.opacity = "1";
    popup.style.transform = "translateY(0)";
    clearTimeout(popup.hideTimer);
    popup.hideTimer = setTimeout(() => {
        popup.style.opacity = "0";
        popup.style.transform = "translateY(-8px)";
    }, 3000);
}

/* =========================================================
   DATABASE FETCH & HYDRATION
========================================================= */
async function fetchProductsFromBackend() {
    try {
        const response = await fetch(`${BACKEND_URL}/api/products`);
        if (!response.ok) throw new Error("Failed to load products");
        const data = await response.json();

        if (data.success && data.products && data.products.length > 0) {
            products = data.products.map(item => ({
                id: item.id,
                name: item.name,
                category: item.category_name || "General",
                brand: item.brand || "Standard",
                price: parseFloat(item.price) || 0,
                stock: parseInt(item.stock) || 0,
                description: item.description || "",
                image: item.image ? (item.image.startsWith("http") ? item.image : `${BACKEND_URL}${item.image}`) : "images/placeholder.jpg",
                fallback: "📦",
                status: (item.stock > 0 && item.status !== "Out of Stock") ? "Available" : "Out of Stock"
            }));
        }
    } catch (err) {
        console.warn("Backend unavailable. Serving static catalog:", err);
    }
}

/* =========================================================
   FILTERS & SORTING
========================================================= */
function getUniqueValues(property) {
    return [...new Set(products.map(p => p[property]).filter(Boolean))];
}

function populateFilters() {
    if (categoryFilter) {
        categoryFilter.innerHTML = `<option value="all">All Categories</option>`;
        getUniqueValues("category").forEach(cat => {
            const opt = document.createElement("option");
            opt.value = cat;
            opt.textContent = cat;
            categoryFilter.appendChild(opt);
        });
    }

    if (brandFilter) {
        brandFilter.innerHTML = `<option value="all">All Brands</option>`;
        getUniqueValues("brand").forEach(brand => {
            const opt = document.createElement("option");
            opt.value = brand;
            opt.textContent = brand;
            brandFilter.appendChild(opt);
        });
    }
}

function applyFilters() {
    const searchValue = productSearch ? productSearch.value.toLowerCase().trim() : "";
    const categoryValue = categoryFilter ? categoryFilter.value : "all";
    const brandValue = brandFilter ? brandFilter.value : "all";
    const sortValue = sortFilter ? sortFilter.value : "default";

    const currentURL = new URLSearchParams(window.location.search);
    const urlCategory = currentURL.get("category");

    currentProducts = products.filter(product => {
        const matchesSearch =
            product.name.toLowerCase().includes(searchValue) ||
            product.category.toLowerCase().includes(searchValue) ||
            product.brand.toLowerCase().includes(searchValue);

        const matchesCategory = urlCategory
            ? product.category === urlCategory
            : (categoryValue === "all" || product.category === categoryValue);

        const matchesBrand = (brandValue === "all" || product.brand === brandValue);

        return matchesSearch && matchesCategory && matchesBrand;
    });

    if (sortValue === "low") currentProducts.sort((a, b) => a.price - b.price);
    if (sortValue === "high") currentProducts.sort((a, b) => b.price - a.price);
    if (sortValue === "name") currentProducts.sort((a, b) => a.name.localeCompare(b.name));

    currentPage = 1;
    renderProducts();
}

/* =========================================================
   RENDER PRODUCTS GRID
========================================================= */
function renderProducts() {
    if (!productGrid) return;
    productGrid.innerHTML = "";

    if (productCount) {
        productCount.textContent = currentProducts.length;
    }

    if (currentProducts.length === 0) {
        productGrid.style.display = "none";
        if (emptyState) emptyState.classList.add("show");
        if (pagination) pagination.innerHTML = "";
        return;
    }

    productGrid.style.display = "grid";
    if (emptyState) emptyState.classList.remove("show");

    const totalPages = Math.ceil(currentProducts.length / productsPerPage);
    if (currentPage > totalPages) currentPage = totalPages;

    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const pageProducts = currentProducts.slice(startIndex, endIndex);

    pageProducts.forEach(product => {
        const card = document.createElement("div");
        card.className = "product-card";
        card.setAttribute("data-product-id", product.id);

        const isAvailable = product.status === "Available" && (product.stock === undefined || product.stock > 0);

        card.innerHTML = `
            <div class="product-image">
                <img
                    src="${product.image}"
                    alt="${product.name}"
                    onerror="this.style.display='none'; this.nextElementSibling.style.display='block';"
                >
                <span class="product-fallback" style="display:none;">${product.fallback || "📦"}</span>
                <span class="product-availability ${!isAvailable ? "out" : ""}">
                    ${isAvailable ? "Available" : "Out of Stock"}
                </span>
            </div>
            <div class="product-content">
                <span class="product-category">${product.category}</span>
                <h3 class="product-name">${product.name}</h3>
                <p class="product-brand">Brand: ${product.brand}</p>
                <p class="product-description">${product.description}</p>
                <div class="product-bottom">
                    <strong class="product-price">₹${product.price.toLocaleString("en-IN")}</strong>
                    <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
                        <button type="button" class="view-product" onclick="openProductModal(${product.id})">
                            View Details
                        </button>
                        <button
                            type="button"
                            class="add-to-cart-btn"
                            onclick="addToCart(${product.id})"
                            ${!isAvailable ? "disabled" : ""}
                            style="
                                border:none;
                                border-radius:8px;
                                padding:10px 14px;
                                font-weight:600;
                                cursor:${isAvailable ? "pointer" : "not-allowed"};
                                background:${isAvailable ? "#1E3A8A" : "#d1d5db"};
                                color:white;
                            "
                        >
                            🛒 ${isAvailable ? "Add to Cart" : "Out of Stock"}
                        </button>
                    </div>
                </div>
            </div>
        `;
        productGrid.appendChild(card);
    });

    renderPagination(totalPages);
}

/* =========================================================
   PAGINATION
========================================================= */
function renderPagination(totalPages) {
    if (!pagination) return;
    pagination.innerHTML = "";
    if (totalPages <= 1) return;

    const previous = document.createElement("button");
    previous.className = "page-button";
    previous.innerHTML = `<i class="fa-solid fa-chevron-left"></i>`;
    if (currentPage === 1) previous.classList.add("disabled");

    previous.addEventListener("click", () => {
        if (currentPage > 1) {
            currentPage--;
            renderProducts();
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    });
    pagination.appendChild(previous);

    for (let page = 1; page <= totalPages; page++) {
        const button = document.createElement("button");
        button.className = "page-button";
        button.textContent = page;
        if (page === currentPage) button.classList.add("active");

        button.addEventListener("click", () => {
            currentPage = page;
            renderProducts();
            window.scrollTo({ top: 0, behavior: "smooth" });
        });
        pagination.appendChild(button);
    }

    const next = document.createElement("button");
    next.className = "page-button";
    next.innerHTML = `<i class="fa-solid fa-chevron-right"></i>`;
    if (currentPage === totalPages) next.classList.add("disabled");

    next.addEventListener("click", () => {
        if (currentPage < totalPages) {
            currentPage++;
            renderProducts();
            window.scrollTo({ top: 0, behavior: "smooth" });
        }
    });
    pagination.appendChild(next);
}

/* =========================================================
   PRODUCT MODAL
========================================================= */
function openProductModal(id) {
    const product = products.find(item => item.id === id);
    if (!product) return;

    currentlyOpenModalId = id;
    const isAvailable = product.status === "Available" && (product.stock === undefined || product.stock > 0);

    if (modalProductImage) {
        modalProductImage.innerHTML = `
            <img
                src="${product.image}"
                alt="${product.name}"
                onerror="this.style.display='none'; this.nextElementSibling.style.display='block';"
            >
            <span class="modal-fallback" style="display:none;">${product.fallback || "📦"}</span>
        `;
    }

    if (modalCategory) modalCategory.textContent = product.category;
    if (modalProductName) modalProductName.textContent = product.name;
    if (modalBrand) modalBrand.textContent = "Brand: " + product.brand;
    if (modalDescription) modalDescription.textContent = product.description;
    if (modalPrice) modalPrice.textContent = "₹" + product.price.toLocaleString("en-IN");

    if (modalStatus) {
        modalStatus.textContent = isAvailable ? "Available" : "Out of Stock";
        modalStatus.style.background = isAvailable ? "#ECFDF3" : "#FEF2F2";
        modalStatus.style.color = isAvailable ? "#16A34A" : "#DC2626";
    }

    let modalCartButton = document.getElementById("modalAddToCart");
    if (!modalCartButton) {
        modalCartButton = document.createElement("button");
        modalCartButton.id = "modalAddToCart";
        modalCartButton.type = "button";
        modalCartButton.style.cssText = `
            margin-top:25px;
            padding:13px 22px;
            border:none;
            border-radius:10px;
            font-size:15px;
            font-weight:700;
        `;
        if (modalStatus && modalStatus.parentElement) {
            modalStatus.parentElement.appendChild(modalCartButton);
        }
    }

    modalCartButton.textContent = isAvailable ? "🛒 Add to Cart" : "Out of Stock";
    modalCartButton.disabled = !isAvailable;
    modalCartButton.style.cursor = isAvailable ? "pointer" : "not-allowed";
    modalCartButton.style.background = isAvailable ? "#1E3A8A" : "#9CA3AF";
    modalCartButton.style.color = "white";
    modalCartButton.onclick = () => addToCart(product.id);

    if (productModal) {
        productModal.classList.add("show");
        document.body.style.overflow = "hidden";
    }
}

function closeProductModal() {
    currentlyOpenModalId = null;
    if (productModal) productModal.classList.remove("show");
    document.body.style.overflow = "";
}

if (modalClose) modalClose.addEventListener("click", closeProductModal);
if (productModal) {
    productModal.addEventListener("click", (e) => {
        if (e.target === productModal) closeProductModal();
    });
}
document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeProductModal();
});

/* =========================================================
   SEARCH & FILTER EVENT LISTENERS
========================================================= */
if (productSearch) {
    productSearch.addEventListener("input", () => {
        if (topSearch) topSearch.value = productSearch.value;
        applyFilters();
    });
}

if (topSearch) {
    topSearch.addEventListener("input", () => {
        if (productSearch) productSearch.value = topSearch.value;
        applyFilters();
    });
}

if (categoryFilter) {
    categoryFilter.addEventListener("change", () => {
        const url = new URL(window.location.href);
        url.searchParams.delete("category");
        window.history.replaceState({}, "", url);
        applyFilters();
    });
}

if (brandFilter) brandFilter.addEventListener("change", applyFilters);
if (sortFilter) sortFilter.addEventListener("change", applyFilters);

if (clearFilters) {
    clearFilters.addEventListener("click", () => {
        if (productSearch) productSearch.value = "";
        if (topSearch) topSearch.value = "";
        if (categoryFilter) categoryFilter.value = "all";
        if (brandFilter) brandFilter.value = "all";
        if (sortFilter) sortFilter.value = "default";

        const url = new URL(window.location.href);
        url.searchParams.delete("category");
        url.searchParams.delete("productId");
        window.history.replaceState({}, "", url);

        currentProducts = [...products];
        currentPage = 1;
        renderProducts();
    });
}

/* =========================================================
   SIDEBAR & LOGOUT
========================================================= */
const customerSidebar = document.getElementById("customerSidebar");
const sidebarToggle = document.getElementById("sidebarToggle");

if (sidebarToggle && customerSidebar) {
    sidebarToggle.addEventListener("click", () => {
        customerSidebar.classList.toggle("open");
        if (customerSidebar.classList.contains("open")) {
            createSidebarOverlay();
        }
    });
}

function createSidebarOverlay() {
    if (document.querySelector(".sidebar-overlay")) return;
    const overlay = document.createElement("div");
    overlay.className = "sidebar-overlay";
    overlay.style.cssText = `position:fixed; inset:0; z-index:999; background:rgba(15,23,42,.35);`;
    document.body.appendChild(overlay);

    overlay.addEventListener("click", () => {
        if (customerSidebar) customerSidebar.classList.remove("open");
        overlay.remove();
    });
}

const logoutButton = document.getElementById("logoutButton");
if (logoutButton) {
    logoutButton.addEventListener("click", (e) => {
        if (!confirm("Are you sure you want to logout?")) {
            e.preventDefault();
        }
    });
}

/* =========================================================
   REAL-TIME WEBSOCKET LISTENERS (FLASK-SOCKETIO)
========================================================= */
function setupRealtimeSocket() {
    if (typeof io === "undefined") {
        console.warn("Socket.io client script not found. Realtime updates disabled.");
        return;
    }

    const socket = io(BACKEND_URL);

    // 1. Live Price & Stock Updates
    socket.on("product_updated", (data) => {
        const prod = products.find(p => p.id === Number(data.id));
        if (prod) {
            if (data.price !== undefined) prod.price = parseFloat(data.price);
            if (data.stock !== undefined) prod.stock = parseInt(data.stock);
            if (data.name !== undefined) prod.name = data.name;
            prod.status = (prod.stock > 0 && data.status !== "Out of Stock") ? "Available" : "Out of Stock";

            // If updated product is open in modal, refresh modal live
            if (currentlyOpenModalId === prod.id) {
                openProductModal(prod.id);
            }
        }

        applyFilters();
    });

    // 2. Live New Product Additions
    socket.on("product_added", (data) => {
        const newProduct = {
            id: Number(data.id),
            name: data.name,
            category: data.category || "General",
            brand: data.brand || "Standard",
            price: parseFloat(data.price) || 0,
            stock: parseInt(data.stock) || 0,
            description: data.description || "",
            image: data.image ? (data.image.startsWith("http") ? data.image : `${BACKEND_URL}${data.image}`) : "images/placeholder.jpg",
            fallback: "📦",
            status: (data.stock > 0) ? "Available" : "Out of Stock"
        };

        products.unshift(newProduct);
        populateFilters();
        applyFilters();
    });

    // 3. Live Product Removal
    socket.on("product_deleted", (data) => {
        const targetId = Number(data.id);
        products = products.filter(p => p.id !== targetId);

        if (currentlyOpenModalId === targetId) {
            closeProductModal();
        }

        populateFilters();
        applyFilters();
    });
}

/* =========================================================
   INITIALIZE PAGE
========================================================= */
async function initializeProductsPage() {
    await fetchProductsFromBackend();

    populateFilters();

    if (selectedCategory && categoryFilter) {
        categoryFilter.value = selectedCategory;
    }

    if (selectedCategory) {
        applyFilters();
    } else {
        currentProducts = [...products];
        renderProducts();
    }

    createCartButton();
    updateCartCount();

    if (selectedProductId) {
        const productId = Number(selectedProductId);
        setTimeout(() => openProductModal(productId), 200);
    }

    setupRealtimeSocket();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeProductsPage);
} else {
    initializeProductsPage();
}
