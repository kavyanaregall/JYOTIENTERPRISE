/* =========================================
   JYOTI ENTERPRISE
   CUSTOMER PROFILE PAGE
   FRONTEND VERSION
========================================= */


/* =========================================
   GET CUSTOMER DATA
========================================= */

let customer =
    JSON.parse(
        localStorage.getItem("jyotiCustomer")
    ) || {};


/* =========================================
   DEFAULT CUSTOMER DATA
========================================= */

if (!customer.name) {
    customer.name = "Customer";
}

if (!customer.email) {
    customer.email = "customer@jyotienterprise.com";
}

if (!customer.phone) {
    customer.phone = "+91 98765 43210";
}

if (!customer.address) {
    customer.address = "Bengaluru, Karnataka, India";
}


/* =========================================
   SAVE CUSTOMER DATA
========================================= */

localStorage.setItem(
    "jyotiCustomer",
    JSON.stringify(customer)
);


/* =========================================
   GET ELEMENTS
========================================= */

const editProfileButton =
    document.getElementById("editProfileButton");

const personalInfoCard =
    document.getElementById("personalInfoCard");

const addressCard =
    document.getElementById("addressCard");

const profileModal =
    document.getElementById("profileModal");

const modalClose =
    document.getElementById("modalClose");

const cancelButton =
    document.getElementById("cancelButton");

const profileForm =
    document.getElementById("profileForm");


/* =========================================
   DISPLAY CUSTOMER DATA
========================================= */

function displayCustomerData() {

    const profileName =
        document.getElementById("profileName");

    const displayName =
        document.getElementById("displayName");

    const navbarName =
        document.getElementById("navbarName");

    const profileEmail =
        document.getElementById("profileEmail");

    const displayEmail =
        document.getElementById("displayEmail");

    const displayPhone =
        document.getElementById("displayPhone");

    const displayAddress =
        document.getElementById("displayAddress");

    const profileInitial =
        document.getElementById("profileInitial");

    const navbarAvatar =
        document.getElementById("navbarAvatar");


    if (profileName) {
        profileName.textContent =
            customer.name;
    }


    if (displayName) {
        displayName.textContent =
            customer.name;
    }


    if (navbarName) {
        navbarName.textContent =
            customer.name;
    }


    if (profileEmail) {
        profileEmail.textContent =
            customer.email;
    }


    if (displayEmail) {
        displayEmail.textContent =
            customer.email;
    }


    if (displayPhone) {
        displayPhone.textContent =
            customer.phone;
    }


    if (displayAddress) {
        displayAddress.textContent =
            customer.address;
    }


    const firstLetter =
        customer.name
            .charAt(0)
            .toUpperCase();


    if (profileInitial) {
        profileInitial.textContent =
            firstLetter;
    }


    if (navbarAvatar) {
        navbarAvatar.textContent =
            firstLetter;
    }

}


/* =========================================
   INITIAL DISPLAY
========================================= */

displayCustomerData();


/* =========================================
   OPEN PROFILE MODAL
========================================= */

function openProfileModal() {

    if (!profileModal) {
        return;
    }


    /* Fill existing information */

    const nameInput =
        document.getElementById("name");

    const emailInput =
        document.getElementById("email");

    const phoneInput =
        document.getElementById("phone");

    const addressInput =
        document.getElementById("address");


    if (nameInput) {
        nameInput.value =
            customer.name;
    }


    if (emailInput) {
        emailInput.value =
            customer.email;
    }


    if (phoneInput) {
        phoneInput.value =
            customer.phone;
    }


    if (addressInput) {
        addressInput.value =
            customer.address;
    }


    profileModal.classList.add("show");

}


/* =========================================
   EDIT PROFILE BUTTON
========================================= */

if (editProfileButton) {

    editProfileButton.addEventListener(
        "click",
        function () {

            openProfileModal();

        }
    );

}


/* =========================================
   PERSONAL INFORMATION CARD
========================================= */

if (personalInfoCard) {

    personalInfoCard.addEventListener(
        "click",
        function () {

            openProfileModal();

        }
    );

}


/* =========================================
   ADDRESS CARD
========================================= */

if (addressCard) {

    addressCard.addEventListener(
        "click",
        function () {

            openProfileModal();

        }
    );

}


/* =========================================
   CLOSE PROFILE MODAL
========================================= */

if (modalClose) {

    modalClose.addEventListener(
        "click",
        function () {

            if (profileModal) {

                profileModal.classList.remove(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   CANCEL PROFILE EDIT
========================================= */

if (cancelButton) {

    cancelButton.addEventListener(
        "click",
        function () {

            if (profileModal) {

                profileModal.classList.remove(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   CLOSE PROFILE MODAL
   CLICK OUTSIDE
========================================= */

if (profileModal) {

    profileModal.addEventListener(
        "click",
        function (event) {

            if (
                event.target ===
                profileModal
            ) {

                profileModal.classList.remove(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   SAVE PROFILE
========================================= */

if (profileForm) {

    profileForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            /* GET VALUES */

            const nameInput =
                document.getElementById("name");

            const emailInput =
                document.getElementById("email");

            const phoneInput =
                document.getElementById("phone");

            const addressInput =
                document.getElementById("address");


            if (
                !nameInput ||
                !emailInput ||
                !phoneInput ||
                !addressInput
            ) {

                alert(
                    "Profile fields are missing."
                );

                return;

            }


            const name =
                nameInput.value.trim();

            const email =
                emailInput.value.trim();

            const phone =
                phoneInput.value.trim();

            const address =
                addressInput.value.trim();


            /* =================================
               VALIDATION
            ================================= */

            if (!name) {

                alert(
                    "Please enter your name."
                );

                return;

            }


            if (!email) {

                alert(
                    "Please enter your email."
                );

                return;

            }


            /* =================================
               UPDATE CUSTOMER
            ================================= */

            customer.name =
                name;

            customer.email =
                email;

            customer.phone =
                phone;

            customer.address =
                address;


            /* =================================
               SAVE CUSTOMER
            ================================= */

            localStorage.setItem(
                "jyotiCustomer",
                JSON.stringify(customer)
            );


            /* =================================
               UPDATE PAGE
            ================================= */

            displayCustomerData();


            /* =================================
               CLOSE MODAL
            ================================= */

            if (profileModal) {

                profileModal.classList.remove(
                    "show"
                );

            }


            /* =================================
               SUCCESS
            ================================= */

            alert(
                "Profile updated successfully!"
            );

        }
    );

}


/* =========================================
   CHANGE PASSWORD
========================================= */

const changePasswordButton =
    document.getElementById(
        "changePasswordButton"
    );

const passwordModal =
    document.getElementById(
        "passwordModal"
    );

const passwordModalClose =
    document.getElementById(
        "passwordModalClose"
    );

const passwordCancelButton =
    document.getElementById(
        "passwordCancelButton"
    );

const passwordForm =
    document.getElementById(
        "passwordForm"
    );


/* =========================================
   OPEN PASSWORD MODAL
========================================= */

if (changePasswordButton) {

    changePasswordButton.addEventListener(
        "click",
        function () {

            if (passwordModal) {

                passwordModal.classList.add(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   CLOSE PASSWORD MODAL
========================================= */

if (passwordModalClose) {

    passwordModalClose.addEventListener(
        "click",
        function () {

            if (passwordModal) {

                passwordModal.classList.remove(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   CANCEL PASSWORD CHANGE
========================================= */

if (passwordCancelButton) {

    passwordCancelButton.addEventListener(
        "click",
        function () {

            if (passwordModal) {

                passwordModal.classList.remove(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   CLOSE PASSWORD MODAL
   CLICK OUTSIDE
========================================= */

if (passwordModal) {

    passwordModal.addEventListener(
        "click",
        function (event) {

            if (
                event.target ===
                passwordModal
            ) {

                passwordModal.classList.remove(
                    "show"
                );

            }

        }
    );

}


/* =========================================
   UPDATE PASSWORD
========================================= */

if (passwordForm) {

    passwordForm.addEventListener(
        "submit",
        function (event) {

            event.preventDefault();


            /* =================================
               GET PASSWORD INPUTS
            ================================= */

            const currentPasswordInput =
                document.getElementById(
                    "currentPassword"
                );

            const newPasswordInput =
                document.getElementById(
                    "newPassword"
                );

            const confirmPasswordInput =
                document.getElementById(
                    "confirmNewPassword"
                );


            /* =================================
               CHECK INPUTS
            ================================= */

            if (
                !currentPasswordInput ||
                !newPasswordInput ||
                !confirmPasswordInput
            ) {

                alert(
                    "Password fields are missing. Please check the IDs in profile.html."
                );

                return;

            }


            /* =================================
               GET VALUES
            ================================= */

            const currentPassword =
                currentPasswordInput.value;

            const newPassword =
                newPasswordInput.value;

            const confirmPassword =
                confirmPasswordInput.value;


            /* =================================
               GET CUSTOMER
            ================================= */

            customer =
                JSON.parse(
                    localStorage.getItem(
                        "jyotiCustomer"
                    )
                ) || null;


            if (!customer) {

                alert(
                    "Customer account not found. Please register again."
                );

                return;

            }


            /* =================================
               CHECK CURRENT PASSWORD
            ================================= */

            if (
                currentPassword !==
                customer.password
            ) {

                alert(
                    "Current password is incorrect."
                );

                return;

            }


            /* =================================
               CHECK NEW PASSWORD LENGTH
            ================================= */

            if (
                newPassword.length < 6
            ) {

                alert(
                    "New password must contain at least 6 characters."
                );

                return;

            }


            /* =================================
               CHECK CONFIRM PASSWORD
            ================================= */

            if (
                newPassword !==
                confirmPassword
            ) {

                alert(
                    "New passwords do not match."
                );

                return;

            }


            /* =================================
               UPDATE PASSWORD
            ================================= */

            customer.password =
                newPassword;


            /* =================================
               SAVE PASSWORD
            ================================= */

            localStorage.setItem(
                "jyotiCustomer",
                JSON.stringify(customer)
            );


            /* =================================
               CLEAR FORM
            ================================= */

            passwordForm.reset();


            /* =================================
               CLOSE MODAL
            ================================= */

            if (passwordModal) {

                passwordModal.classList.remove(
                    "show"
                );

            }


            /* =================================
               SUCCESS MESSAGE
            ================================= */

            alert(
                "Password updated successfully!"
            );

        }
    );

}


/* =========================================
   MOBILE SIDEBAR
========================================= */

const sidebarToggle =
    document.getElementById(
        "sidebarToggle"
    );

const customerSidebar =
    document.getElementById(
        "customerSidebar"
    );


if (sidebarToggle) {

    sidebarToggle.addEventListener(
        "click",
        function () {

            if (customerSidebar) {

                customerSidebar.classList.toggle(
                    "open"
                );

            }

        }
    );

}


/* =========================================
   LOGOUT
========================================= */

const logoutButton =
    document.getElementById(
        "logoutButton"
    );


if (logoutButton) {

    logoutButton.addEventListener(
        "click",
        function (event) {

            event.preventDefault();


            /* CLEAR SESSION */

            sessionStorage.removeItem(
                "jyotiCustomer"
            );


            /* GO TO CUSTOMER LOGIN */

            window.location.href =
                "../login.html";

        }
    );

}


/* =========================================
   FINISHED
========================================= */

console.log(
    "Jyoti Enterprise Profile JavaScript loaded successfully."
);