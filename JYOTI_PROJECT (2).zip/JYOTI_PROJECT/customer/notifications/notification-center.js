(function() {
    const STORAGE_KEY = "jyotiNotifications";
    const DISMISSED_KEY = "jyotiDismissedNotifications";
    const BACKEND_URL = "http://127.0.0.1:5000";
    const MAX_NOTIFICATIONS = 100;
    let productSocket;
    let syncInProgress = false;

    function readNotifications() {
        try {
            const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
            return Array.isArray(saved) ? saved : [];
        } catch (error) {
            console.error("Could not read customer notifications:", error);
            return [];
        }
    }

    function readDismissedIds() {
        try {
            const saved = JSON.parse(localStorage.getItem(DISMISSED_KEY) || "[]");
            return new Set(Array.isArray(saved) ? saved.map(String) : []);
        } catch (error) {
            console.error("Could not read dismissed customer notifications:", error);
            return new Set();
        }
    }

    function writeNotifications(notifications) {
        const saved = notifications.slice(0, MAX_NOTIFICATIONS);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
        updateNotificationBadges();
        window.dispatchEvent(new CustomEvent("jyoti:notifications-updated", {
            detail: saved
        }));
    }

    function getNotifications() {
        return readNotifications();
    }

    function readStoredObject(storage, key) {
        try {
            return JSON.parse(storage.getItem(key) || "{}");
        } catch (error) {
            return {};
        }
    }

    function customerNotificationUrl() {
        const sessionUser = readStoredObject(sessionStorage, "jyotiCustomer");
        const localUser = readStoredObject(localStorage, "currentUser");
        const profileUser = readStoredObject(localStorage, "jyotiCustomer");
        const userId = sessionUser.id || sessionUser.user_id ||
            localUser.id || localUser.user_id || profileUser.id || profileUser.user_id;
        const email = sessionUser.email || sessionUser.email_address ||
            localUser.email || localUser.email_address ||
            profileUser.email || profileUser.email_address ||
            sessionStorage.getItem("jyotiCustomerEmail");
        const params = new URLSearchParams();

        if (userId && Number.isSafeInteger(Number(userId))) {
            params.set("user_id", String(Number(userId)));
        } else if (email) {
            params.set("email", email.trim().toLowerCase());
        }

        const query = params.toString();
        return `${BACKEND_URL}/api/customer/notifications${query ? `?${query}` : ""}`;
    }

    function addNotification(notification) {
        const notifications = readNotifications();
        const notificationId = String(notification.id);
        if (readDismissedIds().has(notificationId) || notifications.some(item => String(item.id) === notificationId)) return;
        notifications.unshift({
            ...notification,
            read: Boolean(notification.read)
        });
        writeNotifications(notifications);
        showProductToast(notification);
    }

    function updateNotificationBadges() {
        const unread = readNotifications().filter(item => !item.read).length;
        const links = document.querySelectorAll(
            'a.notification-button, a[href*="notifications/notification.html"], .customer-notification-shortcut'
        );

        links.forEach(link => {
            let badge = link.querySelector("[data-notification-count], .notification-count");
            if (!badge) {
                badge = document.createElement("span");
                badge.className = "notification-count";
                link.appendChild(badge);
            }
            badge.dataset.notificationCount = "true";
            badge.textContent = unread > 99 ? "99+" : String(unread);
            badge.hidden = unread === 0;
            link.setAttribute("aria-label", unread
                ? `Notifications, ${unread} unread`
                : "Notifications");
        });
    }

    function mountNotificationsShortcut() {
        if (location.pathname.includes("/notifications/notification.html")) return;
        const existingLink = document.querySelector(
            'a.notification-button, a[href*="notifications/notification.html"]'
        );
        if (existingLink) {
            existingLink.classList.add("notification-button");
            updateNotificationBadges();
            return;
        }

        const link = document.createElement("a");
        link.className = "customer-notification-shortcut";
        link.href = "../notifications/notification.html";
        link.title = "Notifications";
        link.setAttribute("aria-label", "Notifications");
        link.innerHTML = '<i class="fa-regular fa-bell" aria-hidden="true"></i>';
        document.body.appendChild(link);
        updateNotificationBadges();
    }

    function showProductToast(notification) {
        let toast = document.getElementById("customerProductUpdateToast");
        if (!toast) {
            toast = document.createElement("div");
            toast.id = "customerProductUpdateToast";
            toast.className = "customer-product-update-toast";
            toast.setAttribute("role", "status");
            toast.setAttribute("aria-live", "polite");
            document.body.appendChild(toast);
        }

        toast.textContent = notification.title;
        toast.classList.add("show");
        clearTimeout(toast.hideTimer);
        toast.hideTimer = setTimeout(() => toast.classList.remove("show"), 5000);
    }

    function recordProductUpdate(data, type) {
        const productName = String(data.name || "A store product");
        const eventId = data.event_id || `${type}-${data.id}-${data.updated_at || Date.now()}`;
        const isAdded = type === "product_added";
        const title = isAdded ? `${productName} is now available` : `${productName} was updated`;
        const details = [];

        if (data.price !== undefined) {
            details.push(`Price: ₹${Number(data.price).toLocaleString("en-IN")}`);
        }
        if (data.stock !== undefined) {
            details.push(`Stock: ${Number(data.stock)}`);
        }
        if (data.status) details.push(`Status: ${data.status}`);

        addNotification({
            id: eventId,
            type: "product_update",
            productId: data.id,
            productName,
            title,
            message: details.length
                ? `${details.join(" · ")}. Visit the store to see the latest product details.`
                : "Product information has changed. Visit the store to see the latest details.",
            createdAt: data.updated_at || new Date().toISOString(),
            read: false
        });
    }

    async function syncPersistedNotifications() {
        if (syncInProgress) return;
        syncInProgress = true;
        try {
            const response = await fetch(customerNotificationUrl());
            if (!response.ok) throw new Error(`HTTP ${response.status}`);

            const result = await response.json();
            if (!result.success || !Array.isArray(result.notifications)) return;

            const current = readNotifications();
            const dismissedIds = readDismissedIds();
            const currentById = new Map(current.map(item => [String(item.id), item]));
            const savedNotifications = result.notifications
                .filter(item => !dismissedIds.has(String(item.event_id)))
                .map(item => {
                const id = String(item.event_id);
                const previous = currentById.get(id);

                if (item.type === "order") {
                    const orderId = item.order_id;
                    const isPlaced = item.event_type === "order_placed";
                    const savedStatus = String(item.status || "Awaiting Pickup");
                    const statusMap = {
                        confirmed: "Awaiting Pickup",
                        pending: "Awaiting Pickup",
                        processing: "Ready for Pickup",
                        shipped: "Ready for Pickup",
                        delivered: "Collected"
                    };
                    const status = statusMap[savedStatus.toLowerCase()] || savedStatus;
                    return {
                        id,
                        type: "order",
                        eventType: item.event_type,
                        orderId,
                        title: isPlaced
                            ? `Order #${orderId} placed`
                            : `Order #${orderId} update: ${status}`,
                        status,
                        message: item.message,
                        customerName: item.customer_name || "Customer",
                        pickupLocation: "Jyoti Enterprise Counter, Main Branch",
                        fulfillmentType: item.fulfillment_type || "store_pickup",
                        amount: Number(item.amount) || 0,
                        products: Array.isArray(item.products) ? item.products : [],
                        createdAt: item.created_at,
                        read: previous ? previous.read : false
                    };
                }

                const isAdded = item.event_type === "added";
                return {
                    id,
                    type: "product_update",
                    productId: item.product_id,
                    productName: item.product_name,
                    title: isAdded
                        ? `${item.product_name} is now available`
                        : `${item.product_name} was updated`,
                    message: item.message,
                    price: item.price,
                    stock: item.stock,
                    status: item.status,
                    createdAt: item.created_at,
                    read: previous ? previous.read : false
                };
                });
            const savedIds = new Set(savedNotifications.map(item => String(item.id)));
            const localNotifications = current.filter(item =>
                !dismissedIds.has(String(item.id)) && !savedIds.has(String(item.id))
            );

            writeNotifications([...savedNotifications, ...localNotifications]);
        } catch (error) {
            console.warn("Could not sync saved customer notifications:", error);
        } finally {
            syncInProgress = false;
        }
    }

    function startProductSocket() {
        if (productSocket || typeof window.io !== "function") return;
        productSocket = window.io(BACKEND_URL, {
            transports: ["polling", "websocket"]
        });
        productSocket.on("product_updated", data => recordProductUpdate(data, "product_updated"));
        productSocket.on("product_added", data => recordProductUpdate(data, "product_added"));
        productSocket.on("product_deleted", data => {
            addNotification({
                id: data.event_id || `product-deleted-${data.id}-${Date.now()}`,
                type: "product_update",
                productId: data.id,
                productName: data.name || "A store product",
                title: `${data.name || "A product"} is no longer available`,
                message: "This product has been removed from the store.",
                createdAt: new Date().toISOString(),
                read: false
            });
        });
    }

    function loadSocketClient() {
        if (typeof window.io === "function") startProductSocket();
    }

    window.CustomerNotificationCenter = {
        getAll: getNotifications,
        ready: syncPersistedNotifications(),
        add: addNotification,
        markAllRead: function() {
            writeNotifications(readNotifications().map(item => ({ ...item, read: true })));
        },
        toggleRead: function(id) {
            writeNotifications(readNotifications().map(item =>
                String(item.id) === String(id) ? { ...item, read: !item.read } : item
            ));
        },
        clearAll: function() {
            const dismissedIds = readDismissedIds();
            readNotifications().forEach(item => dismissedIds.add(String(item.id)));
            localStorage.setItem(DISMISSED_KEY, JSON.stringify([...dismissedIds]));
            writeNotifications([]);
        }
    };

    const stylesheet = document.createElement("link");
    stylesheet.rel = "stylesheet";
    stylesheet.href = new URL("notification-center.css", document.currentScript.src).href;
    document.head.appendChild(stylesheet);

    window.addEventListener("storage", event => {
        if (event.key === STORAGE_KEY) updateNotificationBadges();
    });

    mountNotificationsShortcut();
    syncPersistedNotifications();
    window.setInterval(() => {
        if (document.visibilityState !== "hidden") syncPersistedNotifications();
    }, 15000);
    window.addEventListener("focus", syncPersistedNotifications);
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "visible") syncPersistedNotifications();
    });
    loadSocketClient();
})();