const notificationList = document.getElementById("notificationList");
const emptyState = document.getElementById("emptyState");
const notificationSearch = document.getElementById("notificationSearch");
const allCount = document.getElementById("allCount");
const unreadCount = document.getElementById("unreadCount");
const readCount = document.getElementById("readCount");
const markAllButton = document.getElementById("markAllButton");
const clearAllButton = document.getElementById("clearAllButton");
const filterTabs = document.querySelectorAll(".filter-tab");

let notifications = [];
let activeFilter = "all";

function initializeNotifications() {
    const center = window.CustomerNotificationCenter;
    if (!center) {
        if (emptyState) emptyState.style.display = "block";
        return;
    }

    Promise.resolve(center.ready).finally(() => {
        notifications = center.getAll();
        renderNotifications();
    });

    window.addEventListener("jyoti:notifications-updated", event => {
        notifications = Array.isArray(event.detail) ? event.detail : center.getAll();
        renderNotifications();
    });

    if (notificationSearch) {
        notificationSearch.addEventListener("input", renderNotifications);
    }

    filterTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            filterTabs.forEach(item => item.classList.remove("active"));
            tab.classList.add("active");
            activeFilter = (tab.dataset.filter || tab.textContent).trim().toLowerCase();
            renderNotifications();
        });
    });

    if (markAllButton) {
        markAllButton.addEventListener("click", () => center.markAllRead());
    }

    if (clearAllButton) {
        clearAllButton.addEventListener("click", () => {
            if (window.confirm("Clear all customer notifications?")) center.clearAll();
        });
    }

    if (notificationList) {
        notificationList.addEventListener("click", event => {
            const button = event.target.closest("[data-notification-id]");
            if (button) center.toggleRead(button.dataset.notificationId);
        });
    }
}

function renderNotifications() {
    if (!notificationList) return;
    notificationList.replaceChildren();

    const searchTerm = (notificationSearch?.value || "").trim().toLowerCase();
    const filtered = notifications.filter(item => {
        const isRead = Boolean(item.read);
        const filterMatches = activeFilter === "all" ||
            (activeFilter === "read" && isRead) ||
            (activeFilter === "unread" && !isRead);
        const searchableText = [item.title, item.message, item.orderId, item.productName]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();
        return filterMatches && searchableText.includes(searchTerm);
    });

    updateCounters();
    if (emptyState) emptyState.style.display = filtered.length ? "none" : "block";

    filtered.forEach(item => {
        const isOrder = item.type === "order";
        const statusClass = isOrder
            ? String(item.status || "awaiting-pickup").toLowerCase().replace(/[^a-z]+/g, "-")
            : "";
        const card = document.createElement("article");
        card.className = `notification-card${item.read ? "" : " unread"}${isOrder ? ` order-update ${statusClass}` : " product-update"}`;

        const icon = document.createElement("div");
        icon.className = `notification-icon${statusClass ? ` ${statusClass}` : ""}`;
        icon.innerHTML = isOrder
            ? '<i class="fa-solid fa-store" aria-hidden="true"></i>'
            : '<i class="fa-solid fa-box-open" aria-hidden="true"></i>';

        const content = document.createElement("div");
        content.className = "notification-content";

        const top = document.createElement("div");
        top.className = "notification-top";
        const title = document.createElement("h3");
        title.textContent = item.title || (isOrder ? "Order update" : "Product update");
        top.appendChild(title);
        if (isOrder && item.status) {
            const status = document.createElement("span");
            status.className = `order-status-badge ${item.status.toLowerCase().replace(/[^a-z]+/g, "-")}`;
            status.textContent = item.status;
            top.appendChild(status);
        }
        if (!item.read) {
            const unreadBadge = document.createElement("span");
            unreadBadge.className = "unread-badge";
            unreadBadge.textContent = "New";
            top.appendChild(unreadBadge);
        }

        const message = document.createElement("p");
        message.textContent = item.message || (isOrder
            ? "Your order status has been updated."
            : "Product information has changed.");

        if (isOrder && Array.isArray(item.products) && item.products.length) {
            const itemsSection = document.createElement("section");
            itemsSection.className = "notification-order-items";
            const itemsHeading = document.createElement("h4");
            itemsHeading.textContent = `Items in order (${item.products.length})`;
            const itemsList = document.createElement("ul");

            item.products.forEach(product => {
                const row = document.createElement("li");
                const productName = document.createElement("span");
                productName.className = "ordered-product-name";
                productName.textContent = product.name || "Product";

                const quantity = Number(product.quantity) || 1;
                const details = document.createElement("span");
                details.className = "ordered-product-details";
                details.textContent = `${quantity} × ₹${Number(product.price || 0).toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;

                const lineTotal = document.createElement("strong");
                lineTotal.textContent = `₹${(quantity * Number(product.price || 0)).toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;

                row.append(productName, details, lineTotal);
                itemsList.appendChild(row);
            });

            itemsSection.append(itemsHeading, itemsList);
            content.appendChild(itemsSection);
        }

        const date = document.createElement("div");
        date.className = "notification-date";
        date.innerHTML = '<i class="fa-regular fa-clock" aria-hidden="true"></i>';
        date.append(` ${formatTimeAgo(item.createdAt)}`);
        if (isOrder) {
            date.append(` · ${item.pickupLocation || "Jyoti Enterprise Counter pickup"}`);
        }
        if (isOrder && Number(item.amount) > 0) {
            const amount = document.createElement("strong");
            amount.textContent = ` · ₹${Number(item.amount).toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;
            date.appendChild(amount);
        }

        content.append(top, message, date);

        const actions = document.createElement("div");
        actions.className = "notification-actions";
        const toggleButton = document.createElement("button");
        toggleButton.type = "button";
        toggleButton.dataset.notificationId = String(item.id);
        toggleButton.setAttribute("aria-label", item.read ? "Mark as unread" : "Mark as read");
        toggleButton.title = toggleButton.getAttribute("aria-label");
        toggleButton.innerHTML = item.read
            ? '<i class="fa-regular fa-circle" aria-hidden="true"></i>'
            : '<i class="fa-solid fa-circle-check" aria-hidden="true"></i>';
        actions.appendChild(toggleButton);

        card.append(icon, content, actions);
        notificationList.appendChild(card);
    });
}

function updateCounters() {
    const total = notifications.length;
    const unread = notifications.filter(item => !item.read).length;
    if (allCount) allCount.textContent = String(total);
    if (unreadCount) unreadCount.textContent = String(unread);
    if (readCount) readCount.textContent = String(total - unread);
}

function formatTimeAgo(value) {
    const date = new Date(value || Date.now());
    if (Number.isNaN(date.getTime())) return "Just now";
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return "Just now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return date.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
}

document.addEventListener("DOMContentLoaded", initializeNotifications);
