/* =========================================
   JYOTI ENTERPRISE
   CUSTOMER DASHBOARD - REAL-TIME SYNC
========================================= */

const BACKEND_URL = "http://127.0.0.1:5000";

/* =========================================
   LOGGED-IN CUSTOMER
========================================= */

const customerData =
    JSON.parse(sessionStorage.getItem("jyotiCustomer")) || {
        full_name: "Customer",
        email: "customer@example.com"
    };

/* =========================================
   CUSTOMER DISPLAY
========================================= */

const customerName = document.getElementById("customerName");
const customerAvatar = document.getElementById("customerAvatar");

if (customerName) {
    customerName.textContent =
        customerData.full_name || customerData.name || "Customer";
}

if (customerAvatar) {
    const displayName =
        customerData.full_name || customerData.name || "Customer";
    customerAvatar.textContent = displayName.charAt(0).toUpperCase();
}

/* =========================================
   CATEGORY DATA (FALLBACK)
========================================= */

let categories = [
    { name: "Books", count: 120, icon: "fa-book" },
    { name: "Notebooks", count: 85, icon: "fa-book-open" },
    { name: "Pens", count: 65, icon: "fa-pen" },
    { name: "School Supplies", count: 75, icon: "fa-school" },
    { name: "Art & Craft", count: 45, icon: "fa-palette" },
    { name: "Office Supplies", count: 55, icon: "fa-briefcase" }
];

/* =========================================
   POPULAR PRODUCTS (FALLBACK)
========================================= */

let products = [
    {
        id: 1,
        name: "NCERT Mathematics Book",
        category: "Books",
        price: 185,
        stock: 20,
        description: "Mathematics textbook suitable for school students.",
        icon: "📚",
        status: "Available"
    },
    {
        id: 3,
        name: "Classmate Notebook",
        category: "Notebooks",
        price: 75,
        stock: 50,
        description: "Quality ruled notebook for everyday writing.",
        icon: "📒",
        status: "Available"
    },
    {
        id: 5,
        name: "Reynolds Ball Pen Blue",
        category: "Pens",
        price: 10,
        stock: 100,
        description: "Smooth writing blue ball pen.",
        icon: "🖊️",
        status: "Available"
    },
    {
        id: 7,
        name: "Camlin Colour Set",
        category: "Art & Craft",
        price: 120,
        stock: 25,
        description: "Colour set suitable for school artwork.",
        icon: "🎨",
        status: "Available"
    }
];

/* =========================================
   ELEMENTS
========================================= */

const categoryGrid = document.getElementById("categoryGrid");
const productGrid = document.getElementById("productGrid");
const navbarSearch = document.getElementById("navbarSearch");

/* =========================================
   CATEGORY ICON MAPPER
========================================= */

function getCategoryIcon(name) {
    const lower = (name || "").toLowerCase();
    if (lower.includes("book") && !lower.includes("note")) return "fa-book";
    if (lower.includes("note")) return "fa-book-open";
    if (lower.includes("pen")) return "fa-pen";
    if (lower.includes("school")) return "fa-school";
    if (lower.includes("art") || lower.includes("craft")) return "fa-palette";
    if (lower.includes("office")) return "fa-briefcase";
    return "fa-box";
}

/* =========================================
   RENDER CATEGORIES
========================================= */

function renderCategories() {
    if (!categoryGrid) return;
    categoryGrid.innerHTML = "";

    categories.forEach(function (category) {
        const card = document.createElement("div");
        card.className = "category-card";
        card.setAttribute("data-category-name", category.name);

        card.innerHTML = `
            <div class="category-icon">
                <i class="fa-solid ${category.icon || getCategoryIcon(category.name)}"></i>
            </div>
            <h3>${category.name}</h3>
            <span>${category.count || category.products || 0} Products</span>
        `;

        card.addEventListener("click", function () {
            const categoryName = encodeURIComponent(category.name);
            window.location.href = "../products/products.html?category=" + categoryName;
        });

        categoryGrid.appendChild(card);
    });
}

/* =========================================
   RENDER POPULAR PRODUCTS
========================================= */

function renderProducts(productList = products) {
    if (!productGrid) return;
    productGrid.innerHTML = "";

    if (productList.length === 0) {
        productGrid.innerHTML = `
            <div style="
                grid-column: 1 / -1;
                padding: 50px;
                text-align: center;
                color: #94A3B8;
                background: white;
                border: 1px solid #E2E8F0;
                border-radius: 10px;
            ">
                No products found.
            </div>
        `;
        return;
    }

    productList.forEach(function (product) {
        const card = document.createElement("div");
        card.className = "product-card";
        card.setAttribute("data-product-id", product.id);
        card.style.cursor = "pointer";

        const isAvailable = (product.stock === undefined || product.stock > 0) && product.status !== "Out of Stock";

        card.innerHTML = `
            <div class="product-image">
                ${product.icon || "📦"}
            </div>
            <div class="product-content">
                <span class="product-category">${product.category}</span>
                <h3 class="product-name">${product.name}</h3>
                <p class="product-description">${product.description || ""}</p>
                <div class="product-bottom">
                    <strong class="product-price">₹${parseFloat(product.price).toFixed(0)}</strong>
                    <span class="product-status" style="
                        background: ${isAvailable ? "#ECFDF3" : "#FEF2F2"};
                        color: ${isAvailable ? "#16A34A" : "#DC2626"};
                    ">
                        ${isAvailable ? "Available" : "Out of Stock"}
                    </span>
                </div>
            </div>
        `;

        card.addEventListener("click", function () {
            window.location.href = "../products/products.html?productId=" + encodeURIComponent(product.id);
        });

        productGrid.appendChild(card);
    });
}

/* =========================================
   DASHBOARD SEARCH
========================================= */

if (navbarSearch) {
    navbarSearch.addEventListener("input", function () {
        const searchValue = navbarSearch.value.toLowerCase().trim();

        if (!searchValue) {
            renderProducts();
            return;
        }

        const filteredProducts = products.filter(function (product) {
            return (
                product.name.toLowerCase().includes(searchValue) ||
                product.category.toLowerCase().includes(searchValue)
            );
        });

        renderProducts(filteredProducts);
    });
}

/* =========================================
   SIDEBAR & OVERLAY
========================================= */

const customerSidebar = document.getElementById("customerSidebar");
const sidebarToggle = document.getElementById("sidebarToggle");

if (sidebarToggle && customerSidebar) {
    sidebarToggle.addEventListener("click", function () {
        customerSidebar.classList.toggle("open");
        if (customerSidebar.classList.contains("open")) {
            createSidebarOverlay();
        } else {
            removeSidebarOverlay();
        }
    });
}

function createSidebarOverlay() {
    let overlay = document.querySelector(".sidebar-overlay");
    if (overlay) return;

    overlay = document.createElement("div");
    overlay.className = "sidebar-overlay";
    overlay.style.cssText = `position: fixed; inset: 0; z-index: 999; background: rgba(15,23,42,.35);`;
    document.body.appendChild(overlay);

    overlay.addEventListener("click", function () {
        if (customerSidebar) {
            customerSidebar.classList.remove("open");
        }
        removeSidebarOverlay();
    });
}

function removeSidebarOverlay() {
    const overlay = document.querySelector(".sidebar-overlay");
    if (overlay) overlay.remove();
}

/* =========================================
   LOGOUT
========================================= */

const logoutButton = document.getElementById("logoutButton");

if (logoutButton) {
    logoutButton.addEventListener("click", function (event) {
        if (!confirm("Are you sure you want to logout?")) {
            event.preventDefault();
            return;
        }
        sessionStorage.removeItem("jyotiCustomer");
        sessionStorage.removeItem("jyotiLoggedIn");
        event.preventDefault();
        window.location.href = "../login.html";
    });
}

/* =========================================
   NOTIFICATION COUNT
========================================= */

function updateDashboardNotificationCount() {
    const notificationCount = document.getElementById("notificationCount");
    if (!notificationCount) return;

    let notifications = [];
    try {
        const savedNotifications = JSON.parse(localStorage.getItem("jyotiNotifications") || "[]");
        if (Array.isArray(savedNotifications)) notifications = savedNotifications;
    } catch (error) {
        console.error("Could not read customer notification count:", error);
    }

    const unreadCount = notifications.filter(n => !n.read).length;

    if (unreadCount > 0) {
        notificationCount.textContent = unreadCount;
        notificationCount.style.display = "flex";
    } else {
        notificationCount.style.display = "none";
    }
}

/* =========================================
   FETCH INITIAL DATA FROM BACKEND
========================================= */

async function fetchDashboardData() {
    try {
        const [prodRes, catRes] = await Promise.all([
            fetch(`${BACKEND_URL}/api/products`),
            fetch(`${BACKEND_URL}/api/categories`)
        ]);

        if (prodRes.ok) {
            const prodData = await prodRes.json();
            if (prodData.success && prodData.products && prodData.products.length > 0) {
                // Populate first 4 products for dashboard spotlight
                products = prodData.products.slice(0, 4).map(p => ({
                    id: p.id,
                    name: p.name,
                    category: p.category_name || "General",
                    price: parseFloat(p.price),
                    stock: parseInt(p.stock),
                    description: p.description,
                    icon: p.category_name === "Books" ? "📚" : p.category_name === "Pens" ? "🖊️" : "📦",
                    status: (p.stock > 0 && p.status !== "Out of Stock") ? "Available" : "Out of Stock"
                }));
                renderProducts();
            }
        }

        if (catRes.ok) {
            const catData = await catRes.json();
            if (catData.success && catData.categories && catData.categories.length > 0) {
                categories = catData.categories.map(c => ({
                    name: c.name,
                    count: c.products || 0,
                    icon: getCategoryIcon(c.name)
                }));
                renderCategories();
            }
        }
    } catch (err) {
        console.warn("Could not connect to Flask backend; showing static fallback items.", err);
    }
}

/* =========================================
   REAL-TIME WEBSOCKET LISTENERS
========================================= */

function setupDashboardSocket() {
    if (typeof io === "undefined") {
        console.warn("Socket.IO client library not found. Real-time updates disabled.");
        return;
    }

    const socket = io(BACKEND_URL);

    // 1. Live Price & Stock Updates
    socket.on("product_updated", (data) => {
        const card = document.querySelector(`.product-card[data-product-id="${data.id}"]`);
        
        // Update in-memory data
        const item = products.find(p => p.id === Number(data.id));
        if (item) {
            if (data.price !== undefined) item.price = parseFloat(data.price);
            if (data.stock !== undefined) item.stock = parseInt(data.stock);
            if (data.name !== undefined) item.name = data.name;
            item.status = (item.stock > 0 && data.status !== "Out of Stock") ? "Available" : "Out of Stock";
        }

        // Live DOM Patching
        if (card) {
            if (data.price !== undefined) {
                const priceEl = card.querySelector(".product-price");
                if (priceEl) priceEl.textContent = `₹${parseFloat(data.price).toFixed(0)}`;
            }

            if (data.stock !== undefined || data.status !== undefined) {
                const statusEl = card.querySelector(".product-status");
                const isAvailable = (data.stock > 0) && data.status !== "Out of Stock";
                if (statusEl) {
                    statusEl.textContent = isAvailable ? "Available" : "Out of Stock";
                    statusEl.style.background = isAvailable ? "#ECFDF3" : "#FEF2F2";
                    statusEl.style.color = isAvailable ? "#16A34A" : "#DC2626";
                }
            }

            // Pulse effect to indicate a live change
            card.style.transition = "transform 0.2s ease, box-shadow 0.2s ease";
            card.style.transform = "scale(1.02)";
            card.style.boxShadow = "0 8px 24px rgba(30, 58, 138, 0.15)";
            setTimeout(() => {
                card.style.transform = "";
                card.style.boxShadow = "";
            }, 600);
        }
    });

    // 2. Remove card if admin deleted it
    socket.on("product_deleted", (data) => {
        products = products.filter(p => p.id !== Number(data.id));
        const card = document.querySelector(`.product-card[data-product-id="${data.id}"]`);
        if (card) {
            card.style.transition = "opacity 0.3s ease, transform 0.3s ease";
            card.style.opacity = "0";
            card.style.transform = "scale(0.9)";
            setTimeout(() => card.remove(), 300);
        }
    });
}

/* =========================================
   INITIALIZE
========================================= */

renderCategories();
renderProducts();
updateDashboardNotificationCount();
fetchDashboardData();
setupDashboardSocket();