/* =====================================================
   JYOTI ENTERPRISE
   CUSTOMER CHECKOUT
===================================================== */

const CART_KEY = "jyotiCart";


// =====================================================
// GET CART
// =====================================================

function getCart() {

    try {

        const savedCart = localStorage.getItem(CART_KEY);

        if (!savedCart) {
            return [];
        }

        const cart = JSON.parse(savedCart);

        return Array.isArray(cart) ? cart : [];

    } catch (error) {

        console.error("Error reading cart:", error);

        return [];
    }
}


// =====================================================
// FORMAT PRICE
// =====================================================

function formatPrice(price) {

    return "₹" + Number(price).toLocaleString("en-IN");

}


// =====================================================
// DISPLAY CHECKOUT ITEMS
// =====================================================

function displayCheckoutItems() {

    const cart = getCart();

    const container =
        document.getElementById("checkoutItems");

    const subtotalElement =
        document.getElementById("checkoutSubtotal");

    const deliveryElement =
        document.getElementById("checkoutDelivery");

    const totalElement =
        document.getElementById("checkoutTotal");


    if (!container) {
        return;
    }


    container.innerHTML = "";


    // =================================================
    // EMPTY CART
    // =================================================

    if (cart.length === 0) {

        container.innerHTML = `
            <p style="
                color:#6b7280;
                font-size:14px;
                padding:15px 0;
            ">
                Your cart is empty.
            </p>
        `;

        subtotalElement.textContent = "₹0";
        deliveryElement.textContent = "₹0";
        totalElement.textContent = "₹0";

        return;
    }


    // =================================================
    // CALCULATE TOTAL
    // =================================================

    let subtotal = 0;


    cart.forEach(function(item) {

        const quantity =
            Number(item.quantity) || 1;

        const price =
            Number(item.price) || 0;

        const itemTotal =
            price * quantity;

        subtotal += itemTotal;


        // =================================================
        // CREATE ITEM
        // =================================================

        const itemElement =
            document.createElement("div");

        itemElement.className =
            "checkout-item";


        itemElement.innerHTML = `

            <div>

                <div class="checkout-item-name">
                    ${item.name || "Product"}
                </div>

                <div class="checkout-item-quantity">
                    Quantity: ${quantity}
                </div>

            </div>

            <div class="checkout-item-price">
                ${formatPrice(itemTotal)}
            </div>

        `;


        container.appendChild(itemElement);

    });


    // =================================================
    // DELIVERY
    // =================================================

    const delivery = 0;


    // =================================================
    // FINAL TOTAL
    // =================================================

    const finalTotal =
        subtotal + delivery;


    subtotalElement.textContent =
        formatPrice(subtotal);

    deliveryElement.textContent =
        delivery === 0
            ? "Store pickup · Free"
            : formatPrice(delivery);

    totalElement.textContent =
        formatPrice(finalTotal);

}


// =====================================================
// VALIDATE PHONE
// =====================================================

function validatePhone(phone) {

    return /^[6-9][0-9]{9}$/.test(phone);

}


// =====================================================
// VALIDATE PIN CODE
// =====================================================

// =====================================================
// PLACE ORDER
// =====================================================

async function placeOrder(event) {

    event.preventDefault();


    const cart = getCart();


    // =================================================
    // CHECK CART
    // =================================================

    if (cart.length === 0) {

        alert(
            "Your cart is empty. Please add products first."
        );

        return;
    }


    // =================================================
    // GET FORM VALUES
    // =================================================

    const name =
        document.getElementById("customerName")
            .value.trim();

    const phone =
        document.getElementById("phone")
            .value.trim();

    const email =
        document.getElementById("email")
            .value.trim();

    // =================================================
    // VALIDATE PHONE
    // =================================================

    if (!validatePhone(phone)) {

        alert(
            "Please enter a valid 10-digit Indian phone number."
        );

        document.getElementById("phone").focus();

        return;
    }


    // =================================================
    // GET PAYMENT METHOD
    // =================================================

    const paymentElement =
        document.querySelector(
            'input[name="payment"]:checked'
        );


    const payment =
        paymentElement
            ? paymentElement.value
            : "Cash on Delivery";


    // =================================================
    // CALCULATE TOTAL
    // =================================================

    let subtotal = 0;


    cart.forEach(function(item) {

        const quantity =
            Number(item.quantity) || 1;

        const price =
            Number(item.price) || 0;

        subtotal += price * quantity;

    });


    const delivery = 0;


    const total =
        subtotal + delivery;


    // =================================================
    // CREATE ORDER
    // =================================================

    const order = {

        orderId:
            "JE" +
            Date.now(),

        customerName: name,

        phone: phone,

        email: email,

        fulfillmentType: "Store pickup",

        pickupLocation: "Jyoti Enterprise Counter, Main Branch",

        paymentMethod: "Pay at store counter",

        items: cart,

        subtotal: subtotal,

        delivery: delivery,

        total: total,

        orderDate:
            new Date().toLocaleString("en-IN"),

        status: "Order Placed"

    };


    const submitButton =
        event.submitter ||
        document.querySelector(".place-order-btn");

    const originalButtonText =
        submitButton
            ? submitButton.textContent.trim()
            : "Place Order";

    if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = "Placing order...";
    }

    let placedOrderId = null;
    let placedNotificationId = null;
    let userId = null;

    try {
        const sessionUser =
            JSON.parse(sessionStorage.getItem("jyotiCustomer") || "{}");

        const localUser =
            JSON.parse(localStorage.getItem("currentUser") || "{}");

        const savedUserId =
            sessionUser.id || sessionUser.user_id ||
            localUser.id || localUser.user_id;

        if (savedUserId !== undefined && savedUserId !== null && String(savedUserId).trim() !== "") {
            const numericUserId = Number(savedUserId);
            if (Number.isSafeInteger(numericUserId)) {
                userId = numericUserId;
            }
        }
    } catch (error) {
        console.warn("Customer session could not be read; placing order as guest.", error);
    }

    try {
        const response = await fetch("http://127.0.0.1:5000/api/orders", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: userId,
                customer_name: name,
                customer_phone: phone,
                customer_email: email,
                fulfillment_type: "store_pickup",
                payment_method: "Pay at counter",
                total_amount: total,
                items: cart.map(function(item) {
                    return {
                        product_id: Number(item.id || item.product_id),
                        product_name: item.name || "Product",
                        quantity: Number(item.quantity) || 1,
                        price: Number(item.price) || 0
                    };
                })
            })
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "The order could not be placed.");
        }

        placedOrderId = result.order_id;
        placedNotificationId = result.notification_id || `order-${placedOrderId}-placed`;
        order.backendOrderId = placedOrderId;
        order.orderId = `JE${placedOrderId}`;
        sessionStorage.setItem("jyotiCustomerEmail", email.trim().toLowerCase());
    } catch (error) {
        console.error("Order submission failed:", error);
        alert(error.message || "Could not reach the order service. Please try again.");
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.textContent = originalButtonText;
        }
        return;
    }


    // =================================================
    // SAVE ORDER
    // =================================================

    let orders = [];


    try {

        const savedOrders =
            localStorage.getItem("jyotiOrders");

        if (savedOrders) {

            const parsedOrders =
                JSON.parse(savedOrders);

            if (Array.isArray(parsedOrders)) {

                orders = parsedOrders;

            }

        }

    } catch (error) {

        console.error(
            "Error reading orders:",
            error
        );

    }


    orders.push(order);


    localStorage.setItem(
        "jyotiOrders",
        JSON.stringify(orders)
    );


    // =================================================
    // CREATE NOTIFICATION
    // =================================================

    const notification = {
        id: placedNotificationId,
        type: "order",
        eventType: "order_placed",
        orderId: String(placedOrderId),
        title: `Order #${placedOrderId} placed`,
        status: "Awaiting Pickup",
        message: `Order #${placedOrderId} was placed and is awaiting pickup at Jyoti Enterprise Counter.`,
        pickupLocation: "Jyoti Enterprise Counter, Main Branch",
        amount: total,
        createdAt: new Date().toISOString(),
        read: false
    };


    let notifications = [];


    try {

        const savedNotifications =
            localStorage.getItem("jyotiNotifications");

        if (savedNotifications) {

            const parsedNotifications =
                JSON.parse(savedNotifications);

            if (Array.isArray(parsedNotifications)) {

                notifications = parsedNotifications;

            }

        }

    } catch (error) {

        console.error(
            "Error reading notifications:",
            error
        );

    }


    notifications = notifications.filter(
        item => String(item.id) !== String(notification.id)
    );
    notifications.unshift(notification);


    localStorage.setItem(
        "jyotiNotifications",
        JSON.stringify(notifications)
    );


    // =================================================
    // CLEAR CART
    // =================================================

    localStorage.removeItem(CART_KEY);


    // =================================================
    // SHOW SUCCESS MESSAGE
    // =================================================

    const successOverlay =
        document.getElementById("orderSuccess");

    const successOrderMessage =
        document.getElementById("successOrderMessage");

    if (successOrderMessage) {
        successOrderMessage.textContent = `Order #${placedOrderId} is confirmed and awaiting pickup at Jyoti Enterprise Counter.`;
    }

    if (successOverlay) {

        successOverlay.style.display = "flex";

    }

}


// =====================================================
// FORM SUBMIT
// =====================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const checkoutForm =
            document.getElementById("checkoutForm");


        if (checkoutForm) {

            checkoutForm.addEventListener(
                "submit",
                placeOrder
            );

        }


        displayCheckoutItems();

    }
);