/* =========================================
   JYOTI ENTERPRISE
   CUSTOMER CATEGORIES MODULE - REAL-TIME SYNC
========================================= */

const BACKEND_URL = "http://127.0.0.1:5000";

let categories = [
    {
        id: 1,
        name: "Books",
        count: 120,
        icon: "fa-book",
        description: "School books, reference books and general books."
    },
    {
        id: 2,
        name: "Notebooks",
        count: 85,
        icon: "fa-book-open",
        description: "Ruled, unruled and long notebooks."
    },
    {
        id: 3,
        name: "Pens",
        count: 65,
        icon: "fa-pen",
        description: "Ball pens, gel pens and writing pens."
    },
    {
        id: 4,
        name: "School Supplies",
        count: 75,
        icon: "fa-school",
        description: "Essential supplies for school students."
    },
    {
        id: 5,
        name: "Art & Craft",
        count: 45,
        icon: "fa-palette",
        description: "Colours, drawing books and craft materials."
    },
    {
        id: 6,
        name: "Office Supplies",
        count: 55,
        icon: "fa-briefcase",
        description: "Stationery products for office requirements."
    }
];

/* =========================================
   ELEMENTS
========================================= */

const categoryGrid = document.getElementById("categoryGrid");
const categoryCount = document.getElementById("categoryCount");
const emptyState = document.getElementById("emptyState");

const categorySearch = document.getElementById("categorySearch");
const topSearch = document.getElementById("topSearch");

const sidebar = document.querySelector(".sidebar");
const overlay = document.querySelector(".sidebar-overlay");
const menuButton = document.querySelector(".menu-toggle");

/* =========================================
   ICON HELPER FOR DYNAMIC CATEGORIES
========================================= */

function getCategoryIcon(name) {
    const lower = (name || "").toLowerCase();
    if (lower.includes("book") && !lower.includes("note")) return "fa-book";
    if (lower.includes("note")) return "fa-book-open";
    if (lower.includes("pen")) return "fa-pen";
    if (lower.includes("school")) return "fa-school";
    if (lower.includes("art") || lower.includes("craft")) return "fa-palette";
    if (lower.includes("office")) return "fa-briefcase";
    return "fa-box";
}

/* =========================================
   RENDER CATEGORIES
========================================= */

function renderCategories(categoryList = categories) {
    if (!categoryGrid) return;

    categoryGrid.innerHTML = "";

    if (categoryCount) {
        categoryCount.textContent = categoryList.length;
    }

    if (categoryList.length === 0) {
        if (emptyState) emptyState.style.display = "block";
        return;
    }

    if (emptyState) emptyState.style.display = "none";

    categoryList.forEach(function(category) {
        const card = document.createElement("div");
        card.className = "category-card";
        card.setAttribute("data-category-id", category.id || "");

        card.innerHTML = `
            <div class="category-icon">
                <i class="fa-solid ${category.icon || getCategoryIcon(category.name)}"></i>
            </div>

            <h3>
                ${category.name}
            </h3>

            <span>
                ${category.count ?? category.products ?? 0} Products
            </span>

            <p>
                ${category.description || "Stationery products for wholesale and institutional orders."}
            </p>

            <a href="../products/products.html?category=${encodeURIComponent(category.name)}" class="view-products">
                View Products →
            </a>
        `;

        /* CATEGORY CLICK */
        card.addEventListener("click", function(event) {
            event.preventDefault();
            const categoryName = encodeURIComponent(category.name);
            window.location.href = `../products/products.html?category=${categoryName}`;
        });

        categoryGrid.appendChild(card);
    });
}

/* =========================================
   DATABASE FETCH FROM FLASK
========================================= */

async function fetchCategoriesFromBackend() {
    try {
        const response = await fetch(`${BACKEND_URL}/api/categories`);
        if (!response.ok) throw new Error("Categories endpoint unavailable");

        const data = await response.json();
        if (data.success && data.categories && data.categories.length > 0) {
            categories = data.categories.map(c => ({
                id: c.id,
                name: c.name,
                count: c.products || 0,
                icon: getCategoryIcon(c.name),
                description: c.description || "Stationery products for wholesale and institutional orders."
            }));
            renderCategories();
        }
    } catch (err) {
        console.warn("Using default category layout:", err);
    }
}

/* =========================================
   CATEGORY SEARCH
========================================= */

function searchCategories(value) {
    const searchValue = value.toLowerCase().trim();

    const filteredCategories = categories.filter(function(category) {
        return (
            category.name.toLowerCase().includes(searchValue) ||
            (category.description && category.description.toLowerCase().includes(searchValue))
        );
    });

    renderCategories(filteredCategories);
}

/* =========================================
   CATEGORY SEARCH EVENTS
========================================= */

if (categorySearch) {
    categorySearch.addEventListener("input", function() {
        if (topSearch) topSearch.value = categorySearch.value;
        searchCategories(categorySearch.value);
    });
}

if (topSearch) {
    topSearch.addEventListener("input", function() {
        if (categorySearch) categorySearch.value = topSearch.value;
        searchCategories(topSearch.value);
    });
}

/* =========================================
   MOBILE SIDEBAR
========================================= */

if (menuButton) {
    menuButton.addEventListener("click", function() {
        if (sidebar) sidebar.classList.toggle("active");
        if (overlay) overlay.classList.toggle("active");
    });
}

if (overlay) {
    overlay.addEventListener("click", function() {
        if (sidebar) sidebar.classList.remove("active");
        overlay.classList.remove("active");
    });
}

const sidebarLinks = document.querySelectorAll(".sidebar a");
sidebarLinks.forEach(function(link) {
    link.addEventListener("click", function() {
        if (sidebar) sidebar.classList.remove("active");
        if (overlay) overlay.classList.remove("active");
    });
});

/* =========================================
   LOGOUT
========================================= */

const logoutButton = document.querySelector(".logout, #logoutButton");
if (logoutButton) {
    logoutButton.addEventListener("click", function(event) {
        event.preventDefault();
        const confirmLogout = confirm("Are you sure you want to logout?");
        if (confirmLogout) {
            sessionStorage.removeItem("jyotiCustomer");
            sessionStorage.removeItem("jyotiLoggedIn");
            window.location.href = "../login.html";
        }
    });
}

/* =========================================
   REAL-TIME WEBSOCKET LISTENERS
========================================= */

function setupCategoriesSocket() {
    if (typeof io === "undefined") {
        console.warn("Socket.IO client library not loaded. Live category sync disabled.");
        return;
    }

    const socket = io(BACKEND_URL);

    // Refresh category counts whenever products are added or removed
    socket.on("product_added", () => {
        fetchCategoriesFromBackend();
    });

    socket.on("product_deleted", () => {
        fetchCategoriesFromBackend();
    });
}

/* =========================================
   INITIALIZE
========================================= */

renderCategories();
fetchCategoriesFromBackend();
setupCategoriesSocket();