from flask import Blueprint, jsonify
from backend.config.db import get_db_connection

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/api/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            # 1. Product & Stock Counts
            cursor.execute("""
                SELECT 
                    COUNT(*) AS total_products,
                    SUM(CASE WHEN stock <= minimum_stock AND stock > 0 THEN 1 ELSE 0 END) AS low_stock,
                    SUM(CASE WHEN stock > minimum_stock THEN 1 ELSE 0 END) AS in_stock,
                    SUM(CASE WHEN stock <= 0 THEN 1 ELSE 0 END) AS out_of_stock
                FROM products
            """)
            prod_stats = cursor.fetchone() or {}

            # 2. Total Categories
            cursor.execute("SELECT COUNT(*) AS total_categories FROM categories")
            cat_stats = cursor.fetchone() or {}

            # 3. Total Customers
            cursor.execute("SELECT COUNT(*) AS total_customers FROM customers")
            cust_stats = cursor.fetchone() or {}

            # 4. Recent 5 Products
            cursor.execute("""
                SELECT p.id, p.name, p.sku, p.price, p.stock, p.status, p.image, p.brand
                FROM products p
                ORDER BY p.id DESC
                LIMIT 5
            """)
            recent_products = cursor.fetchall() or []

        return jsonify({
            'success': True,
            'stats': {
                'total_products': prod_stats.get('total_products', 0) or 0,
                'low_stock': prod_stats.get('low_stock', 0) or 0,
                'in_stock': prod_stats.get('in_stock', 0) or 0,
                'out_of_stock': prod_stats.get('out_of_stock', 0) or 0,
                'total_categories': cat_stats.get('total_categories', 0) or 0,
                'total_customers': cust_stats.get('total_customers', 0) or 0
            },
            'recent_products': recent_products
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()