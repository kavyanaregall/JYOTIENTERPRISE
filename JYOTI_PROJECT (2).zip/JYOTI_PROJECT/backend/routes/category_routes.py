import os
import time
from datetime import datetime, date
from decimal import Decimal
from flask import Blueprint, request, jsonify, current_app
from backend.config.db import get_db_connection

category_bp = Blueprint('categories', __name__)

def clean_row(row):
    if not row:
        return None
    cleaned = {}
    for key, val in row.items():
        if isinstance(val, Decimal):
            cleaned[key] = float(val)
        elif isinstance(val, (datetime, date)):
            cleaned[key] = val.strftime('%d %b %Y')
        else:
            cleaned[key] = val
    return cleaned

# GET /api/categories
@category_bp.route('/api/categories', methods=['GET'])
def get_categories():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                SELECT 
                    c.id, 
                    c.name, 
                    c.description, 
                    c.status, 
                    c.image, 
                    c.created_at,
                    (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS products
                FROM categories c
                ORDER BY c.id DESC
            """
            cursor.execute(query)
            raw_categories = cursor.fetchall()

        categories = [clean_row(cat) for cat in raw_categories]
        return jsonify({'success': True, 'categories': categories}), 200
    except Exception as e:
        print(f"Error fetching categories: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# POST /api/categories
@category_bp.route('/api/categories', methods=['POST'])
def add_category():
    conn = None
    try:
        name = request.form.get('categoryName')
        description = request.form.get('categoryDescription', '')
        status = request.form.get('categoryStatus', 'Active')

        image_filename = None
        if 'categoryImage' in request.files:
            file = request.files['categoryImage']
            if file and file.filename != '':
                ext = os.path.splitext(file.filename)[1].lower()
                clean_name = f"cat_{int(time.time())}_{os.urandom(4).hex()}{ext}"
                upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], 'categories')
                os.makedirs(upload_dir, exist_ok=True)
                file.save(os.path.join(upload_dir, clean_name))
                image_filename = f"/uploads/categories/{clean_name}"

        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                INSERT INTO categories (name, description, status, image, products)
                VALUES (%s, %s, %s, %s, 0)
            """
            cursor.execute(query, (name, description, status, image_filename))
            conn.commit()

        return jsonify({'success': True, 'message': 'Category added successfully'}), 201
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()