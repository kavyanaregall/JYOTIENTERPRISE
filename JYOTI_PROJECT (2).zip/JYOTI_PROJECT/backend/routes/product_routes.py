import os
import time
from datetime import datetime, date
from decimal import Decimal
from flask import Blueprint, request, jsonify, current_app, send_from_directory
from backend.config.db import get_db_connection

product_bp = Blueprint('products', __name__)

def clean_row(row):
    if not row:
        return None
    cleaned = {}
    for key, val in row.items():
        if isinstance(val, Decimal):
            cleaned[key] = float(val)
        elif isinstance(val, (datetime, date)):
            cleaned[key] = val.isoformat()
        else:
            cleaned[key] = val
    return cleaned

# Serve uploaded static images
@product_bp.route('/uploads/<path:filename>', methods=['GET'])
def serve_upload(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)

# GET /api/products - Get all products with joined category name
@product_bp.route('/api/products', methods=['GET'])
def get_products():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                SELECT 
                    p.id,
                    p.name,
                    p.sku,
                    p.category_id,
                    COALESCE(c.name, 'Uncategorized') AS category_name,
                    p.description,
                    p.price,
                    p.stock,
                    p.status,
                    p.image,
                    p.brand,
                    p.minimum_stock,
                    p.created_at
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                ORDER BY p.id DESC
            """
            cursor.execute(query)
            raw_products = cursor.fetchall()
            
        products = [clean_row(p) for p in raw_products]
        return jsonify({'success': True, 'products': products}), 200
    except Exception as e:
        print(f"Error fetching products: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# GET /api/products/<id> - Get single product
@product_bp.route('/api/products/<int:product_id>', methods=['GET'])
def get_single_product(product_id):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                SELECT 
                    p.id,
                    p.name,
                    p.sku,
                    p.category_id,
                    COALESCE(c.name, 'Uncategorized') AS category_name,
                    p.description,
                    p.price,
                    p.stock,
                    p.status,
                    p.image,
                    p.brand,
                    p.minimum_stock,
                    p.created_at
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.id = %s
            """
            cursor.execute(query, (product_id,))
            product = cursor.fetchone()
        
        if not product:
            return jsonify({'success': False, 'message': 'Product not found'}), 404

        return jsonify({'success': True, 'product': clean_row(product)}), 200
    except Exception as e:
        print(f"Error fetching product #{product_id}: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# POST /api/products - Create new product
@product_bp.route('/api/products', methods=['POST'])
def add_product():
    conn = None
    try:
        name = request.form.get('productName')
        sku = request.form.get('productCode')
        category_val = request.form.get('productCategory')
        brand = request.form.get('productBrand')
        price = request.form.get('productPrice', 0)
        stock = request.form.get('productQuantity', 0)
        min_stock = request.form.get('productMinimumStock', 0)
        status = request.form.get('productStatus', 'In Stock')
        description = request.form.get('productDescription', '')

        # Image processing
        image_filename = None
        if 'productImage' in request.files:
            file = request.files['productImage']
            if file and file.filename != '':
                ext = os.path.splitext(file.filename)[1].lower()
                image_filename = f"{int(time.time())}_{os.urandom(6).hex()}{ext}"
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], image_filename)
                file.save(file_path)

        conn = get_db_connection()
        with conn.cursor() as cursor:
            # Map category_val to category_id
            category_id = None
            if category_val:
                cursor.execute("SELECT id FROM categories WHERE name = %s OR id = %s", (category_val, category_val))
                cat_row = cursor.fetchone()
                if cat_row:
                    category_id = cat_row['id']
                else:
                    cursor.execute("INSERT INTO categories (name, status, products) VALUES (%s, 'Active', 0)", (category_val,))
                    category_id = cursor.lastrowid

            query = """
                INSERT INTO products 
                (name, sku, category_id, description, price, stock, status, image, brand, minimum_stock)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (
                name, sku, category_id, description, price, stock, status, image_filename, brand, min_stock
            ))
            conn.commit()

        return jsonify({'success': True, 'message': 'Product added successfully'}), 201
    except Exception as e:
        print(f"Error creating product: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# PUT or POST /api/products/<id> - Update product
@product_bp.route('/api/products/<int:product_id>', methods=['PUT', 'POST'])
def update_product(product_id):
    conn = None
    try:
        name = request.form.get('productName')
        sku = request.form.get('productCode')
        category_val = request.form.get('productCategory')
        brand = request.form.get('productBrand')
        price = request.form.get('productPrice', 0)
        stock = request.form.get('productQuantity', 0)
        min_stock = request.form.get('productMinimumStock', 0)
        status = request.form.get('productStatus', 'In Stock')
        description = request.form.get('productDescription', '')

        conn = get_db_connection()
        with conn.cursor() as cursor:
            category_id = None
            if category_val:
                cursor.execute("SELECT id FROM categories WHERE name = %s OR id = %s", (category_val, category_val))
                cat_row = cursor.fetchone()
                if cat_row:
                    category_id = cat_row['id']
                else:
                    cursor.execute("INSERT INTO categories (name, status, products) VALUES (%s, 'Active', 0)", (category_val,))
                    category_id = cursor.lastrowid

            if 'productImage' in request.files and request.files['productImage'].filename != '':
                file = request.files['productImage']
                ext = os.path.splitext(file.filename)[1].lower()
                image_filename = f"{int(time.time())}_{os.urandom(6).hex()}{ext}"
                file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], image_filename)
                file.save(file_path)

                query = """
                    UPDATE products 
                    SET name=%s, sku=%s, category_id=%s, description=%s, price=%s, stock=%s, status=%s, image=%s, brand=%s, minimum_stock=%s
                    WHERE id=%s
                """
                cursor.execute(query, (name, sku, category_id, description, price, stock, status, image_filename, brand, min_stock, product_id))
            else:
                query = """
                    UPDATE products 
                    SET name=%s, sku=%s, category_id=%s, description=%s, price=%s, stock=%s, status=%s, brand=%s, minimum_stock=%s
                    WHERE id=%s
                """
                cursor.execute(query, (name, sku, category_id, description, price, stock, status, brand, min_stock, product_id))

            conn.commit()

        return jsonify({'success': True, 'message': 'Product updated successfully'}), 200
    except Exception as e:
        print(f"Error updating product #{product_id}: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# DELETE /api/products/<id> - Delete product
@product_bp.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT image FROM products WHERE id = %s", (product_id,))
            row = cursor.fetchone()
            if row and row.get('image'):
                img_path = os.path.join(current_app.config['UPLOAD_FOLDER'], row['image'])
                if os.path.exists(img_path):
                    os.remove(img_path)

            cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
            conn.commit()

        return jsonify({'success': True, 'message': 'Product deleted successfully'}), 200
    except Exception as e:
        print(f"Error deleting product #{product_id}: {e}")
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()