const express = require("express");
const productController = require("../controllers/productController");
const { uploadProductImage } = require("../middleware/productUpload");

const router = express.Router();

router.get("/", productController.getProducts);
router.post("/", uploadProductImage.single("productImage"), productController.addProduct);

module.exports = router;
