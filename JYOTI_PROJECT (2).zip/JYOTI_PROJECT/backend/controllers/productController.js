const fs = require("fs/promises");
const path = require("path");
const pool = require("../config/db");
const { uploadDirectory } = require("../middleware/productUpload");

function imagePath(file) {
    return file ? `/uploads/products/${file.filename}` : "";
}

function publicProduct(row) {
    return {
        id: row.id,
        name: row.name,
        code: row.sku,
        category: row.category_name || "General",
        category_id: row.category_id,
        brand: row.brand || "",
        price: Number(row.price),
        stock: row.stock,
        quantity: row.stock,
        minimum_stock: row.minimum_stock,
        description: row.description || "",
        status: row.status,
        image: row.image || "",
        created_at: row.created_at
    };
}

async function getProducts(req, res) {
    try {
        const [rows] = await pool.execute(
            `SELECT p.id, p.name, p.sku, p.category_id, p.description,
                    p.price, p.stock, p.status, p.image, p.created_at,
                    p.brand, p.minimum_stock,
                    c.name AS category_name
             FROM products p
             LEFT JOIN categories c ON c.id = p.category_id
             ORDER BY p.id DESC`
        );

        res.json({
            success: true,
            products: rows.map(publicProduct)
        });
    } catch (error) {
        console.error("Product list error:", error);
        res.status(500).json({
            success: false,
            message: "Unable to load products."
        });
    }
}

async function addProduct(req, res) {
    const productName = String(req.body.productName || "").trim();
    const productCode = String(req.body.productCode || "").trim();
    const productCategory = String(req.body.productCategory || "").trim();
    const productBrand = String(req.body.productBrand || "").trim();
    const productPrice = Number(req.body.productPrice);
    const productQuantity = Number(req.body.productQuantity);
    const productMinimumStock = req.body.productMinimumStock === ""
        || req.body.productMinimumStock === undefined
        ? 0
        : Number(req.body.productMinimumStock);
    const productStatus = String(req.body.productStatus || "In Stock").trim();
    const productDescription = String(req.body.productDescription || "").trim();
    const uploadedImage = req.file;

    const removeUploadedImage = async () => {
        if (uploadedImage) {
            await fs.unlink(path.join(uploadDirectory, uploadedImage.filename)).catch(() => {});
        }
    };

    if (!productName || !productCode || !productCategory) {
        await removeUploadedImage();
        return res.status(400).json({
            success: false,
            message: "Product name, code and category are required."
        });
    }

    if (!Number.isFinite(productPrice) || productPrice < 0) {
        await removeUploadedImage();
        return res.status(400).json({
            success: false,
            message: "Price must be a valid non-negative number."
        });
    }

    if (!Number.isInteger(productQuantity) || productQuantity < 0) {
        await removeUploadedImage();
        return res.status(400).json({
            success: false,
            message: "Quantity must be a valid non-negative whole number."
        });
    }

    if (!Number.isInteger(productMinimumStock) || productMinimumStock < 0) {
        await removeUploadedImage();
        return res.status(400).json({
            success: false,
            message: "Minimum stock must be a valid non-negative whole number."
        });
    }

    let connection;

    try {
        connection = await pool.getConnection();

        const [categoryRows] = await connection.execute(
            "SELECT id FROM categories WHERE name = ? LIMIT 1",
            [productCategory]
        );

        if (!categoryRows.length) {
            await removeUploadedImage();
            return res.status(400).json({
                success: false,
                message: `Category '${productCategory}' does not exist.`
            });
        }

        const categoryId = categoryRows[0].id;
        const storedImage = imagePath(uploadedImage);

        const [result] = await connection.execute(
            `INSERT INTO products
                (name, sku, category_id, description, price, stock, status, image, brand, minimum_stock)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                productName,
                productCode,
                categoryId,
                productDescription,
                productPrice,
                productQuantity,
                productStatus,
                storedImage,
                productBrand || null,
                productMinimumStock
            ]
        );

        const [rows] = await connection.execute(
            `SELECT p.id, p.name, p.sku, p.category_id, p.description,
                    p.price, p.stock, p.status, p.image, p.created_at,
                    p.brand, p.minimum_stock,
                    c.name AS category_name
             FROM products p
             LEFT JOIN categories c ON c.id = p.category_id
             WHERE p.id = ?`,
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            message: "Product added successfully",
            product: publicProduct(rows[0])
        });
    } catch (error) {
        await removeUploadedImage();

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "Product code already exists."
            });
        }

        console.error("Product create error:", error);
        res.status(500).json({
            success: false,
            message: "Unable to save product."
        });
    } finally {
        if (connection) connection.release();
    }
}

module.exports = {
    getProducts,
    addProduct
};
