const User = require("../models/User");

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function getCredentials(body) {
    return {
        email: String(body.email || "").trim(),
        password: String(body.password || "").trim(),
        role: String(body.role || "").toLowerCase()
    };
}

async function login(req, res) {
    const { email, password, role } = getCredentials(req.body || {});

    if (!email || !password || !role) {
        return res.status(400).json({
            success: false,
            message: "Email, password and role are required"
        });
    }

    if (role !== "admin" && role !== "customer") {
        return res.status(400).json({
            success: false,
            message: "Invalid user role"
        });
    }

    try {
        const user = await User.findByEmail(email, role);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: `${role} account not found`
            });
        }

        if (user.password !== password) {
            return res.status(401).json({
                success: false,
                message: "Incorrect password"
            });
        }

        return res.json({
            success: true,
            message: "Login successful",
            user: User.toPublicUser(user, role)
        });
    } catch (error) {
        console.error("Login error:", error);
        return res.status(500).json({
            success: false,
            message: "Login failed. Please try again."
        });
    }
}

async function register(req, res) {
    const name = String(req.body?.name || "").trim();
    const email = String(req.body?.email || "").trim();
    const phone = String(req.body?.phone || "").trim();
    const password = String(req.body?.password || "").trim();
    const requestedRole = req.body?.role === undefined
        ? "customer"
        : String(req.body.role).toLowerCase();

    if (!name || !email || !phone || !password) {
        return res.status(400).json({
            success: false,
            message: "Name, email, phone and password are required"
        });
    }

    if (!isValidEmail(email)) {
        return res.status(400).json({
            success: false,
            message: "Please enter a valid email address"
        });
    }

    if (password.length < 6) {
        return res.status(400).json({
            success: false,
            message: "Password must contain at least 6 characters"
        });
    }

    if (requestedRole !== "customer") {
        return res.status(403).json({
            success: false,
            message: "Only customer registration is allowed"
        });
    }

    try {
        const existingUser = await User.findByEmail(email, "customer");

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: "This email is already registered."
            });
        }

        await User.createCustomer({ name, email, phone, password });

        return res.status(201).json({
            success: true,
            message: "Customer registered successfully"
        });
    } catch (error) {
        console.error("Registration error:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "This email is already registered."
            });
        }

        return res.status(500).json({
            success: false,
            message: "Registration failed. Please try again."
        });
    }
}

module.exports = {
    login,
    register
};
