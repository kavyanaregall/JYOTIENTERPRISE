const path = require("path");
const express = require("express");
const cors = require("cors");
const pool = require("./config/db");
const authRoutes = require("./routes/authRoutes");
const productRoutes = require("./routes/productRoutes");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);

app.get("/health", async (req, res) => {
    try {
        await pool.query("SELECT 1");
        res.json({
            success: true,
            message: "Server is running"
        });
    } catch (error) {
        console.error("Database health check failed:", error);
        res.status(500).json({
            success: false,
            message: "Server is running but database connection failed"
        });
    }
});

app.use((error, req, res, next) => {
    if (error && error.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json({
            success: false,
            message: "Product image must be 5 MB or smaller."
        });
    }

    if (error) {
        return res.status(400).json({
            success: false,
            message: error.message || "Invalid request."
        });
    }

    next();
});

app.listen(PORT, () => {
    console.log(`Express server running on http://localhost:${PORT}`);
});
