const pool = require("../config/db");

async function findByEmail(email, role) {
    const normalizedRole = String(role || "").toLowerCase();
    let query;

    if (normalizedRole === "admin") {
        query = "SELECT * FROM admin WHERE email = ? LIMIT 1";
    } else if (normalizedRole === "customer") {
        query = "SELECT * FROM users WHERE email = ? AND role = 'customer' LIMIT 1";
    } else {
        throw new Error("Invalid user role");
    }

    const [rows] = await pool.execute(query, [email]);

    return rows.length ? rows[0] : null;
}

async function createCustomer({ name, email, phone, password }) {
    const [result] = await pool.execute(
        "INSERT INTO users (name, email, phone, password, role, status) VALUES (?, ?, ?, ?, 'customer', 'active')",
        [name, email, phone, password]
    );

    return {
        id: result.insertId,
        name,
        email,
        role: "customer"
    };
}

function toPublicUser(user, role) {
    return {
        id: user.id,
        name: user.name,
        email: user.email,
        role: String(role).toLowerCase()
    };
}

module.exports = {
    createCustomer,
    findByEmail,
    toPublicUser
};
