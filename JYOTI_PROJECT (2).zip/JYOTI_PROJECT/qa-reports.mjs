export default async function run(page) {
  await page.waitForFunction(
    () => document.getElementById('kpiTotalOrders')?.textContent !== '0',
    { timeout: 20000 }
  )

  const before = await page.evaluate(() => ({
    chartJs: typeof Chart,
    canvasW: document.getElementById('orderStatusChart')?.getBoundingClientRect().width,
    kpiOrders: document.getElementById('kpiTotalOrders').textContent,
    kpiRevenue: document.getElementById('kpiRevenue').textContent,
    kpiStockValue: document.getElementById('kpiStockValuation').textContent,
    orderRows: document.querySelectorAll('#ordersReportTableBody tr').length,
    productRows: document.querySelectorAll('#productReportBody tr').length,
    logCount: document.getElementById('orderLogCount')?.textContent
  }))

  const filter = await page.$('#filterInput')
  await filter.fill('pen')
  await page.waitForTimeout(300)
  const filteredRows = await page.evaluate(
    () => document.querySelectorAll('#productReportBody tr').length
  )
  await filter.fill('')
  await page.waitForTimeout(300)
  const restoredRows = await page.evaluate(
    () => document.querySelectorAll('#productReportBody tr').length
  )

  const csv = await page.evaluate(() => {
    const btn = document.getElementById('downloadCsvBtn')
    let captured = null
    const realCreate = URL.createObjectURL
    const realClick = HTMLAnchorElement.prototype.click
    URL.createObjectURL = (blob) => { captured = blob; return 'blob:stub' }
    HTMLAnchorElement.prototype.click = function () {}
    btn.click()
    URL.createObjectURL = realCreate
    HTMLAnchorElement.prototype.click = realClick
    return captured ? { size: captured.size, type: captured.type } : 'no blob captured'
  })

  return { ...before, filteredRows, restoredRows, csv }
}
