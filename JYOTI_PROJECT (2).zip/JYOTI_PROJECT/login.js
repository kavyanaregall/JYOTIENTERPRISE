const API_BASE = "http://localhost:5000/api/auth";

const authForm = document.getElementById("authForm");
const loginMode = document.getElementById("loginMode");
const registerMode = document.getElementById("registerMode");
const roleSelection = document.getElementById("roleSelection");
const adminRole = document.getElementById("adminRole");
const customerRole = document.getElementById("customerRole");
const nameGroup = document.getElementById("nameGroup");
const nameInput = document.getElementById("name");
const phoneGroup = document.getElementById("phoneGroup");
const phoneInput = document.getElementById("phone");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const confirmPasswordGroup = document.getElementById("confirmPasswordGroup");
const confirmPasswordInput = document.getElementById("confirmPassword");
const rememberGroup = document.getElementById("rememberGroup");
const rememberMe = document.getElementById("rememberMe");
const togglePassword = document.getElementById("togglePassword");
const submitButton = document.getElementById("submitButton");
const authMessage = document.getElementById("authMessage");

const errorElements = {
    name: document.getElementById("nameError"),
    email: document.getElementById("emailError"),
    phone: document.getElementById("phoneError"),
    password: document.getElementById("passwordError"),
    confirmPassword: document.getElementById("confirmPasswordError")
};

let authMode = "login";
let selectedRole = "admin";

function setActiveButton(button, active) {
    button.classList.toggle("active", active);
    button.setAttribute("aria-selected", String(active));
}

function setMode(mode) {
    authMode = mode;
    const isLogin = mode === "login";

    setActiveButton(loginMode, isLogin);
    setActiveButton(registerMode, !isLogin);
    roleSelection.classList.toggle("hidden", !isLogin);
    nameGroup.classList.toggle("hidden", isLogin);
    phoneGroup.classList.toggle("hidden", isLogin);
    confirmPasswordGroup.classList.toggle("hidden", isLogin);
    rememberGroup.classList.toggle("hidden", !isLogin);
    submitButton.textContent = isLogin ? "Login" : "Register";

    if (!isLogin) {
        selectedRole = "customer";
        setActiveButton(adminRole, false);
        setActiveButton(customerRole, true);
    }

    clearMessages();
}

function setRole(role) {
    selectedRole = role;
    setActiveButton(adminRole, role === "admin");
    setActiveButton(customerRole, role === "customer");
}

function clearMessages() {
    Object.values(errorElements).forEach((element) => {
        element.textContent = "";
    });
    authMessage.textContent = "";
    authMessage.className = "login-message";
}

function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validateForm() {
    const isLogin = authMode === "login";
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    let valid = true;

    if (!isLogin && !nameInput.value.trim()) {
        errorElements.name.textContent = "Full name is required.";
        valid = false;
    }

    if (!email) {
        errorElements.email.textContent = "Email is required.";
        valid = false;
    } else if (!validateEmail(email)) {
        errorElements.email.textContent = "Enter a valid email address.";
        valid = false;
    }

    if (!isLogin && !phoneInput.value.trim()) {
        errorElements.phone.textContent = "Phone number is required.";
        valid = false;
    }

    if (!password) {
        errorElements.password.textContent = "Password is required.";
        valid = false;
    } else if (password.length < 6) {
        errorElements.password.textContent = "Password must contain at least 6 characters.";
        valid = false;
    }

    if (!isLogin && password !== confirmPasswordInput.value) {
        errorElements.confirmPassword.textContent = "Passwords do not match.";
        valid = false;
    }

    return valid;
}

async function submitLogin() {
    const email = emailInput.value.trim();
    const response = await fetch(`${API_BASE}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email,
            password: passwordInput.value,
            role: selectedRole
        })
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Unable to login.");
    }

    localStorage.setItem("user", JSON.stringify(data.user));
    localStorage.setItem("userRole", data.user.role);

    if (rememberMe.checked) {
        localStorage.setItem("jyotiLoginEmail", email);
    } else {
        localStorage.removeItem("jyotiLoginEmail");
    }

    authMessage.className = "login-message success";
    authMessage.textContent = data.message || "Login successful";

    setTimeout(() => {
        window.location.href = data.user.role === "admin"
            ? "admin/dashboard/dashboard.html"
            : "customer/dashboard/dashboard.html";
    }, 500);
}

async function submitRegistration() {
    const response = await fetch(`${API_BASE}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            name: nameInput.value.trim(),
            email: emailInput.value.trim(),
            phone: phoneInput.value.trim(),
            password: passwordInput.value
        })
    });

    const data = await response.json();

    if (!response.ok || !data.success) {
        throw new Error(data.message || "Unable to register.");
    }

    authMessage.className = "login-message success";
    authMessage.textContent = data.message || "Customer registered successfully";
    authForm.reset();

    setTimeout(() => setMode("login"), 700);
}

loginMode.addEventListener("click", () => setMode("login"));
registerMode.addEventListener("click", () => setMode("register"));
adminRole.addEventListener("click", () => setRole("admin"));
customerRole.addEventListener("click", () => setRole("customer"));

togglePassword.addEventListener("click", () => {
    const showing = passwordInput.type === "text";
    passwordInput.type = showing ? "password" : "text";
    togglePassword.textContent = showing ? "Show" : "Hide";
});

authForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearMessages();

    if (!validateForm()) {
        return;
    }

    submitButton.disabled = true;
    submitButton.textContent = authMode === "login" ? "Logging in..." : "Registering...";

    try {
        if (authMode === "login") {
            await submitLogin();
        } else {
            await submitRegistration();
        }
    } catch (error) {
        authMessage.textContent = error.message;
    } finally {
        submitButton.disabled = false;
        submitButton.textContent = authMode === "login" ? "Login" : "Register";
    }
});

const savedEmail = localStorage.getItem("jyotiLoginEmail");
if (savedEmail) {
    emailInput.value = savedEmail;
    rememberMe.checked = true;
}
