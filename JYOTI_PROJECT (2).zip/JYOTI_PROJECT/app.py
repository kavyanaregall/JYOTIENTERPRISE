import os
import time
from decimal import Decimal
from datetime import datetime, date
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room
from backend.config.db import get_db_connection

app = Flask(__name__)
# Enable CORS across all origins for local development & Live Server
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Real-time WebSocket connection
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', logger=True, engineio_logger=True)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'backend', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(os.path.join(UPLOAD_FOLDER, 'categories'), exist_ok=True)
os.makedirs(os.path.join(UPLOAD_FOLDER, 'products'), exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def clean_row(row):
    """Safely converts Decimals, Dates, and Timestamps to JSON-serializable types."""
    if not row:
        return None
    cleaned = {}
    for key, val in row.items():
        if isinstance(val, Decimal):
            cleaned[key] = float(val)
        elif isinstance(val, (datetime, date)):
            cleaned[key] = val.isoformat()
        else:
            cleaned[key] = val
    return cleaned

def save_customer_product_notification(cursor, event_id, product_id, product_name, price, stock, status, event_type):
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS customer_product_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            event_id VARCHAR(160) NOT NULL UNIQUE,
            product_id INT NOT NULL,
            product_name VARCHAR(255) NOT NULL,
            event_type VARCHAR(32) NOT NULL,
            message TEXT NOT NULL,
            price DECIMAL(10,2) NULL,
            stock INT NULL,
            status VARCHAR(80) NULL,
            created_at DATETIME NOT NULL
        )
    """)
    details = []
    if price is not None:
        details.append(f"Price: ₹{float(price):g}")
    if stock is not None:
        details.append(f"Stock: {int(stock)}")
    if status:
        details.append(f"Status: {status}")
    verb = "is now available" if event_type == 'added' else "was updated"
    message = f"{'; '.join(details)}. Visit the store to see the latest product details." if details else "Product information has changed. Visit the store to see the latest details."
    cursor.execute("""
        INSERT INTO customer_product_notifications
            (event_id, product_id, product_name, event_type, message, price, stock, status, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
    """, (
        event_id,
        product_id,
        product_name or "Store product",
        event_type,
        f"{product_name or 'A store product'} {verb}. {message}",
        price,
        stock,
        status,
        datetime.now()
    ))

@app.route('/uploads/<path:filename>')
def serve_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@socketio.on('join_admin')
def handle_join_admin():
    join_room('admin_channel')

@app.route('/api/auth/login', methods=['POST'])
def auth_login():
    data = request.get_json(silent=True) or {}
    email = str(data.get('email') or '').strip().lower()
    password = str(data.get('password') or '')
    role = str(data.get('role') or '').strip().lower()

    if not email or not password or role not in ('admin', 'customer'):
        return jsonify({'success': False, 'message': 'Invalid email or password'}), 400

    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            if role == 'admin':
                cursor.execute(
                    'SELECT id, name, email, password FROM admin WHERE LOWER(email) = %s LIMIT 1',
                    (email,)
                )
            else:
                cursor.execute(
                    "SELECT id, name, email, password FROM users WHERE LOWER(email) = %s AND role = 'customer' LIMIT 1",
                    (email,)
                )
            user = cursor.fetchone()

        if not user or str(user.get('password') or '') != password:
            return jsonify({'success': False, 'message': 'Invalid email or password'}), 401

        return jsonify({
            'success': True,
            'message': 'Login successful',
            'user': {
                'id': user.get('id'),
                'name': user.get('name') or ('Admin' if role == 'admin' else ''),
                'email': user.get('email'),
                'role': role
            }
        }), 200
    except Exception as error:
        app.logger.exception('Authentication request failed')
        return jsonify({'success': False, 'message': 'Could not verify account'}), 500
    finally:
        if conn:
            conn.close()

# ============================================================
# 1. PRODUCTS ENDPOINTS
# ============================================================

@app.route('/api/products', methods=['GET'])
def get_products():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                SELECT 
                    p.id, 
                    p.name, 
                    p.sku, 
                    p.category_id,
                    COALESCE(c.name, 'Uncategorized') AS category_name,
                    p.description, 
                    p.price, 
                    p.stock, 
                    p.status, 
                    p.image, 
                    p.brand, 
                    COALESCE(p.minimum_stock, 10) AS minimum_stock, 
                    p.created_at
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                ORDER BY p.id DESC
            """
            cursor.execute(query)
            raw_products = cursor.fetchall() or []
            
        products = [clean_row(p) for p in raw_products]
        return jsonify({
            'success': True,
            'products': products,
            'data': products,
            'total': len(products)
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e), 'products': []}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/products/<int:product_id>', methods=['GET'])
def get_single_product(product_id):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                SELECT 
                    p.id, p.name, p.sku, p.category_id,
                    COALESCE(c.name, 'Uncategorized') AS category_name,
                    p.description, p.price, p.stock, p.status, p.image, p.brand, 
                    COALESCE(p.minimum_stock, 10) AS minimum_stock, p.created_at
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                WHERE p.id = %s
            """
            cursor.execute(query, (product_id,))
            product = cursor.fetchone()

        if not product:
            return jsonify({'success': False, 'message': 'Product not found'}), 404

        return jsonify({'success': True, 'product': clean_row(product)}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/products', methods=['POST'])
def add_product():
    conn = None
    try:
        name = request.form.get('productName')
        sku = request.form.get('productCode')
        category_val = request.form.get('productCategory')
        brand = request.form.get('productBrand')
        price = float(request.form.get('productPrice', 0))
        stock = int(request.form.get('productQuantity', 0))
        min_stock = int(request.form.get('productMinimumStock', 10))
        status = request.form.get('productStatus', 'In Stock')
        description = request.form.get('productDescription', '')

        image_filename = None
        if 'productImage' in request.files:
            file = request.files['productImage']
            if file and file.filename != '':
                ext = os.path.splitext(file.filename)[1].lower()
                clean_name = f"{int(time.time())}_{os.urandom(4).hex()}{ext}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'products', clean_name))
                image_filename = f"/uploads/products/{clean_name}"

        conn = get_db_connection()
        with conn.cursor() as cursor:
            category_id = None
            if category_val:
                cursor.execute("SELECT id FROM categories WHERE name = %s OR id = %s", (category_val, category_val))
                cat_row = cursor.fetchone()
                if cat_row:
                    category_id = cat_row['id']
                else:
                    cursor.execute("INSERT INTO categories (name, status) VALUES (%s, 'Active')", (category_val,))
                    category_id = cursor.lastrowid

            query = """
                INSERT INTO products 
                (name, sku, category_id, description, price, stock, status, image, brand, minimum_stock)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (name, sku, category_id, description, price, stock, status, image_filename, brand, min_stock))
            new_id = cursor.lastrowid
            event_id = f'product-added-{new_id}-{int(time.time() * 1000)}'
            save_customer_product_notification(
                cursor, event_id, new_id, name, price, stock, status, 'added'
            )
            conn.commit()

        socketio.emit('product_added', {
            'event_id': event_id,
            'id': new_id,
            'name': name,
            'price': price,
            'stock': stock,
            'image': image_filename,
            'status': status,
            'updated_at': datetime.now().isoformat(timespec='seconds')
        })

        return jsonify({'success': True, 'message': 'Product added successfully', 'id': new_id}), 201
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/products/<int:product_id>', methods=['PUT', 'POST'])
def update_product(product_id):
    conn = None
    try:
        name = request.form.get('productName')
        sku = request.form.get('productCode')
        category_val = request.form.get('productCategory')
        brand = request.form.get('productBrand')
        price = float(request.form.get('productPrice', 0))
        stock = int(request.form.get('productQuantity', 0))
        min_stock = int(request.form.get('productMinimumStock', 10))
        status = request.form.get('productStatus', 'In Stock')
        description = request.form.get('productDescription', '')
        event_id = f'product-updated-{product_id}-{int(time.time() * 1000)}'
        updated_at = datetime.now()

        conn = get_db_connection()
        with conn.cursor() as cursor:
            category_id = None
            if category_val:
                cursor.execute("SELECT id FROM categories WHERE name = %s OR id = %s", (category_val, category_val))
                cat_row = cursor.fetchone()
                if cat_row:
                    category_id = cat_row['id']
                else:
                    cursor.execute("INSERT INTO categories (name, status) VALUES (%s, 'Active')", (category_val,))
                    category_id = cursor.lastrowid

            image_filename = None
            if 'productImage' in request.files and request.files['productImage'].filename != '':
                file = request.files['productImage']
                ext = os.path.splitext(file.filename)[1].lower()
                clean_name = f"{int(time.time())}_{os.urandom(4).hex()}{ext}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'products', clean_name))
                image_filename = f"/uploads/products/{clean_name}"

                query = """
                    UPDATE products 
                    SET name=%s, sku=%s, category_id=%s, description=%s, price=%s, stock=%s, status=%s, image=%s, brand=%s, minimum_stock=%s
                    WHERE id=%s
                """
                cursor.execute(query, (name, sku, category_id, description, price, stock, status, image_filename, brand, min_stock, product_id))
            else:
                query = """
                    UPDATE products 
                    SET name=%s, sku=%s, category_id=%s, description=%s, price=%s, stock=%s, status=%s, brand=%s, minimum_stock=%s
                    WHERE id=%s
                """
                cursor.execute(query, (name, sku, category_id, description, price, stock, status, brand, min_stock, product_id))

            save_customer_product_notification(
                cursor, event_id, product_id, name, price, stock,
                'Out of Stock' if stock <= 0 else status, 'updated'
            )
            conn.commit()

        socketio.emit('product_updated', {
            'event_id': event_id,
            'id': product_id,
            'name': name,
            'price': price,
            'stock': stock,
            'status': 'Out of Stock' if stock <= 0 else status,
            'updated_at': updated_at.isoformat(timespec='seconds')
        })

        return jsonify({'success': True, 'message': 'Product updated successfully'}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM products WHERE id = %s", (product_id,))
            conn.commit()

        socketio.emit('product_deleted', {'id': product_id})
        return jsonify({'success': True, 'message': 'Product deleted successfully'}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# ============================================================
# 2. CATEGORIES ENDPOINTS
# ============================================================

@app.route('/api/categories', methods=['GET'])
def get_categories():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                SELECT 
                    c.id, 
                    c.name, 
                    COALESCE(c.description, '') AS description, 
                    COALESCE(c.status, 'Active') AS status, 
                    c.image, 
                    c.created_at,
                    COUNT(p.id) AS products,
                    COALESCE(SUM(p.stock), 0) AS stock
                FROM categories c
                LEFT JOIN products p ON c.id = p.category_id
                GROUP BY c.id, c.name, c.description, c.status, c.image, c.created_at
                ORDER BY c.id DESC
            """
            cursor.execute(query)
            raw_categories = cursor.fetchall() or []

        categories = [clean_row(cat) for cat in raw_categories]
        return jsonify({
            'success': True,
            'categories': categories,
            'data': categories,
            'total': len(categories)
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e), 'categories': []}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/categories', methods=['POST'])
def add_category():
    conn = None
    try:
        name = request.form.get('categoryName')
        description = request.form.get('categoryDescription', '')
        status = request.form.get('categoryStatus', 'Active')

        image_filename = None
        if 'categoryImage' in request.files:
            file = request.files['categoryImage']
            if file and file.filename != '':
                ext = os.path.splitext(file.filename)[1].lower()
                clean_name = f"cat_{int(time.time())}_{os.urandom(4).hex()}{ext}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], 'categories', clean_name))
                image_filename = f"/uploads/categories/{clean_name}"

        conn = get_db_connection()
        with conn.cursor() as cursor:
            query = """
                INSERT INTO categories (name, description, status, image)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (name, description, status, image_filename))
            conn.commit()

        return jsonify({'success': True, 'message': 'Category added successfully'}), 201
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# ============================================================
# 3. ORDERS LIFECYCLE SCHEMA & API
# ============================================================

def ensure_orders_schema(cursor):
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NULL,
            customer_name VARCHAR(150),
            customer_phone VARCHAR(40) NULL,
            customer_email VARCHAR(150) NULL,
            fulfillment_type VARCHAR(40) NOT NULL DEFAULT 'store_pickup',
            payment_method VARCHAR(80) NOT NULL DEFAULT 'Pay at counter',
            total_amount DECIMAL(10,2),
            status VARCHAR(50) DEFAULT 'Awaiting Pickup',
            is_admin_notified TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("SHOW COLUMNS FROM orders")
    columns = {column["Field"] for column in cursor.fetchall()}
    additions = {
        "customer_phone": "VARCHAR(40) NULL",
        "customer_email": "VARCHAR(150) NULL",
        "fulfillment_type": "VARCHAR(40) NOT NULL DEFAULT 'store_pickup'",
        "payment_method": "VARCHAR(80) NOT NULL DEFAULT 'Pay at counter'"
    }
    for name, definition in additions.items():
        if name not in columns:
            cursor.execute(f"ALTER TABLE orders ADD COLUMN `{name}` {definition}")

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id INT NULL,
            product_name VARCHAR(255) NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            quantity INT NOT NULL,
            INDEX idx_order_items_order_id (order_id)
        )
    """)

@app.route('/api/orders', methods=['POST'])
def place_order():
    conn = None
    try:
        data = request.get_json() or {}
        user_id = data.get('user_id')
        customer_name = str(data.get('customer_name') or 'Customer').strip()[:150]
        customer_phone = str(data.get('customer_phone') or '').strip()[:40]
        customer_email = str(data.get('customer_email') or '').strip()[:150]
        total_amount = float(data.get('total_amount', 0))
        items = data.get('items', [])

        if not isinstance(items, list) or not items:
            return jsonify({'success': False, 'message': 'Cart cannot be empty'}), 400

        conn = get_db_connection()
        with conn.cursor() as cursor:
            ensure_orders_schema(cursor)
            cursor.execute("""
                INSERT INTO orders (
                    user_id, customer_name, customer_phone, customer_email,
                    fulfillment_type, payment_method, total_amount, status, is_admin_notified
                )
                VALUES (%s, %s, %s, %s, 'store_pickup', 'Pay at counter', %s, 'Awaiting Pickup', 0)
            """, (user_id, customer_name, customer_phone, customer_email, total_amount))
            order_id = cursor.lastrowid

            for item in items:
                product_id = int(item.get('product_id') or item.get('id'))
                quantity = max(1, int(item.get('quantity', 1)))
                unit_price = max(0, float(item.get('price', 0)))
                product_name = str(item.get('product_name') or item.get('name') or f'Product #{product_id}')[:255]

                cursor.execute("""
                    INSERT INTO order_items (order_id, product_id, product_name, unit_price, quantity)
                    VALUES (%s, %s, %s, %s, %s)
                """, (order_id, product_id, product_name, unit_price, quantity))

                cursor.execute("""
                    UPDATE products 
                    SET stock = GREATEST(stock - %s, 0) 
                    WHERE id = %s
                """, (quantity, product_id))

            conn.commit()

        socketio.emit('new_order', {
            'order_id': order_id,
            'customer_name': customer_name,
            'customer_phone': customer_phone,
            'total_amount': total_amount,
            'fulfillment_type': 'store_pickup',
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })

        return jsonify({'success': True, 'message': 'Order confirmed successfully!', 'order_id': order_id}), 201
    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/orders', methods=['GET'])
def get_orders():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            ensure_orders_schema(cursor)
            cursor.execute("""
                SELECT id, customer_name, customer_phone, customer_email,
                       fulfillment_type, payment_method, total_amount, status, created_at
                FROM orders
                ORDER BY id DESC
            """)
            order_rows = [clean_row(row) for row in cursor.fetchall() or []]
            order_ids = [row['id'] for row in order_rows]
            items_by_order = {}

            if order_ids:
                placeholders = ','.join(['%s'] * len(order_ids))
                cursor.execute(f"""
                    SELECT order_id, product_id, product_name, unit_price, quantity
                    FROM order_items
                    WHERE order_id IN ({placeholders})
                    ORDER BY id
                """, tuple(order_ids))
                for item in cursor.fetchall() or []:
                    items_by_order.setdefault(item['order_id'], []).append({
                        'id': item['product_id'],
                        'name': item['product_name'],
                        'price': float(item['unit_price']),
                        'quantity': int(item['quantity'])
                    })

        orders = [{
            'id': row['id'],
            'customer': {
                'name': row.get('customer_name') or 'Customer',
                'email': row.get('customer_email') or '',
                'phone': row.get('customer_phone') or ''
            },
            'items': items_by_order.get(row['id'], []),
            'total': float(row.get('total_amount') or 0),
            'date': row.get('created_at'),
            'status': row.get('status') or 'Awaiting Pickup',
            'fulfillment_type': row.get('fulfillment_type') or 'store_pickup',
            'payment_method': row.get('payment_method') or 'Pay at counter'
        } for row in order_rows]

        return jsonify({'success': True, 'orders': orders, 'data': orders}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e), 'orders': []}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/orders/<int:order_id>/status', methods=['PUT'])
def update_order_status(order_id):
    allowed_statuses = {'Awaiting Pickup', 'Ready for Pickup', 'Collected', 'Cancelled'}
    data = request.get_json() or {}
    status = str(data.get('status') or '').strip()
    if status not in allowed_statuses:
        return jsonify({'success': False, 'message': 'Invalid pickup order status'}), 400

    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            ensure_orders_schema(cursor)
            cursor.execute("UPDATE orders SET status = %s WHERE id = %s", (status, order_id))
            conn.commit()
        return jsonify({'success': True, 'status': status}), 200
    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

# ============================================================
# 4. COMPREHENSIVE REPORTS & ANALYTICS API
# ============================================================

@app.route('/api/admin/reports/analytics', methods=['GET'])
@app.route('/api/admin/reports/summary', methods=['GET'])
@app.route('/api/reports/summary', methods=['GET'])
def get_reports_analytics():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            # 1. Fetch all products
            cursor.execute("""
                SELECT 
                    p.id, p.name, p.sku, p.category_id,
                    COALESCE(c.name, 'Uncategorized') AS category_name,
                    p.price, p.stock, COALESCE(p.minimum_stock, 10) AS minimum_stock
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
            """)
            raw_prods = cursor.fetchall() or []
            products = [clean_row(p) for p in raw_prods]

            # 2. Fetch all categories
            cursor.execute("SELECT id, name FROM categories")
            categories = [clean_row(c) for c in (cursor.fetchall() or [])]

            # 3. Fetch all orders
            cursor.execute("""
                SELECT 
                    id, customer_name, customer_phone, fulfillment_type, 
                    total_amount, status, created_at
                FROM orders 
                ORDER BY id DESC
            """)
            orders = [clean_row(o) for o in (cursor.fetchall() or [])]

            # 4. Fetch all order items if table exists
            order_items = []
            try:
                cursor.execute("SELECT order_id, product_id, product_name, unit_price, quantity FROM order_items")
                order_items = [clean_row(oi) for oi in (cursor.fetchall() or [])]
            except Exception:
                order_items = []

        # --- Perform All Calculations in Python (100% crash-proof) ---
        total_products = len(products)
        total_categories = len(categories)
        total_stock_units = sum(int(p.get('stock') or 0) for p in products)
        total_stock_value = sum(float(p.get('price') or 0) * int(p.get('stock') or 0) for p in products)
        low_stock_count = sum(1 for p in products if int(p.get('stock') or 0) <= int(p.get('minimum_stock') or 10))

        total_orders_placed = len(orders)
        count_awaiting_pickup = 0
        count_confirmed_ready = 0
        count_collected = 0
        count_cancelled = 0
        total_revenue = 0.0
        collected_revenue = 0.0

        orders_log = []
        for o in orders:
            st = str(o.get('status') or '').strip().lower()
            amt = float(o.get('total_amount') or 0.0)

            if 'awaiting' in st or 'pending' in st:
                count_awaiting_pickup += 1
            elif 'ready' in st or 'confirmed' in st:
                count_confirmed_ready += 1
            elif 'collected' in st or 'completed' in st:
                count_collected += 1
                collected_revenue += amt
            elif 'cancel' in st:
                count_cancelled += 1

            if 'cancel' not in st:
                total_revenue += amt

            # Match items count
            o_items = [it for it in order_items if it.get('order_id') == o['id']]
            items_count = sum(int(it.get('quantity') or 1) for it in o_items) if o_items else 1

            dt = o.get('created_at')
            formatted_date = str(dt) if dt else '-'

            orders_log.append({
                'id': o['id'],
                'customer_name': o.get('customer_name') or 'Customer',
                'customer_phone': o.get('customer_phone') or '-',
                'fulfillment_type': o.get('fulfillment_type') or 'Store pickup',
                'items_count': items_count,
                'total_amount': amt,
                'formatted_date': formatted_date,
                'status': o.get('status') or 'Awaiting Pickup'
            })

        # Calculate Sales and Units per product
        total_units_sold = sum(int(it.get('quantity') or 0) for it in order_items)

        # Category sales & stock distribution
        category_sales_map = {c['name']: {'category': c['name'], 'total_sales_amount': 0.0, 'units_sold': 0} for c in categories}
        category_stock_map = {c['name']: {'category': c['name'], 'stock_qty': 0, 'product_count': 0} for c in categories}

        for p in products:
            cname = p.get('category_name') or 'Uncategorized'
            if cname not in category_stock_map:
                category_stock_map[cname] = {'category': cname, 'stock_qty': 0, 'product_count': 0}
            category_stock_map[cname]['stock_qty'] += int(p.get('stock') or 0)
            category_stock_map[cname]['product_count'] += 1

        for it in order_items:
            # find category
            pid = it.get('product_id')
            matched_prod = next((p for p in products if p['id'] == pid), None)
            cname = matched_prod.get('category_name') if matched_prod else 'Uncategorized'
            if cname not in category_sales_map:
                category_sales_map[cname] = {'category': cname, 'total_sales_amount': 0.0, 'units_sold': 0}
            qty = int(it.get('quantity') or 0)
            price = float(it.get('unit_price') or 0.0)
            category_sales_map[cname]['units_sold'] += qty
            category_sales_map[cname]['total_sales_amount'] += (qty * price)

        # Itemized Product Breakdown
        product_breakdown = []
        for p in products:
            p_items = [it for it in order_items if it.get('product_id') == p['id']]
            units_sold = sum(int(it.get('quantity') or 0) for it in p_items)
            sales_val = sum(int(it.get('quantity') or 0) * float(it.get('unit_price') or 0) for it in p_items)
            product_breakdown.append({
                'id': p['id'],
                'name': p['name'],
                'category_name': p.get('category_name') or 'Uncategorized',
                'stock': int(p.get('stock') or 0),
                'price': float(p.get('price') or 0.0),
                'total_units_sold': units_sold,
                'total_sales_value': sales_val
            })

        return jsonify({
            'success': True,
            'kpis': {
                'total_orders_placed': total_orders_placed,
                'count_awaiting_pickup': count_awaiting_pickup,
                'count_confirmed_ready': count_confirmed_ready,
                'count_collected': count_collected,
                'count_cancelled': count_cancelled,
                'total_revenue': total_revenue,
                'collected_revenue': collected_revenue,
                'total_units_sold': total_units_sold,
                'total_products': total_products,
                'total_categories': total_categories,
                'total_stock_units': total_stock_units,
                'total_stock_value': total_stock_value,
                'low_stock_count': low_stock_count
            },
            'category_sales': list(category_sales_map.values()),
            'stock_by_category': list(category_stock_map.values()),
            'product_breakdown': product_breakdown,
            'orders_log': orders_log
        }), 200

    except Exception as e:
        print("CRITICAL ERROR IN ANALYTICS ROUTE:", str(e))
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close() 
# 5. DASHBOARD STATS & NOTIFICATIONS
# ============================================================

@app.route('/api/dashboard/stats', methods=['GET'])
def get_dashboard_stats():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    COUNT(*) AS total_products,
                    COALESCE(SUM(CASE WHEN stock <= minimum_stock AND stock > 0 THEN 1 ELSE 0 END), 0) AS low_stock,
                    COALESCE(SUM(CASE WHEN stock > minimum_stock THEN 1 ELSE 0 END), 0) AS in_stock,
                    COALESCE(SUM(CASE WHEN stock <= 0 THEN 1 ELSE 0 END), 0) AS out_of_stock
                FROM products
            """)
            prod_stats = cursor.fetchone() or {}

            cursor.execute("SELECT COUNT(*) AS total_categories FROM categories")
            cat_row = cursor.fetchone() or {}

            total_customers = 0
            try:
                cursor.execute("SELECT COUNT(*) AS total_customers FROM users WHERE role = 'customer'")
                cust_row = cursor.fetchone() or {}
                total_customers = cust_row.get('total_customers', 0)
            except Exception:
                pass

            cursor.execute("""
                SELECT 
                    p.id, p.name, p.sku, 
                    COALESCE(c.name, 'Uncategorized') AS category_name,
                    p.price, p.stock, p.status, p.image, p.brand
                FROM products p
                LEFT JOIN categories c ON p.category_id = c.id
                ORDER BY p.id DESC
                LIMIT 5
            """)
            recent_products = [clean_row(r) for r in cursor.fetchall() or []]

        return jsonify({
            'success': True,
            'stats': {
                'total_products': prod_stats.get('total_products', 0),
                'low_stock': prod_stats.get('low_stock', 0),
                'in_stock': prod_stats.get('in_stock', 0),
                'out_of_stock': prod_stats.get('out_of_stock', 0),
                'total_categories': cat_row.get('total_categories', 0),
                'total_customers': total_customers
            },
            'recent_products': recent_products
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/admin/customers', methods=['GET'])
def get_admin_customers():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT id, name, email, phone, role, created_at FROM users WHERE role = 'customer' ORDER BY id DESC")
            users = cursor.fetchall() or []
        return jsonify({'success': True, 'customers': [clean_row(u) for u in users]}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/admin/notifications', methods=['GET'])
def get_admin_notifications():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            ensure_orders_schema(cursor)
            cursor.execute("""
                SELECT id, customer_name, customer_phone, fulfillment_type, total_amount, created_at 
                FROM orders 
                WHERE is_admin_notified = 0 
                ORDER BY id DESC
            """)
            unread_orders = [clean_row(row) for row in cursor.fetchall() or []]

            cursor.execute("""
                SELECT id, name, stock, COALESCE(minimum_stock, 10) AS minimum_stock 
                FROM products 
                WHERE stock <= COALESCE(minimum_stock, 10)
            """)
            low_stock_alerts = [clean_row(row) for row in cursor.fetchall() or []]

        return jsonify({
            'success': True,
            'unread_orders': unread_orders,
            'low_stock_alerts': low_stock_alerts,
            'total_alerts': len(unread_orders) + len(low_stock_alerts)
        }), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/admin/notifications/mark-read', methods=['POST'])
def mark_admin_notifications_read():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("UPDATE orders SET is_admin_notified = 1 WHERE is_admin_notified = 0")
            conn.commit()
        return jsonify({'success': True}), 200
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

@app.route('/api/admin/settings', methods=['GET', 'POST'])
def manage_store_settings():
    conn = None
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS store_settings (
                    id INT PRIMARY KEY DEFAULT 1,
                    store_name VARCHAR(150),
                    contact_number VARCHAR(50),
                    email_address VARCHAR(150),
                    store_address TEXT,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            """)

            if request.method == 'GET':
                cursor.execute("SELECT store_name, contact_number, email_address, store_address FROM store_settings WHERE id = 1")
                row = cursor.fetchone()
                if not row:
                    default_settings = {
                        'store_name': 'Jyoti Enterprise',
                        'contact_number': '+91 98765 43210',
                        'email_address': 'info@jyotienterprise.com',
                        'store_address': 'Jyoti Enterprise, Main Market Road, Bengaluru, Karnataka - 560001'
                    }
                    cursor.execute("""
                        INSERT INTO store_settings (id, store_name, contact_number, email_address, store_address)
                        VALUES (1, %s, %s, %s, %s)
                    """, (default_settings['store_name'], default_settings['contact_number'], default_settings['email_address'], default_settings['store_address']))
                    conn.commit()
                    return jsonify({'success': True, 'settings': default_settings})
                
                return jsonify({'success': True, 'settings': row})

            elif request.method == 'POST':
                data = request.get_json() or {}
                cursor.execute("""
                    INSERT INTO store_settings (id, store_name, contact_number, email_address, store_address)
                    VALUES (1, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE 
                        store_name = VALUES(store_name),
                        contact_number = VALUES(contact_number),
                        email_address = VALUES(email_address),
                        store_address = VALUES(store_address)
                """, (data.get('store_name', ''), data.get('contact_number', ''), data.get('email_address', ''), data.get('store_address', '')))
                conn.commit()
                return jsonify({'success': True, 'message': 'Store settings updated successfully!'})
    except Exception as e:
        if conn:
            conn.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if conn:
            conn.close()

if __name__ == '__main__':
    socketio.run(app, host='127.0.0.1', port=5000, debug=True)
